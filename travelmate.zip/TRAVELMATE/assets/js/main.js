// TRAVELMATE AI - Main application script
// Placeholder for global page interactions

document.addEventListener('DOMContentLoaded', function(){
  console.log('TRAVELMATE AI loaded');

  // Any global click handlers can go here
  document.querySelectorAll('a[href="#"]').forEach(function(link){
    link.addEventListener('click', function(e){
      e.preventDefault();
    });
  });
});