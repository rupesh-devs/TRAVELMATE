<?php
/**
 * TRAVELMATE AI - Destination Explorer
 */
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/config/auth.php';

$destinations = Database::query('SELECT * FROM destinations ORDER BY is_popular DESC, is_trending DESC, rating DESC');
$countries = array_unique(array_column($destinations ?? [], 'country'));
$types = ['domestic' => 'Domestic', 'international' => 'International'];
?>
<div class="container">
  <div class="dashboard-header">
    <h1>🌍 Destination Explorer</h1>
    <p class="small">Discover domestic and international destinations with weather, currency, and map locations.</p>
  </div>

  <div class="grid grid-2">
    <div class="card">
      <div class="card-body">
        <h3>Filter Destinations</h3>
        <div class="form-group">
          <label>Search</label>
          <input type="text" id="destSearch" class="form-control" placeholder="Search destination...">
        </div>
        <div class="form-group">
          <label>Country</label>
          <select id="destCountry" class="form-select">
            <option value="">All countries</option>
            <?php foreach ($countries as $c): ?>
              <option value="<?= e($c) ?>"><?= e($c) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="form-group">
          <label>Type</label>
          <select id="destType" class="form-select">
            <option value="">All types</option>
            <?php foreach ($types as $v => $l): ?>
              <option value="<?= e($v) ?>"><?= e($l) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="form-group">
          <label>Best Season</label>
          <input type="text" id="destSeason" class="form-control" placeholder="e.g. Winter">
        </div>
        <div class="btn-group mt-3">
          <button class="btn btn-outline btn-sm" onclick="clearFilters()">Clear filters</button>
        </div>
      </div>
    </div>

    <div class="card" id="mapCard">
      <div class="card-body">
        <h3>Map View</h3>
        <div id="destMap" style="height:300px;width:100%;border-radius:var(--radius-lg);background:var(--color-offwhite);display:flex;align-items:center;justify-content:center;color:var(--color-muted);">
          Configure Google Maps API key to view interactive map
        </div>
      </div>
    </div>
  </div>

  <h3 style="margin:var(--space-xl) 0 var(--space-lg);">All Destinations</h3>
  <div class="grid grid-3" id="destList">
    <?php if ($destinations): foreach ($destinations as $d): ?>
      <div class="destination-card" data-country="<?= e($d['country']) ?>" data-type="<?= e($d['type']) ?>" data-season="<?= e($d['best_season']) ?>">
        <div class="destination-image">
          <img src="<?= e($d['image_url']) ?>" alt="<?= e($d['name']) ?>">
          <div class="destination-badge badge badge-dark"><?= e($d['rating']) ?>★</div>
        </div>
        <div class="destination-body">
          <h3><?= e($d['name']) ?></h3>
          <div class="destination-meta">📍 <?= e($d['country']) ?>, <?= e($d['city']) ?></div>
          <p class="small" style="color:var(--color-muted);margin-top:var(--space-xs);"><?= e($d['short_description']) ?></p>
          <div style="margin-top:var(--space-md);">
            <span class="badge badge-info">📅 <?= e($d['best_season']) ?></span>
            <span class="badge badge-<?= $d['is_popular'] ? 'success' : 'info' ?>"><?= $d['is_popular'] ? 'Popular' : ($d['is_trending'] ? 'Trending' : '') ?></span>
          </div>
        </div>
        <div class="destination-overlay">
          <div style="font-size:2rem;margin-bottom:var(--space-sm);">✈️</div>
          <div style="font-weight:600;"><?= e($d['name']) ?></div>
          <div class="destination-actions mt-3">
            <a href="<?= url('booking/flights.php?source=&destination=' . urlencode($d['city'])) ?>" class="btn btn-outline btn-sm">Explore</a>
          </div>
        </div>
      </div>
    <?php endforeach; else: ?>
      <div class="empty-state" style="grid-column:1/-1;">
        <div class="icon">🌍</div>
        <h3 style="font-size:var(--text-lg);">No destinations yet</h3>
      </div>
    <?php endforeach; ?>
  </div>
</div>

<script>
(function(){
  const cards = document.querySelectorAll('.destination-card');
  const filters = { search: document.getElementById('destSearch'), country: document.getElementById('destCountry'), type: document.getElementById('destType'), season: document.getElementById('destSeason') };

  function filter() {
    const s = filters.search.value.toLowerCase();
    const c = filters.country.value;
    const t = filters.type.value;
    const se = filters.season.value.toLowerCase();
    cards.forEach(card => {
      const match = (
        card.textContent.toLowerCase().includes(s) &&
        (!c || card.dataset.country === c) &&
        (!t || card.dataset.type === t) &&
        (!se || card.dataset.season.toLowerCase().includes(se))
      );
      card.style.display = match ? '' : 'none';
    });
  }
  [filters.search, filters.country, filters.type, filters.season].forEach(el => el.addEventListener('input', filter));
  window.clearFilters = function(){ [filters.search, filters.country, filters.type, filters.season].forEach(el => el.value = ''); filter(); };

  // Weather widget per destination card
  async function loadWeather() {
    cards.forEach(async (card) => {
      const name = card.querySelector('h3').textContent;
      try {
        const res = await fetch('<?= url('api/weather.php?city=') ?>' + encodeURIComponent(name));
        const data = await res.json();
        if (data.success) {
          const badge = card.querySelector('.destination-badge');
          badge.textContent = data.temperature + '°C';
        }
      } catch (e) {}
    });
  }
  loadWeather();
})();
</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>