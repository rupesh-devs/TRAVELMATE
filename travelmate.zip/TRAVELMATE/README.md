# TRAVELMATE AI
**"Explore the World. Travel Smarter."**

A complete, premium, AI-powered travel management and booking platform — BCA Final Year Major Project.

## 🌟 Overview

TRAVELMATE AI is a full-stack travel technology platform built with **PHP 8+**, **MySQL (PDO)**, **HTML5/CSS3/JavaScript**, and **Bootstrap-style custom CSS**. It integrates **Google Gemini AI** for an intelligent travel assistant, **Google Maps** for destination discovery, **Razorpay/Stripe/PayPal** for payments, and includes QR e-tickets, a digital wallet, admin dashboard, and much more.

Designed with a premium international UI: navy blue, white, sky blue, and gold accents; glassmorphism navigation; dark/light mode; responsive layouts.

## 🚀 Features

- **Premium UI/UX** — Rotating destination hero, glassmorphism search, rounded cards, smooth transitions, dark/light mode.
- **Authentication** — Register, login, forgot password, password reset, secure sessions, CSRF protection, rate limiting, role-based access (user/admin).
- **User Dashboard** — Profile, upcoming trips, booking history, travel wallet, reward points, notifications, wishlist, settings.
- **Booking Modules** — Flights, buses, trains, hotels (simulated demo data with clear labels).
- **AI Travel Assistant** — Gemini-powered chat with text/voice input and responses, Hindi & English, itineraries, budget suggestions, packing checklists.
- **Smart Trip Planner** — Day-wise itinerary generator with cost estimates.
- **Multi-Transport Comparison** — Flights vs trains vs buses with price/duration sorting.
- **Destination Discovery** — Global & Indian destinations, best seasons, map locations, reviews, wishlist.
- **Google Maps** — Interactive destination markers.
- **Weather & Currency** — Current weather, forecast, multi-currency converter (INR, USD, EUR, GBP, AED, AUD, CAD, SGD).
- **Payments** — Razorpay (UPI/cards/net banking), Stripe, PayPal — all in sandbox/demo mode. Server-side verification. No card data stored.
- **QR E-Tickets** — Unique booking references, QR codes, backend verification, printable/downloadable tickets.
- **Digital Wallet** — Balance, transactions, reward points.
- **Cancellation & Refunds** — Cancellation requests, refund tracking.
- **Travel Buddy Finder** — Profiles, interests, consent-based sharing.
- **Extras** — AI packing assistant, voice search, trip countdown, notifications, search history, emergency contacts, multilingual UI.
- **Admin Dashboard** — Users, destinations, flights, buses, trains, hotels, reviews, refunds, revenue analytics with Chart.js.
- **Security** — PDO prepared statements, password hashing, CSRF, XSS prevention, server-side validation, secure sessions.

## 🛠 Technology Stack

| Layer | Technology |
|-------|-----------|
| Frontend | HTML5, CSS3, JavaScript (Vanilla), Google Fonts |
| Styling | Custom CSS (glassmorphism, dark mode, responsive) |
| Backend | PHP 8+, MySQL, PDO prepared statements |
| AI | Google Gemini API (server-side proxy) |
| Maps | Google Maps JavaScript API |
| Payments | Razorpay, Stripe, PayPal (sandbox) |
| Charts | Chart.js |
| Icons | Emoji / SVG inline icons |

## 📦 Installation

### Requirements
- PHP 8.0 or higher
- MySQL 5.7 / 8.0
- Apache / Nginx (e.g., XAMPP, WAMP, LAMP)
- Composer (optional)
- cURL extension enabled in PHP

### Step 1 — Clone / copy files
Place the `TRAVELMATE` folder in your web server root (e.g., `htdocs/TRAVELMATE` for XAMPP).

### Step 2 — Configure environment
```bash
cd TRAVELMATE
cp .env.example .env
```
Edit `.env` and set:
- `DB_HOST`, `DB_USER`, `DB_PASS`, `DB_NAME`
- `APP_URL` (e.g., `http://localhost/travelmate`)
- API keys: `GEMINI_API_KEY`, `GOOGLE_MAPS_API_KEY`, `WEATHER_API_KEY`, `CURRENCY_API_KEY`, `RAZORPAY_KEY_ID/SECRET`, `STRIPE_*`, `PAYPAL_*`
- `DEMO_MODE=true` for development (no real API keys needed)

### Step 3 — Create the database
Option A (installer): open `http://localhost/travelmate/install.php` in your browser and fill in DB details.

Option B (manual):
```bash
mysql -u root -p
CREATE DATABASE travelmate CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
exit
mysql -u root -p travelmate < database.sql
```

### Step 4 — Run
Visit `http://localhost/travelmate/index.php`

### Demo credentials
| Role | Email | Password |
|------|-------|----------|
| Customer | rahul@example.com | Travel@123 |
| Admin | admin@travelmate.ai | Admin@123 |

> ⚠️ All bookings and payments are **demo/simulated** unless you configure real provider credentials and set `DEMO_MODE=false`. No real tickets or payments are processed in demo mode.

## 📁 Project Structure

```
TRAVELMATE/
├── .env.example            # Environment variables template
├── .gitignore
├── database.sql            # Full MySQL schema + sample data
├── install.php             # Web-based database installer
├── index.php               # Homepage
├── contact.php             # Contact page
├── destinations.php        # Public destination explorer
├── config/
│   ├── config.php          # App config & .env loader
│   ├── database.php        # PDO connection
│   ├── functions.php       # Helpers (flash, CSRF, auth, money)
│   ├── csrf.php            # CSRF protection
│   └── auth.php            # Register/login/password-reset
├── includes/
│   ├── header.php          # HTML head + navbar
│   └── footer.php          # Footer + scripts
├── auth/                   # Login, register, forgot password, reset, logout
├── dashboard/              # User dashboard (profile, bookings, wallet, settings, ...)
├── booking/                # Flights, buses, trains, hotels, passenger details, payment, tickets
├── ai/                     # AI assistant & itinerary planner
├── admin/                  # Admin dashboard & management
├── api/                    # Backend APIs (Gemini, weather, currency, QR, payment webhooks)
│   └── payments/           # Razorpay/Stripe/PayPal webhooks
└── assets/
    ├── css/                # variables, typography, layout, components, pages, dark mode, responsive
    └── js/                 # main.js
```

## 🔐 Security

- PDO prepared statements for all queries (no SQL injection).
- `password_hash()` / `password_verify()` for passwords.
- CSRF tokens on all state-changing forms.
- XSS prevention via output escaping (`htmlspecialchars`).
- Secure sessions + session fixation protection on login/logout.
- Rate limiting on login attempts.
- Role-based access control (user vs admin).
- API keys stored server-side only (`.env`); never exposed to frontend.
- Payment signatures verified server-side; no card numbers/CVV stored.
- File upload restrictions (secure upload pattern).

## 🧪 Testing

Every module includes demo-mode behavior so it can be tested without API keys:
1. Open `install.php` and set up the database.
2. Register a customer account or log in with `rahul@example.com / Travel@123`.
3. Book a flight/bus/train/hotel → proceed to demo payment → view QR e-ticket.
4. Open the AI Assistant and ask: *"Plan a 5-day trip from Lucknow to Manali under ₹15,000"*.
5. Log in as admin (`admin@travelmate.ai / Admin@123`) → manage users, destinations, refunds, view reports.

## 📄 Documentation

- `docs/PROJECT-REPORT.md` — Full project report (BCA major project format).
- `docs/ER-DIAGRAM.md` — Entity-Relationship diagram (Mermaid).
- `docs/DFD.md` — Data Flow Diagrams Level 0 & Level 1.
- `docs/ARCHITECTURE.md` — System architecture.
- `docs/TESTING.md` — Test cases.
- `docs/VIVA.md` — Viva questions & answers.

## 👨‍💻 Author

BCA Final Year Major Project — TRAVELMATE AI

"Explore the World. Travel Smarter."