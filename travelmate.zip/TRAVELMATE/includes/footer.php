<?php
/**
 * TRAVELMATE AI - Footer
 */
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/functions.php';
?>
<footer>
  <div class="container">
    <div class="footer-grid">
      <div class="footer-widget">
        <div class="footer-brand">
          <div class="brand-mark">T</div>
          <span>TRAVELMATE AI</span>
        </div>
        <p class="small" style="margin-top:var(--space-sm); color:#94a3b8;">
          Your intelligent travel companion for every journey. Book smarter, travel better.
        </p>
        <div class="social-links">
          <a href="#" aria-label="Facebook">📘</a>
          <a href="#" aria-label="Instagram">📸</a>
          <a href="#" aria-label="Twitter">𝕏</a>
          <a href="#" aria-label="YouTube">▶️</a>
        </div>
      </div>

      <div class="footer-widget">
        <h4>Explore</h4>
        <ul>
          <li><a href="<?= url('destinations.php') ?>">Destinations</a></li>
          <li><a href="<?= url('booking/flights.php') ?>">Flights</a></li>
          <li><a href="<?= url('booking/buses.php') ?>">Buses</a></li>
          <li><a href="<?= url('booking/trains.php') ?>">Trains</a></li>
          <li><a href="<?= url('booking/hotels.php') ?>">Hotels</a></li>
        </ul>
      </div>

      <div class="footer-widget">
        <h4>Plan</h4>
        <ul>
          <li><a href="<?= url('ai/assistant.php') ?>">AI Travel Assistant</a></li>
          <li><a href="<?= url('ai/itinerary.php') ?>">Trip Planner</a></li>
          <li><a href="#">Weather &amp; Currency</a></li>
          <li><a href="#">Travel Buddy Finder</a></li>
          <li><a href="#">Packing Assistant</a></li>
        </ul>
      </div>

      <div class="footer-widget">
        <h4>Support</h4>
        <ul>
          <li><a href="<?= url('auth/login.php') ?>">Log in</a></li>
          <li><a href="#">Help Center</a></li>
          <li><a href="#">Refund Policy</a></li>
          <li><a href="#">Terms of Service</a></li>
          <li><a href="#">Privacy Policy</a></li>
        </ul>
      </div>

      <div class="footer-widget">
        <h4>Newsletter</h4>
        <p class="small" style="color:#94a3b8;">Subscribe for travel deals &amp; guides.</p>
        <form class="newsletter-form" onsubmit="event.preventDefault(); showToast('Subscribed!', 'success'); this.reset();">
          <input type="email" placeholder="your@email.com" required>
          <button type="submit" class="btn btn-primary btn-sm">Join</button>
        </form>
      </div>
    </div>

    <div class="footer-bottom">
      <div>
        &copy; <?= date('Y') ?> <strong>TRAVELMATE AI</strong>. All rights reserved.
      </div>
      <div>
        <span style="margin-right:var(--space-sm);">Demo Mode: <?= DEMO_MODE ? 'ON' : 'OFF' ?></span>
        <a href="#" style="color:#94a3b8;">Report an issue</a>
      </div>
    </div>
  </div>
</footer>

<?php if (strpos($_SERVER['SCRIPT_NAME'], '/admin/') === false): ?>
<script src="<?= asset('js/main.js') ?>" defer></script>
<?php endif; ?>
</body>
</html>