<?php
/**
 * TRAVELMATE AI - Header
 * Includes CSS, meta, theme init, and CSRF token.
 */
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/functions.php';

$currentPage = basename($_SERVER['SCRIPT_NAME']);
?>
<!DOCTYPE html>
<html lang="<?= e(APP_LOCALE) ?>">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="theme-color" content="#0f172a">
<title>TRAVELMATE AI | Explore the World. Travel Smarter.</title>
<meta name="description" content="TRAVELMATE AI - Your intelligent travel companion. Book flights, buses, trains and hotels with AI-powered trip planning.">

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=Playfair+Display:wght@700&display=swap" rel="stylesheet">

<link rel="stylesheet" href="<?= asset('css/variables.css') ?>">
<link rel="stylesheet" href="<?= asset('css/typography.css') ?>">
<link rel="stylesheet" href="<?= asset('css/layout.css') ?>">
<link rel="stylesheet" href="<?= asset('css/components.css') ?>">
<link rel="stylesheet" href="<?= asset('css/homepage.css') ?>">
<link rel="stylesheet" href="<?= asset('css/dashboard.css') ?>">
<link rel="stylesheet" href="<?= asset('css/booking.css') ?>">
<link rel="stylesheet" href="<?= asset('css/admin.css') ?>">
<link rel="stylesheet" href="<?= asset('css/ai.css') ?>">
<link rel="stylesheet" href="<?= asset('css/dark-mode.css') ?>">
<link rel="stylesheet" href="<?= asset('css/responsive.css') ?>">

<!-- Chart.js -->
<script src="https://cdn.jsdelivr.net/npm/chart.js@3.9.1/dist/chart.min.js"></script>
<!-- Google Maps (loaded where needed with API key) -->
<?php if (!empty(GOOGLE_MAPS_API_KEY)): ?>
<script src="https://maps.googleapis.com/maps/api/js?key=<?= e(GOOGLE_MAPS_API_KEY) ?>&libraries=<?= e(GOOGLE_MAPS_LIBRARIES) ?>" defer></script>
<?php endif; ?>

<style>
  body { font-family: 'Inter', var(--font-sans); }
  h1, h2, h3, h4, h5, h6, .display-heading, .nav-brand span, .footer-brand span { font-family: 'Playfair Display', var(--font-display); }
</style>
</head>
<body data-theme="<?= isset($_COOKIE['tm_theme']) ? e($_COOKIE['tm_theme']) : (isset($_SESSION['theme']) ? e($_SESSION['theme']) : 'light') ?>">

<?php if (strpos($_SERVER['SCRIPT_NAME'], '/auth/') === false && strpos($_SERVER['SCRIPT_NAME'], '/admin/') === false): ?>
<nav class="top-nav">
  <div class="container">
    <a href="<?= url('index.php') ?>" class="nav-brand">
      <div class="brand-mark">T</div>
      <span>TRAVELMATE AI</span>
    </a>

    <div class="nav-links">
      <a href="<?= url('index.php') ?>" class="<?= $currentPage === 'index.php' ? 'active' : '' ?>">Home</a>
      <a href="<?= url('destinations.php') ?>">Destinations</a>
      <a href="<?= url('booking/flights.php') ?>">Flights</a>
      <a href="<?= url('booking/buses.php') ?>">Buses</a>
      <a href="<?= url('booking/trains.php') ?>">Trains</a>
      <a href="<?= url('booking/hotels.php') ?>">Hotels</a>
      <a href="<?= url('ai/assistant.php') ?>">AI Assistant</a>
    </div>

    <div class="nav-actions">
      <?php if (isset($_SESSION['user_id'])): ?>
        <a href="<?= url('dashboard/index.php') ?>" class="btn btn-ghost">
          <span>Dashboard</span>
        </a>
        <button class="theme-toggle" id="themeToggle" aria-label="Toggle dark mode">🌙</button>
        <a href="<?= url('auth/logout.php') ?>" class="btn btn-outline btn-sm">Sign out</a>
      <?php else: ?>
        <a href="<?= url('auth/login.php') ?>" class="btn btn-outline btn-sm">Log in</a>
        <a href="<?= url('auth/register.php') ?>" class="btn btn-primary btn-sm">Sign up</a>
      <?php endif; ?>
    </div>

    <button class="mobile-menu-btn" id="mobileMenuBtn" aria-label="Toggle menu">☰</button>
  </div>
</nav>
<?php endif; ?>

<!-- Toast container -->
<div class="toast-container" id="toastContainer"></div>

<script>
/* ---------- Theme handling ---------- */
(function(){
  const toggle = document.getElementById('themeToggle');
  const body = document.body;
  const saved = localStorage.getItem('tm_theme');
  if (saved) { body.setAttribute('data-theme', saved); toggle.textContent = saved === 'dark' ? '☀️' : '🌙'; }
  toggle?.addEventListener('click', () => {
    const isDark = body.getAttribute('data-theme') === 'dark';
    body.setAttribute('data-theme', isDark ? 'light' : 'dark');
    localStorage.setItem('tm_theme', isDark ? 'light' : 'dark');
    toggle.textContent = isDark ? '🌙' : '☀️';
  });
})();

/* ---------- Mobile menu ---------- */
(function(){
  const btn = document.getElementById('mobileMenuBtn');
  const links = document.querySelector('.nav-links');
  if (!btn || !links) return;
  let open = false;
  btn.addEventListener('click', () => {
    open = !open;
    links.style.display = open ? 'flex' : 'none';
    links.style.flexDirection = 'column';
    links.style.position = 'absolute';
    links.style.top = '100%';
    links.style.left = '0';
    links.style.right = '0';
    links.style.background = 'var(--color-white)';
    links.style.padding = 'var(--space-lg)';
    links.style.border = 'var(--border-width) solid var(--color-border)';
    links.style.gap = 'var(--space-sm)';
  });
})();

/* ---------- Toasts ---------- */
function showToast(message, type = 'info') {
  const container = document.getElementById('toastContainer');
  if (!container) return;
  const toast = document.createElement('div');
  toast.className = 'toast toast-' + type;
  toast.innerHTML = '<span>' + message + '</span>';
  container.appendChild(toast);
  setTimeout(() => toast.remove(), 4000);
}
</script>

<?php
$flash = getFlash('auth_required') ?: getFlash('login_success') ?: getFlash('welcome') ?: getFlash('login_error') ?: getFlash('access_denied');
if ($flash): ?>
<script>showToast(<?= json_encode($flash['message']) ?>, <?= json_encode($flash['type']) ?>);</script>
<?php endif; ?>