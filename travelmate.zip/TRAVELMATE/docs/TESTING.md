# Test Cases

## 1. Authentication
| ID | Test Case | Expected Result |
|----|-----------|-----------------|
| T1 | Register with valid data | Account created, redirected to dashboard, welcome flash |
| T2 | Register with duplicate email | Error: email already registered |
| T3 | Login with correct credentials | Session created, redirected to dashboard |
| T4 | Login with wrong password | Error: invalid email/password; rate limit after 5 failures |
| T5 | Forgot password with valid email | Reset token created, link generated (demo email) |
| T6 | Reset password with expired token | Error: token expired |
| T7 | Logout | Session destroyed, redirected to login |

## 2. Booking — Flights / Buses / Trains / Hotels
| ID | Test Case | Expected Result |
|----|-----------|-----------------|
| T8 | Search flights with source/destination/date | Demo flights listed with prices |
| T9 | Search with no results | "No flights found" empty state |
| T10 | Bus seat selection (interactive) | Seats toggle selected/booked; total updates |
| T11 | Train booking | Demo PNR-style reference shown; labeled as non-official |
| T12 | Hotel room selection | Room list with price/occupancy; proceed to passengers |
| T13 | Passenger details form | All fields required; total = price × passengers |

## 3. Payment
| ID | Test Case | Expected Result |
|----|-----------|-----------------|
| T14 | Demo payment success | Booking confirmed, payment recorded, QR ticket shown |
| T15 | Razorpay/Stripe/PayPal without credentials | Falls back gracefully / demo mode notice |
| T16 | Payment with invalid data | Server-side validation error |

## 4. QR E-Ticket
| ID | Test Case | Expected Result |
|----|-----------|-----------------|
| T17 | View ticket with valid reference | Ticket displays journey, passengers, QR code |
| T18 | Verify QR via API | Returns JSON booking status |
| T19 | Ticket with invalid reference | Error: booking not found |

## 5. AI Assistant
| ID | Test Case | Expected Result |
|----|-----------|-----------------|
| T20 | Send travel query | Assistant replies (demo mode if no Gemini key) |
| T21 | "Plan a 5-day trip ... under ₹15,000" | Day-wise itinerary with cost estimates |
| T22 | Voice input (supported browser) | Speech transcribed into input field |

## 6. Admin Dashboard
| ID | Test Case | Expected Result |
|----|-----------|-----------------|
| T23 | Admin login | Admin dashboard with stats and charts |
| T24 | Add destination | Destination appears in list |
| T25 | Approve/reject review | Review is_approved updated |
| T26 | Process refund | Refund status changed; booking marked refunded |

## 7. UI/UX
| ID | Test Case | Expected Result |
|----|-----------|-----------------|
| T27 | Dark mode toggle | Theme switches and persists on refresh |
| T28 | Mobile view | Navigation collapses; cards stack |
| T29 | All navigation links | Each link resolves to a working page (no 404) |

## 8. Security
| ID | Test Case | Expected Result |
|----|-----------|-----------------|
| T30 | Access dashboard without login | Redirected to login page |
| T31 | Access admin pages as customer | Access denied |
| T32 | Submit form without CSRF token | Request rejected (403) |

**Note:** All bookings/payments are demo/simulated unless real provider credentials are configured in `.env` and `DEMO_MODE=false`.