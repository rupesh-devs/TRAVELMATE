# TRAVELMATE AI — Project Report
**BCA Final Year Major Project**  
"Explore the World. Travel Smarter."

---

## 1. Introduction

Travel planning today is fragmented: users visit separate sites for flights, buses, trains, hotels, weather, currency, and itinerary planning. TRAVELMATE AI unifies all of these into a single premium travel technology platform powered by artificial intelligence.

The platform enables users to search and book flights, buses, trains, and hotels; generate AI-driven day-wise itineraries; compare transport options; receive destination recommendations; pay via Razorpay, Stripe, or PayPal; and manage QR e-tickets through a personal dashboard. Administrators manage users, inventory, reviews, refunds, and view revenue analytics.

## 2. Objectives

1. Build a responsive, premium UI/UX travel website with dark/light mode.
2. Implement a secure authentication and authorization system (users + admins).
3. Provide flight, bus, train, and hotel booking with simulated demo inventory.
4. Integrate Google Gemini AI as a travel assistant (chat, itinerary, packing, budgeting).
5. Integrate Google Maps, weather, and currency exchange.
6. Implement Razorpay (India), Stripe, and PayPal payments in sandbox/demo mode.
7. Generate QR-based e-tickets verifiable on the backend.
8. Build a digital wallet with reward points and refund tracking.
9. Provide a full-featured admin dashboard with Chart.js analytics.
10. Follow security best practices: PDO, password hashing, CSRF, XSS prevention.

## 3. Scope

- **Users**: Register, log in, search/book travel, manage profile, wallet, wishlist, itineraries, view QR tickets, request cancellations/refunds.
- **AI Assistant**: Text/voice chat (Hindi & English), trip planning, budget estimates, packing lists.
- **Admin**: Manage users, destinations, transport, hotels, reviews, refunds, reports.
- **Demo Mode**: All inventory and payments are simulated when live API credentials are not configured. Clearly labeled throughout.

## 4. Methodology

Development followed a phased approach:

| Phase | Deliverable |
|-------|-------------|
| 1 | Project architecture, database schema, configuration |
| 2 | Premium responsive UI/UX (CSS, homepage, navigation) |
| 3 | Authentication system + database integration |
| 4 | Booking modules (flight, bus, train, hotel) |
| 5 | Gemini AI integration (server-side proxy) |
| 6 | Maps, weather, currency |
| 7 | Payment integrations (Razorpay, Stripe, PayPal) |
| 8 | QR e-tickets, digital wallet, cancellations |
| 9 | Admin dashboard with charts |
| 10 | Security hardening & testing |
| 11 | Documentation (report, ER, DFD, testing, viva) |

## 5. System Requirements

### Hardware
- Processor: Dual-core 2.0 GHz or higher
- RAM: 4 GB minimum (8 GB recommended)
- Storage: 20 GB free space

### Software
- OS: Windows / Linux / macOS
- Web Server: Apache / Nginx (XAMPP/WAMP/LAMP)
- PHP: 8.0+ with cURL, PDO MySQL, mbstring, json extensions
- Database: MySQL 5.7 / 8.0
- Browser: Chrome, Firefox, Edge, Safari (latest)

## 6. Database Architecture

The database `travelmate` contains 27 normalized tables including:

`users`, `admins`, `destinations`, `flights`, `buses`, `trains`, `hotels`, `hotel_rooms`, `bookings`, `passengers`, `payments`, `payment_events`, `refunds`, `reviews`, `itineraries`, `trip_expenses`, `group_trips`, `group_members`, `travel_buddies`, `notifications`, `rewards`, `reward_transactions`, `wishlists`, `packing_checklists`, `packing_items`, `emergency_contacts`, `user_preferences`, `search_history`, `cancellation_requests`, `password_resets`.

All tables use InnoDB, foreign keys with cascading deletes, and indexes on frequently queried columns. See `database.sql` for the complete schema.

## 7. Modules

### 7.1 Homepage
Rotating world-destination hero with landmarks, popular/trending destinations, booking tiles (flight/train/bus/hotel), travel packages, AI assistant preview, testimonials, inspiration gallery, newsletter, professional footer.

### 7.2 Authentication
Registration with full name, email, mobile, country, password, terms acceptance. Login with remember-me and show/hide password. Forgot/reset password with secure tokens. Passwords hashed with `password_hash()`. CSRF protection and login rate limiting.

### 7.3 User Dashboard
Welcome message, profile, upcoming trips, recent bookings, wallet balance, reward points, notifications, quick actions.

### 7.4 Booking Modules
- **Flights**: Source/destination, dates, passengers, class, airline, price comparison, QR ticket.
- **Buses**: Source/destination, date, AC/non-AC, sleeper/seater, interactive seat selection.
- **Trains**: Source/destination stations, date, train name/number, class, demo PNR-style reference (labeled as non-official).
- **Hotels**: Destination, dates, guests, photos, ratings, amenities, room selection.

### 7.5 AI Travel Assistant
Server-side proxy to Google Gemini API (key never exposed). Text chat, Web Speech API voice input/output, Hindi & English, personalized recommendations, budget-based suggestions, itineraries, packing checklists, conversation history in session.

### 7.6 Smart Trip Planner
Inputs: start city, destination, dates, budget, interests, travellers. Output: day-wise schedule, attractions, transport/food/hotel estimates, total budget. Save and edit itineraries.

### 7.7 Payments
Demo mode by default. Razorpay, Stripe, and PayPal integrations with sandbox credentials. Server-side signature/webhook verification. Payment receipts, refund requests, transaction history. No card numbers or CVV stored.

### 7.8 QR E-Tickets
Unique booking reference (e.g., TMX9F2K1L8), QR code generated via QR server API, backend verification endpoint (`api/verify-qr.php`), printable ticket.

### 7.9 Admin Dashboard
Stats cards, Chart.js revenue and booking charts, recent bookings, user/destination/transport/hotel management, review approval, refund processing, reports.

## 8. Security

- PDO prepared statements for every query.
- `password_hash(PASSWORD_DEFAULT)` + `password_verify()`.
- CSRF tokens on all POST/PUT/DELETE requests.
- Output escaping to prevent XSS.
- Secure cookies (HttpOnly, SameSite), session regeneration on login/logout.
- Login rate limiting.
- Role-based access control (`requireAuth()`, `requireAdmin()`).
- Server-side validation on all inputs.
- Payment signatures verified; webhook validation scaffolding.
- API keys stored in `.env`, excluded from version control.

## 9. Testing Approach

- Unit-level: each PHP page loads without errors; database queries return expected results.
- Form testing: all auth and booking forms submit and validate.
- Payment testing: demo payments succeed; Razorpay/Stripe/PayPal fall back gracefully when credentials absent.
- Responsiveness: tested layout on mobile, tablet, desktop breakpoints.
- Dark mode: theme toggle persists via `localStorage`.

See `docs/TESTING.md` for detailed test cases.

## 10. Limitations & Future Scope

- Demo inventory is not connected to live GDS/airline/railway systems.
- Real payments require sandbox/live provider credentials.
- Future: mobile app, live provider integration, multilingual content translation, travel insurance, visa assistance.

## 11. Conclusion

TRAVELMATE AI delivers a complete, secure, premium travel platform suitable as a BCA major project, demonstrating full-stack development, API integration, database design, security, and AI-assisted user experience.