# Data Flow Diagrams

## DFD Level 0 — Context Diagram

```
                     +-----------------------------+
                     |        USER / CUSTOMER       |
                     |                             |
                     +------------+----------------+
                                  |
                    +-------------v--------------+
                    |                            |
                    v                            v
          +-------------------+        +-------------------+
          |   TRAVELMATE AI   |<------>|  External APIs    |
          |   Platform        |        | (Gemini, Maps,    |
          |                   |        | Weather, Currency,|
          |                   |        | Razorpay, Stripe, |
          |                   |        | PayPal)           |
          +-------------------+        +-------------------+
                    ^
                    |
          +---------+---------+
          |                   |
          v                   v
   +---------------+  +-----------------+
   | ADMINISTRATOR |  |   PAYMENT       |
   |               |  |   PROVIDERS     |
   +---------------+  +-----------------+
```

**Entities:**
- **User / Customer**: Searches books, pays, manages trips.
- **Administrator**: Manages platform content and users.
- **External APIs**: Gemini AI, Google Maps, Weather, Currency exchange.
- **Payment Providers**: Razorpay, Stripe, PayPal.

**Data flows:** User requests and payments enter the platform; platform sends queries to external APIs and payment providers; responses and confirmations return to the user.

---

## DFD Level 1 — Major Processes

```
P1: Authentication & Profile
   Input: Registration/Login credentials
   Output: Session, user profile
   Data stores: users, user_preferences

P2: Destination & Inventory Search
   Input: Search criteria (route, dates, guests)
   Output: Available destinations, flights, buses, trains, hotels
   Data stores: destinations, flights, buses, trains, hotels

P3: Booking & Passenger Details
   Input: Selected inventory, passenger info
   Output: Pending booking reference
   Data stores: bookings, passengers

P4: Payment Processing
   Input: Payment method, card/wallet details (via provider)
   Output: Payment success/failure, confirmed booking, QR ticket
   Data stores: payments, bookings, payment_events

P5: AI Travel Assistant
   Input: User query (text/voice)
   Output: Itinerary, recommendations, packing list
   Data stores: itineraries (via Gemini API)

P6: Ticket & Wallet Management
   Input: Booking reference, QR scan
   Output: Ticket status, wallet balance, reward points
   Data stores: bookings, rewards, reward_transactions

P7: Cancellation & Refund
   Input: Cancellation request
   Output: Refund status
   Data stores: refunds, cancellation_requests

P8: Administration
   Input: Admin actions (CRUD inventory, approve reviews/refunds)
   Output: Updated platform data
   Data stores: all tables
```

**Data Stores (Level 1):**
- `D1 users` — accounts and profiles
- `D2 destinations & inventory` — flights, buses, trains, hotels
- `D3 bookings & passengers` — travel reservations
- `D4 payments & refunds` — transactions and refunds
- `D5 AI & itineraries` — assistant conversations and trip plans
- `D6 admin & analytics` — admin actions, reports

**Key Data Flows:**
1. User → P1: login credentials → D1: validate → Session
2. User → P2: search criteria → D2: inventory results
3. User → P3: booking details → D3: pending booking
4. P3 → P4: payment request → Payment Provider → D4: confirmed payment → QR ticket
5. User → P5: travel query → Gemini API → itinerary → D5
6. Admin → P8: inventory/content updates → all data stores