# System Architecture

## Architecture Style
Layered, three-tier architecture: Presentation → Application (Business Logic) → Data.

```
+-------------------------------------------------------------------+
|                     CLIENT LAYER (Browser)                        |
|                                                                   |
|  [HTML5/CSS3/JS]  [Bootstrap-style CSS]  [Chart.js]               |
|  [Google Maps JS]  [Web Speech API]   [Fetch API]                |
+-------------------------------------------------------------------+
                           | HTTPS
+-------------------------------------------------------------------+
|                  PRESENTATION LAYER (PHP Views)                   |
|                                                                   |
|  index.php  destinations.php  booking/*  ai/*                     |
|  dashboard/*  admin/*  auth/*  includes/header-footer             |
+-------------------------------------------------------------------+
                           | include/require
+-------------------------------------------------------------------+
|                 APPLICATION / BUSINESS LAYER (PHP)                |
|                                                                   |
|  config/config.php       App constants, env loader                |
|  config/database.php     PDO connection & queries                 |
|  config/auth.php         Register/login/password reset            |
|  config/functions.php    Helpers: flash, CSRF, money, dates       |
|  config/csrf.php         CSRF protection                          |
|  api/gemini.php          Gemini AI proxy (server-side)            |
|  api/weather.php         Weather proxy                            |
|  api/currency.php        Currency proxy                           |
|  api/verify-qr.php       QR ticket verification                   |
|  api/payments/*          Razorpay/Stripe/PayPal webhooks          |
+-------------------------------------------------------------------+
                           | PDO / SQL
+-------------------------------------------------------------------+
|                      DATA LAYER (MySQL 8)                         |
|                                                                   |
|  27 normalized tables (users, bookings, payments, ...)           |
+-------------------------------------------------------------------+

External Services (server-side only):
- Google Gemini API (AI)
- Google Maps API (maps, places)
- OpenWeatherMap (weather)
- ExchangeRate-API (currency)
- Razorpay, Stripe, PayPal (payments)

Security boundary: All API keys live in .env on the server; frontend never sees them.
```

## Data Flow (Typical Booking)

1. User submits booking form → `booking/passenger-details.php`
2. Form posts to `booking/payment.php` → creates `bookings` (pending) + `payments` record in a transaction
3. User selects provider (demo/Razorpay/Stripe/PayPal) → provider checkout
4. Provider webhook / return verifies payment server-side → `payments.status = success`, `bookings.status = confirmed`
5. QR code generated and stored on booking; user redirected to `booking/ticket.php?ref=xxx`
6. Ticket verifiable via `api/verify-qr.php?ref=xxx`

## Security Controls by Layer

- **Presentation**: CSRF tokens, output escaping, HTTPS-only cookies.
- **Application**: PDO prepared statements, password hashing, rate limiting, role checks, server-side validation.
- **Data**: Foreign keys, indexes, least-privilege DB user, `.env` credentials excluded from VCS.