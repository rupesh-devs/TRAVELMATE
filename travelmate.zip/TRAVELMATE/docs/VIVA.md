# Viva Questions & Answers

**Q1. What is TRAVELMATE AI?**  
A: TRAVELMATE AI is a full-stack travel management and booking platform that lets users search and book flights, buses, trains, and hotels, plan AI-powered itineraries, pay online, and manage QR e-tickets — all through a premium responsive interface.

**Q2. What is the technology stack?**  
A: Frontend — HTML5, CSS3, JavaScript. Backend — PHP 8+ with MySQL and PDO. Integrations — Google Gemini AI, Google Maps, Weather API, Currency API, Razorpay, Stripe, PayPal, Chart.js.

**Q3. How are passwords secured?**  
A: Passwords are hashed using PHP's `password_hash()` with bcrypt and verified with `password_verify()`. Sessions are secure, and CSRF tokens protect state-changing requests.

**Q4. How does the AI assistant work without exposing the API key?**  
A: A server-side proxy (`api/gemini.php`) holds the Gemini API key. The frontend only calls the proxy, which forwards the user message and returns the model's reply.

**Q5. Are payments real?**  
A: By default (`DEMO_MODE=true`) payments are simulated. Razorpay, Stripe, and PayPal integrations are included for sandbox/live use when credentials are configured. No card numbers or CVV are stored.

**Q6. What is the purpose of the QR code on tickets?**  
A: Each booking gets a unique reference encoded in a QR code. The backend endpoint `api/verify-qr.php` verifies the reference and returns the booking status, enabling ticket validation.

**Q7. How is the database structured?**  
A: 27 normalized InnoDB tables with primary keys, foreign keys (cascade/set null), and indexes. Core tables include users, bookings, payments, destinations, flights, buses, trains, hotels, refunds, reviews, itineraries, rewards.

**Q8. Is the train booking official?**  
A: No. Train bookings are clearly labeled as simulated demo data. The platform is not affiliated with Indian Railways and does not issue official railway tickets.

**Q9. What does the admin dashboard do?**  
A: Admins manage users, destinations, transport, hotels, reviews, and refunds, and view revenue and booking analytics using Chart.js.

**Q10. How does dark mode work?**  
A: A theme toggle sets `data-theme="dark"` on the body and stores the preference in `localStorage`; CSS variables adapt colors automatically.

**Q11. What currencies are supported?**  
A: INR, USD, EUR, GBP, AED, AUD, CAD, SGD — with live or demo exchange rates.

**Q12. How do refunds work?**  
A: Users request cancellations; an admin approves/processes the refund, which updates the payment and marks the booking as refunded. Refund status is trackable.