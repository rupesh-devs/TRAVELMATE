# Entity-Relationship Diagram (ER Diagram)

```mermaid
erDiagram
    users ||--o{ bookings : places
    users ||--o{ payments : makes
    users ||--o{ rewards : earns
    users ||--o{ reward_transactions : transacts
    users ||--o{ wishlists : saves
    users ||--o{ itineraries : creates
    users ||--o{ trip_expenses : logs
    users ||--o{ packing_checklists : owns
    users ||--o{ emergency_contacts : lists
    users ||--o{ user_preferences : configures
    users ||--o{ search_history : searches
    users ||--o{ notifications : receives
    users ||--o{ travel_buddies : owns
    users ||--o{ reviews : writes
    users ||--o{ group_members : joins

    admins ||--o{ bookings : manages

    bookings ||--o{ passengers : has
    bookings ||--o{ payments : pays_for
    bookings ||--o{ refunds : refunds_for
    bookings ||--o{ cancellation_requests : cancels

    payments ||--o{ payment_events : logs
    payments ||--o{ refunds : refunds_from

    destinations ||--o{ hotels : contains
    destinations ||--o{ reviews : reviewed
    destinations ||--o{ wishlists : wished

    hotels ||--o{ hotel_rooms : offers
    hotels ||--o{ reviews : reviewed
    hotels ||--o{ wishlists : wished

    flights }o--|| bookings : booked_via
    buses }o--|| bookings : booked_via
    trains }o--|| bookings : booked_via

    itineraries ||--o{ packing_checklists : generates
    trip_expenses }o--|| itineraries : belongs_to

    packing_checklists ||--o{ packing_items : contains

    group_trips ||--o{ group_members : has
```

## Tables Summary

| Table | Purpose |
|-------|---------|
| `users` | Customer accounts |
| `admins` | Admin staff accounts |
| `destinations` | Travel destinations (domestic/international) |
| `flights` | Simulated flight inventory |
| `buses` | Simulated bus inventory |
| `trains` | Simulated train inventory |
| `hotels` | Simulated hotel inventory |
| `hotel_rooms` | Room types per hotel |
| `bookings` | Master booking record |
| `passengers` | Passenger details per booking |
| `payments` | Payment transactions |
| `payment_events` | Webhook event log |
| `refunds` | Refund requests |
| `reviews` | User reviews/ratings |
| `itineraries` | AI-generated trip plans |
| `trip_expenses` | Expense tracking |
| `group_trips` / `group_members` | Group travel planning |
| `travel_buddies` | Buddy finder profiles |
| `notifications` | System notifications |
| `rewards` / `reward_transactions` | Loyalty points |
| `wishlists` | Saved destinations/hotels |
| `packing_checklists` / `packing_items` | Packing lists |
| `emergency_contacts` | Emergency contact details |
| `user_preferences` | Currency, language, theme |
| `search_history` | Past searches |
| `cancellation_requests` | Cancellation tracking |
| `password_resets` | Password reset tokens |

All primary keys are auto-increment integers; foreign keys enforce referential integrity with `ON DELETE CASCADE`/`SET NULL`.