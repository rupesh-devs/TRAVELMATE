<?php
/**
 * TRAVELMATE AI - Bus Seat Selection (demo)
 */
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../config/auth.php';

$busId = (int) ($_GET['id'] ?? 0);
$price = (float) ($_GET['price'] ?? 0);
$bus = Database::queryOne('SELECT * FROM buses WHERE id = ? AND is_demo = 1', [$busId]);

if (!$bus) {
  setFlash('access_denied', 'Bus not found.', 'error');
  redirect('booking/buses.php');
}

// 40 seats: 4 per row (2-2 layout), aisle after seat 2
$totalSeats = 40;
$bookedSeats = [5, 12, 19, 26, 33]; // simulated already-booked
$selected = isset($_SESSION['temp_bus_seats']) ? $_SESSION['temp_bus_seats'] : [];
?>
<div class="container">
  <div class="booking-search">
    <h1>🚌 Select Seats</h1>
    <p class="small"><?= e($bus['source']) ?> → <?= e($bus['destination']) ?> &bull; <?= date('d M, H:i', strtotime($bus['departure_time'])) ?></p>
  </div>

  <div class="glass" style="max-width:700px;margin:0 auto var(--space-xl);">
    <div class="seat-map">
      <div class="driver-seat">🚎 Driver</div>
      <div class="bus-diagram">
        <div class="seat-rows">
          <?php for ($row = 0; $row < 10; $row++): ?>
            <div class="seat-row">
              <?php for ($col = 0; $col < 4; $col++): ?>
                <?php $seatNo = $row * 4 + $col + 1; ?>
                <?php $isAisle = $col === 1 ? ' class="aisle"' : ''; ?>
                <?php
                  $isBooked = in_array($seatNo, $bookedSeats);
                  $isSelected = in_array($seatNo, $selected);
                  $cls = 'seat';
                  if ($isBooked) $cls .= ' booked';
                  elseif ($isSelected) $cls .= ' selected';
                  else $cls .= ' available';
                ?>
                <div class="seat<?= $isBooked ? ' booked' : '' ?>" data-seat="<?= $seatNo ?>" <?= $isBooked ? '' : 'onclick="toggleSeat(' . $seatNo . ')"' ?>><?= $seatNo ?></div>
                <?php if ($col === 1): echo '<div class="seat aisle" style="width:24px;"></div>'; endif; ?>
              <?php endfor; ?>
            </div>
          <?php endfor; ?>
        </div>
      </div>
      <div class="seat-legend">
        <div class="legend-item"><div class="legend-color" style="background:var(--color-white);border-color:var(--color-border);"></div>Available</div>
        <div class="legend-item"><div class="legend-color" style="background:var(--color-gold-dark);"></div>Selected</div>
        <div class="legend-item"><div class="legend-color" style="background:var(--color-muted);"></div>Booked</div>
      </div>
      <div style="margin-top:var(--space-lg);">
        <p class="small">Selected seats: <span id="selectedCount"><?= count($selected) ?></span> &bull; Total: <span id="totalAmount"><?= money(count($selected) * $price) ?></span></p>
        <?php if (isset($_SESSION['user_id'])): ?>
          <a href="<?= url('booking/passenger-details.php?type=bus&bus=' . $busId . '&price=' . $price) ?>" class="btn btn-primary btn-full" id="proceedBtn" <?= count($selected) === 0 ? 'disabled' : '' ?>>Proceed to Passengers</a>
        <?php else: ?>
          <p class="small">Please <a href="<?= url('auth/login.php') ?>">log in</a> to continue.</p>
        <?php endif; ?>
      </div>
    </div>
  </div>
</div>

<script>
let selected = <?= json_encode($selected) ?>;
function toggleSeat(n) {
  const idx = selected.indexOf(n);
  const el = document.querySelector('.seat[data-seat="' + n + '"]');
  if (el.classList.contains('booked')) return;
  if (idx >= 0) { selected.splice(idx, 1); el.classList.remove('selected'); }
  else { selected.push(n); el.classList.add('selected'); }
  update();
}
function update() {
  document.getElementById('selectedCount').textContent = selected.length;
  document.getElementById('totalAmount').textContent = '<?= money(0, 'INR') ?>'.replace('0', selected.length * <?= $price ?>);
  const btn = document.getElementById('proceedBtn');
  btn.disabled = selected.length === 0;
  <?php $_SESSION['temp_bus_seats'] = $selected; // placeholder; actual update via AJAX below ?>
}
async function saveSeats() {
  await fetch('api/save-bus-seats.php', {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({bus: <?= $busId ?>, seats: selected, price: <?= $price ?>, csrf_token: '<?= csrfToken() ?>'})
  });
}
saveSeats();
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>