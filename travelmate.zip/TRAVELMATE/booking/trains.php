<?php
/**
 * TRAVELMATE AI - Train Booking (demo data from database)
 */
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../config/auth.php';

$trains = [];
$filters = ['source' => '', 'destination' => '', 'date' => '', 'class' => 'sleeper'];

if ($_SERVER['REQUEST_METHOD'] === 'GET' && !empty($_GET['search'])) {
  $filters = [
    'source' => trim($_GET['source'] ?? ''),
    'destination' => trim($_GET['destination'] ?? ''),
    'date' => $_GET['date'] ?? '',
    'class' => $_GET['class'] ?? 'sleeper',
  ];

  $sql = "SELECT * FROM trains WHERE is_demo = 1 AND status = 'scheduled'";
  $params = [];
  if ($filters['source']) { $sql .= " AND source = ?"; $params[] = $filters['source']; }
  if ($filters['destination']) { $sql .= " AND destination = ?"; $params[] = $filters['destination']; }
  $sql .= " ORDER BY train_number ASC";

  $trains = Database::query($sql, $params);
}
?>
<div class="container">
  <div class="booking-search">
    <h1>🚆 Train Booking</h1>
    <p class="small">Indian Railways-style simulated booking. <strong>This is a demo — not an official railway ticket.</strong></p>
  </div>

  <div class="glass" style="max-width:700px;margin:0 auto var(--space-xl);">
    <form method="GET" action="" class="search-form">
      <input type="hidden" name="search" value="1">
      <div class="input-group">
        <label>From station</label>
        <input type="text" name="source" class="form-control" placeholder="e.g. New Delhi" required value="<?= e($filters['source']) ?>">
      </div>
      <div class="input-group">
        <label>To station</label>
        <input type="text" name="destination" class="form-control" placeholder="e.g. Goa" required value="<?= e($filters['destination']) ?>">
      </div>
      <div class="input-group">
        <label>Journey date</label>
        <input type="date" name="date" class="form-control" required value="<?= e($filters['date']) ?>">
      </div>
      <div class="input-group">
        <label>Class</label>
        <select name="class" class="form-select">
          <option value="sleeper" <?= $filters['class'] === 'sleeper' ? 'selected' : '' ?>>Sleeper (SL)</option>
          <option value="3ac" <?= $filters['class'] === '3ac' ? 'selected' : '' ?>>3 AC</option>
          <option value="2ac" <?= $filters['class'] === '2ac' ? 'selected' : '' ?>>2 AC</option>
          <option value="1ac" <?= $filters['class'] === '1ac' ? 'selected' : '' ?>>1 AC</option>
        </select>
      </div>
      <button type="submit" class="btn btn-primary btn-full btn-lg">Search Trains</button>
    </form>
  </div>

  <?php if ($_SERVER['REQUEST_METHOD'] === 'GET' && !empty($_GET['search'])): ?>
    <div class="results-header">
      <h2>Available Trains</h2>
      <p class="small">Simulated demo data — not official Indian Railways inventory.</p>
    </div>
    <div class="grid grid-1">
      <?php if ($trains): foreach ($trains as $t): ?>
        <div class="result-card">
          <div class="result-image">
            <img src="https://images.unsplash.com/photo-1528381969242-07f7be457141?auto=format&fit=crop&w=600&q=80" alt="Train">
          </div>
          <div class="result-body">
            <div class="provider"><?= e($t['train_name']) ?> &bull; <?= e($t['train_number']) ?></div>
            <h3><?= e($t['source']) ?> → <?= e($t['destination']) ?></h3>
            <div class="meta">
              <span>🕐 <?= e($t['departure_time']) ?></span>
              <span>🕑 <?= e($t['arrival_time']) ?></span>
              <span>⏱ <?= e($t['duration']) ?></span>
            </div>
            <?php
            $priceMap = ['sleeper' => $t['price_sleeper'], '3ac' => $t['price_3ac'], '2ac' => $t['price_2ac'], '1ac' => $t['price_1ac']];
            $price = $priceMap[$filters['class']] ?? $t['price_sleeper'];
            ?>
            <div class="price"><?= money($price, 'INR') ?></div>
          </div>
          <div class="result-actions">
            <span class="badge badge-info">Demo PNR style</span>
            <a href="<?= url('booking/passenger-details.php?type=train&id=' . $t['id'] . '&price=' . $price . '&class=' . $filters['class']) ?>" class="btn btn-primary btn-full">Book Seat</a>
          </div>
        </div>
      <?php endforeach; else: ?>
        <div class="empty-state" style="grid-column:1/-1;">
          <div class="icon">🚆</div>
          <h3 style="font-size:var(--text-lg);">No trains found</h3>
          <p class="small">Try adjusting your search criteria.</p>
        </div>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>