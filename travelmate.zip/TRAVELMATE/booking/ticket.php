<?php
/**
 * TRAVELMATE AI - QR E-Ticket
 */
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../config/auth.php';

$ref = $_GET['ref'] ?? '';
if (!$ref) {
  setFlash('access_denied', 'No ticket reference provided.', 'error');
  redirect('dashboard/index.php');
}

$booking = Database::queryOne('SELECT * FROM bookings WHERE reference = ?', [$ref]);
if (!$booking) {
  setFlash('access_denied', 'Booking not found.', 'error');
  redirect('dashboard/index.php');
}

// Ensure ownership (or admin)
if ((int) $booking['user_id'] !== (int) $_SESSION['user_id'] && !isAdmin()) {
  setFlash('access_denied', 'You do not own this booking.', 'error');
  redirect('dashboard/index.php');
}

$passengers = Database::query('SELECT * FROM passengers WHERE booking_id = ? ORDER BY id', [(int) $booking['id']]);
$payment = Database::queryOne('SELECT * FROM payments WHERE booking_id = ? ORDER BY created_at DESC LIMIT 1', [(int) $booking['id']]);
$bookingData = json_decode($booking['booking_data'] ?? '{}', true);

// QR data for verification
$qrPayload = json_encode([
  'ref' => $booking['reference'],
  'booking_id' => (int) $booking['id'],
  'user_id' => (int) $booking['user_id'],
  'type' => $booking['booking_type']
]);
$qrUrl = 'https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=' . urlencode($qrPayload);

if (!$booking['qr_code_url']) {
  Database::execute('UPDATE bookings SET qr_code_url = ?, qr_verified = 1 WHERE id = ?', [$qrUrl, (int) $booking['id']]);
}
?>
<div class="container">
  <div class="dashboard-header">
    <h1>🎫 Your E-Ticket</h1>
    <a href="<?= url('dashboard/bookings.php') ?>" class="btn btn-outline">← Back to bookings</a>
  </div>

  <div class="ticket" style="max-width:640px;margin:0 auto;">
    <div class="ticket-header">
      <div style="font-size:var(--text-xs);letter-spacing:0.1em;opacity:0.9;">TRAVELMATE AI &bull; ELECTRONIC TICKET</div>
      <h3 style="margin:var(--space-sm) 0 var(--space-xs);"><?= ucfirst(e($booking['booking_type'])) ?> Ticket</h3>
      <div class="small">Reference: <strong><?= e($booking['reference']) ?></strong></div>
    </div>

    <div class="ticket-body">
      <div class="ticket-section">
        <h4>Journey</h4>
        <div class="ticket-row"><span class="label">From</span><span class="value"><?= e($booking['source'] ?? '-') ?></span></div>
        <div class="ticket-row"><span class="label">To</span><span class="value"><?= e($booking['destination']) ?></span></div>
        <div class="ticket-row"><span class="label">Date</span><span class="value"><?= $booking['journey_date'] ? travelDate($booking['journey_date']) : '-' ?></span></div>
      </div>
      <div class="ticket-section">
        <h4>Booking</h4>
        <div class="ticket-row"><span class="label">Status</span><span class="value badge-<?= $booking['status'] === 'confirmed' ? 'success' : 'warning' ?>"><?= ucfirst(e($booking['status'])) ?></span></div>
        <div class="ticket-row"><span class="label">Payment</span><span class="value badge-<?= $booking['payment_status'] === 'paid' ? 'success' : 'warning' ?>"><?= ucfirst(e($booking['payment_status'])) ?></span></div>
        <div class="ticket-row"><span class="label">Amount</span><span class="value"><?= money($booking['total_amount'], $booking['currency']) ?></span></div>
      </div>
    </div>

    <div class="ticket-qr">
      <img src="<?= e($qrUrl) ?>" alt="QR Code" class="qr-code">
      <div class="small">Scan to verify booking</div>
      <div class="small" style="word-break:break-all;"><?= e($booking['reference']) ?></div>
    </div>

    <div class="ticket-footer">
      <div class="ticket-section">
        <h4>Passengers</h4>
        <?php if ($passengers): foreach ($passengers as $p): ?>
          <div class="ticket-row" style="font-size:var(--text-xs);"><span class="label"><?= e($p['full_name']) ?></span><span class="value"><?= e($p['seat_number'] ?? '-') ?></span></div>
        <?php endforeach; else: ?>
          <div class="small">Passenger details on record.</div>
        <?php endif; ?>
      </div>
      <div style="border-top:var(--border-width) solid var(--color-border);margin-top:var(--space-md);padding-top:var(--space-md);">
        <p class="small">This is a simulated demo ticket. Not valid for actual travel without a live provider integration.</p>
      </div>
    </div>
  </div>

  <div style="text-align:center;margin-top:var(--space-lg);">
    <a href="<?= url('booking/ticket.php?ref=' . $ref) ?>" class="btn btn-outline btn-sm" onclick="window.print();return false;">🖨️ Print Ticket</a>
    <a href="<?= url('api/verify-qr.php?ref=' . $ref) ?>" class="btn btn-ghost btn-sm">Verify QR</a>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>