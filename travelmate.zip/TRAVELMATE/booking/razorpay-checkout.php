<?php
/**
 * TRAVELMATE AI - Razorpay Checkout (sandbox)
 */
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../config/auth.php';
requireAuth();

$orderId = $_GET['order_id'] ?? '';
$paymentId = (int) ($_GET['payment_id'] ?? 0);

if (!$orderId || !$paymentId) {
  setFlash('access_denied', 'Invalid Razorpay order.', 'error');
  redirect('dashboard/bookings.php');
}

$payment = Database::queryOne('SELECT * FROM payments WHERE id = ?', [$paymentId]);
$booking = Database::queryOne('SELECT * FROM bookings WHERE id = ?', [(int) $payment['booking_id']]);
?>
<div class="container">
  <div class="booking-search">
    <h1>🏦 Razorpay Checkout</h1>
    <p class="small">Sandbox mode — no real money is charged.</p>
  </div>

  <div class="glass" style="max-width:520px;margin:0 auto;">
    <form id="razorpayForm" action="<?= url('api/payments/razorpay-webhook.php') ?>" method="POST" style="display:none;">
      <?= csrfField() ?>
      <input type="hidden" name="payment_id" value="<?= $paymentId ?>">
      <input type="hidden" name="razorpay_order_id" id="rzpOrderId" value="<?= e($orderId) ?>">
      <input type="hidden" name="razorpay_payment_id" id="rzpPaymentId">
      <input type="hidden" name="razorpay_signature" id="rzpSignature">
    </form>

    <div class="card">
      <div class="card-body">
        <h3>Pay via Razorpay</h3>
        <p class="small">Order: <?= e($reference = $booking['reference'] ?? '') ?></p>
        <p class="small">Amount: <?= money($payment['amount'], $payment['currency']) ?></p>
        <button id="rzpPayBtn" class="btn btn-primary btn-full btn-lg">Pay Now</button>
        <p class="small mt-3">Or <a href="<?= url('booking/payment.php') ?>">use demo payment</a>.</p>
      </div>
    </div>
  </div>
</div>

<script src="https://checkout.razorpay.com/v1/checkout.js"></script>
<script>
const options = {
  key: '<?= e(RAZORPAY_KEY_ID) ?>',
  amount: <?= (int) ($payment['amount'] * 100) ?>,
  currency: '<?= e($payment['currency']) ?>',
  name: 'TRAVELMATE AI',
  description: 'Booking <?= e($booking['reference'] ?? '') ?>',
  order_id: '<?= e($orderId) ?>',
  handler: function (response) {
    document.getElementById('rzpPaymentId').value = response.razorpay_payment_id;
    document.getElementById('rzpSignature').value = response.razorpay_signature;
    document.getElementById('razorpayForm').submit();
  },
  theme: { color: '#f59e0b' }
};
document.getElementById('rzpPayBtn').addEventListener('click', function (e) {
  e.preventDefault();
  const rzp = new Razorpay(options);
  rzp.open();
});
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>