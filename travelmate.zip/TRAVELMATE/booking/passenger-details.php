<?php
/**
 * TRAVELMATE AI - Passenger Details & Booking Summary
 */
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../config/auth.php';
requireAuth();

$userId = (int) $_SESSION['user_id'];
$type = $_GET['type'] ?? ''; // flight, bus, train, hotel
$id = (int) ($_GET['id'] ?? 0);
$price = (float) ($_GET['price'] ?? 0);
$class = $_GET['class'] ?? '';
$busId = (int) ($_GET['bus'] ?? 0);
$hotelId = (int) ($_GET['hotel'] ?? 0);
$roomId = (int) ($_GET['room'] ?? 0);
$checkin = $_GET['checkin'] ?? '';
$checkout = $_GET['checkout'] ?? '';
$guests = (int) ($_GET['guests'] ?? 1);
$busSeats = isset($_SESSION['temp_bus_seats']) ? $_SESSION['temp_bus_seats'] : [];

$itemName = '';
$itemImage = '';
$journeyDate = '';

if ($type === 'flight') {
  $f = Database::queryOne('SELECT * FROM flights WHERE id = ?', [$id]);
  $itemName = $f ? $f['airline'] . ' ' . $f['flight_number'] : 'Flight';
  $itemImage = 'https://images.unsplash.com/photo-1436491865332-7a61a1d0c067?auto=format&fit=crop&w=600&q=80';
  $journeyDate = $f ? date('Y-m-d', strtotime($f['departure_time'])) : '';
} elseif ($type === 'bus') {
  $b = Database::queryOne('SELECT * FROM buses WHERE id = ?', [$busId]);
  $itemName = $b ? $b['operator'] . ' ' . $b['bus_number'] : 'Bus';
  $itemImage = 'https://images.unsplash.com/photo-1552454612-e95ea719c2c7?auto=format&fit=crop&w=600&q=80';
  $journeyDate = $b ? date('Y-m-d', strtotime($b['departure_time'])) : '';
} elseif ($type === 'train') {
  $t = Database::queryOne('SELECT * FROM trains WHERE id = ?', [$id]);
  $itemName = $t ? $t['train_name'] . ' (' . $t['train_number'] . ')' : 'Train';
  $itemImage = 'https://images.unsplash.com/photo-1528381969242-07f7be457141?auto=format&fit=crop&w=600&q=80';
  $journeyDate = $_GET['date'] ?? date('Y-m-d');
} elseif ($type === 'hotel') {
  $h = Database::queryOne('SELECT * FROM hotels WHERE id = ?', [$hotelId]);
  $itemName = $h ? $h['name'] : 'Hotel';
  $itemImage = $h ? $h['image_url'] : 'https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?auto=format&fit=crop&w=600&q=80';
  $journeyDate = $checkin;
}

$passengerCount = $type === 'hotel' ? $guests : (count($busSeats) ?: 1);
$total = $price * $passengerCount;
?>
<div class="container">
  <div class="booking-search">
    <h1>📋 Passenger Details</h1>
    <p class="small">Review your booking before payment.</p>
  </div>

  <div class="glass" style="max-width:700px;margin:0 auto var(--space-xl);">
    <form method="POST" action="<?= url('booking/payment.php') ?>" novalidate>
      <?= csrfField() ?>
      <input type="hidden" name="type" value="<?= e($type) ?>">
      <input type="hidden" name="id" value="<?= e($id) ?>">
      <input type="hidden" name="price" value="<?= e($price) ?>">
      <input type="hidden" name="class" value="<?= e($class) ?>">
      <input type="hidden" name="bus" value="<?= e($busId) ?>">
      <input type="hidden" name="hotel" value="<?= e($hotelId) ?>">
      <input type="hidden" name="room" value="<?= e($roomId) ?>">
      <input type="hidden" name="checkin" value="<?= e($checkin) ?>">
      <input type="hidden" name="checkout" value="<?= e($checkout) ?>">
      <input type="hidden" name="guests" value="<?= e($guests) ?>">
      <input type="hidden" name="seats" value="<?= e(json_encode($busSeats)) ?>">
      <input type="hidden" name="journey_date" value="<?= e($journeyDate) ?>">
      <input type="hidden" name="total_amount" value="<?= e($total) ?>">

      <h3 style="margin-bottom:var(--space-lg);">Booking Summary</h3>
      <div class="trip-card" style="margin-bottom:var(--space-lg);">
        <div class="trip-card-image"><img src="<?= e($itemImage) ?>" alt="Travel"></div>
        <div class="trip-card-info">
          <h4 style="margin:0 0 var(--space-xs);"><?= e($itemName) ?></h4>
          <p class="small" style="margin:0 0 var(--space-sm);"><?= e($type === 'hotel' ? ($checkin . ' to ' . $checkout) : $journeyDate) ?></p>
          <div class="trip-card-meta">
            <span><?= e($type === 'hotel' ? $guests : $passengerCount) ?> traveller(s)</span>
            <span><?= money($total) ?></span>
          </div>
        </div>
      </div>

      <h4 style="margin-bottom:var(--space-sm);">Passenger Information</h4>
      <?php for ($i = 0; $i < max(1, $passengerCount); $i++): ?>
        <div class="card" style="padding:var(--space-md);margin-bottom:var(--space-lg);border:var(--border-width) solid var(--color-border);">
          <p class="small" style="color:var(--color-muted);margin-bottom:var(--space-sm);">Passenger <?= $i + 1 ?></p>
          <div class="grid grid-2" style="gap:var(--space-sm);">
            <div class="form-group">
              <label>Full name</label>
              <input type="text" name="passengers[<?= $i ?>][name]" class="form-control" required>
            </div>
            <div class="form-group">
              <label>Age</label>
              <input type="number" name="passengers[<?= $i ?>][age]" class="form-control" min="1" max="100">
            </div>
          </div>
          <div class="form-group" style="margin-top:var(--space-sm);">
            <label>ID type</label>
            <select name="passengers[<?= $i ?>][id_type]" class="form-select">
              <option value="passport">Passport</option>
              <option value="aadhaar">Aadhaar</option>
              <option value="driving_license">Driving License</option>
              <option value="voter_id">Voter ID</option>
            </select>
          </div>
          <div class="form-group" style="margin-top:var(--space-sm);">
            <label>ID number</label>
            <input type="text" name="passengers[<?= $i ?>][id_number]" class="form-control">
          </div>
        </div>
      <?php endfor; ?>

      <div class="form-group">
        <label>Contact email</label>
        <input type="email" name="contact_email" class="form-control" required value="<?= e($_SESSION['user_email'] ?? '') ?>">
      </div>

      <div class="demo-notice">
        <strong>Demo mode:</strong> This is a simulated booking. No real ticket is issued. Payment is processed in sandbox/demo mode.
      </div>

      <div class="form-group">
        <button type="submit" class="btn btn-primary btn-full btn-lg">Proceed to Payment</button>
      </div>
    </form>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>