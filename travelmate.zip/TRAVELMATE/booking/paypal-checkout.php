<?php
/**
 * TRAVELMATE AI - PayPal Checkout (sandbox)
 */
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../config/auth.php';
requireAuth();

$paymentId = (int) ($_GET['payment_id'] ?? 0);
$payment = Database::queryOne('SELECT * FROM payments WHERE id = ?', [$paymentId]);
?>
<div class="container">
  <div class="booking-search">
    <h1>🅿️ PayPal Checkout</h1>
    <p class="small">Sandbox mode — PayPal checkout.</p>
  </div>

  <div class="glass" style="max-width:520px;margin:0 auto;">
    <div class="card">
      <div class="card-body">
        <h3>Pay via PayPal</h3>
        <p class="small">Booking: <?= e($payment['id'] ?? '') ?></p>
        <p class="small">Amount: <?= money($payment['amount'], $payment['currency']) ?></p>
        <div id="paypal-button-container"></div>
        <p class="small mt-3">Or <a href="<?= url('booking/payment.php') ?>">use demo payment</a>.</p>
      </div>
    </div>
  </div>
</div>

<script src="https://www.paypal.com/sdk/js?client-id=<?= e(PAYPAL_CLIENT_ID) ?>&currency=<?= e($payment['currency']) ?>"></script>
<script>
paypal.Buttons({
  createOrder: function (data, actions) {
    return actions.order.create({
      purchase_units: [{
        amount: { value: '<?= number_format($payment['amount'], 2) ?>' },
        custom_id: '<?= $paymentId ?>'
      }]
    });
  },
  onApprove: function (data, actions) {
    return actions.order.capture().then(function (details) {
      fetch('<?= url('api/payments/paypal-webhook.php') ?>', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({ event_type: 'PAYMENT_CAPTURE_COMPLETED', id: data.orderID, resource: { id: details.id, custom_id: '<?= $paymentId ?>' } })
      }).then(() => {
        window.location.href = '<?= url('dashboard/bookings.php') ?>';
      });
    });
  },
  onError: function (err) {
    alert('PayPal error. Try demo mode.');
    window.location.href = '<?= url('booking/payment.php') ?>';
  }
}).render('#paypal-button-container');
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>