<?php
/**
 * TRAVELMATE AI - Hotel Detail & Room Selection (demo)
 */
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../config/auth.php';

$hotelId = (int) ($_GET['id'] ?? 0);
$checkin = $_GET['checkin'] ?? '';
$checkout = $_GET['checkout'] ?? '';
$guests = (int) ($_GET['guests'] ?? 2);

$hotel = Database::queryOne('SELECT * FROM hotels WHERE id = ? AND is_demo = 1', [$hotelId]);
if (!$hotel) {
  setFlash('access_denied', 'Hotel not found.', 'error');
  redirect('booking/hotels.php');
}
$rooms = Database::query('SELECT * FROM hotel_rooms WHERE hotel_id = ? AND is_available = 1', [$hotelId]);
?>
<div class="container">
  <div class="booking-search">
    <h1>🏨 <?= e($hotel['name']) ?></h1>
    <p class="small"><?= e($hotel['city']) ?>, <?= e($hotel['country']) ?> &bull; <?= date('d M, strtotime($hotel['created_at']) ? strtotime($hotel['created_at']) : time()) === false ? 'd M' : '' ?></p>
  </div>

  <div class="grid grid-2" style="margin-top:var(--space-lg);">
    <div>
      <div class="card-image" style="height:320px;">
        <img src="<?= e($hotel['image_url']) ?>" alt="<?= e($hotel['name']) ?>">
      </div>
      <div class="card-body" style="margin-top:var(--space-lg);">
        <h3><?= e($hotel['name']) ?></h3>
        <div class="destination-meta"><span class="badge badge-dark"><?= (int) $hotel['stars'] ?>★</span> <span style="margin-left:var(--space-sm);"><?= e($hotel['rating']) ?> / 5</span></div>
        <p><?= e($hotel['description']) ?></p>
        <h4 style="margin:var(--space-lg) 0 var(--space-sm);">Amenities</h4>
        <div style="display:flex;flex-wrap:wrap;gap:var(--space-xs);">
          <?php foreach (json_decode($hotel['amenities'] ?? '[]', true) ?: [] as $a): ?>
            <span class="badge badge-info" style="font-size:var(--text-xs);"><?= e($a) ?></span>
          <?php endforeach; ?>
        </div>
      </div>
    </div>
    <div>
      <div class="card">
        <div class="card-body">
          <h3>Select Room</h3>
          <p class="small"><?= e($guests) ?> guest(s) &bull; Check-in: <?= e($checkin) ?> &bull; Check-out: <?= e($checkout) ?></p>
          <?php if ($rooms): foreach ($rooms as $room): ?>
            <div class="trip-card" style="padding:var(--space-md);">
              <div class="trip-card-info">
                <h4 style="margin:0 0 var(--space-xs);"><?= e($room['room_type']) ?></h4>
                <p class="small" style="margin:0 0 var(--space-sm);"><?= e($room['max_occupancy']) ?> guests &bull; <?= e($room['available_rooms']) ?> rooms left</p>
                <div class="trip-card-meta">
                  <span><?= money($room['price_per_night'], 'INR') ?> /night</span>
                </div>
              </div>
              <a href="<?= url('booking/passenger-details.php?type=hotel&hotel=' . $hotelId . '&room=' . $room['id'] . '&checkin=' . $checkin . '&checkout=' . $checkout . '&guests=' . $guests . '&price=' . $room['price_per_night']) ?>" class="btn btn-primary btn-full btn-sm mt-2">Select</a>
            </div>
          <?php endforeach; else: ?>
            <div class="empty-state" style="padding:var(--space-md);">
              <div class="icon">🛏</div>
              <h3 style="font-size:var(--text-lg);">No rooms available</h3>
            </div>
          <?php endforeach; ?>
        </div>
      </div>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>