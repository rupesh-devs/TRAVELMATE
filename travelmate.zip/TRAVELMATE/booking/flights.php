<?php
/**
 * TRAVELMATE AI - Flight Booking (demo data from database)
 */
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../config/auth.php';

$flights = [];
$filters = ['source' => '', 'destination' => '', 'date' => '', 'passengers' => '1', 'class' => 'economy'];

if ($_SERVER['REQUEST_METHOD'] === 'GET' && !empty($_GET['search'])) {
  $filters = [
    'source' => trim($_GET['source'] ?? ''),
    'destination' => trim($_GET['destination'] ?? ''),
    'date' => $_GET['date'] ?? '',
    'passengers' => $_GET['passengers'] ?? '1',
    'class' => $_GET['class'] ?? 'economy',
  ];

  $sql = "SELECT * FROM flights WHERE is_demo = 1 AND status = 'scheduled'";
  $params = [];
  if ($filters['source']) { $sql .= " AND source = ?"; $params[] = $filters['source']; }
  if ($filters['destination']) { $sql .= " AND destination = ?"; $params[] = $filters['destination']; }
  if ($filters['date']) { $sql .= " AND DATE(departure_time) = ?"; $params[] = $filters['date']; }
  $sql .= " ORDER BY departure_time ASC";

  $flights = Database::query($sql, $params);

  if (isset($_SESSION['user_id'])) {
    Database::insert(
      'INSERT INTO search_history (user_id, search_type, query) VALUES (?, ?, ?)',
      [(int) $_SESSION['user_id'], 'flight', json_encode($filters)]
    );
  }
}
?>
<div class="container">
  <div class="booking-search">
    <h1>✈️ Flight Booking</h1>
    <p class="small">Compare prices across airlines. All flights below are simulated demo data.</p>
  </div>

  <div class="glass" style="max-width:700px;margin:0 auto var(--space-xl);">
    <form method="GET" action="" class="search-form">
      <input type="hidden" name="search" value="1">
      <div class="input-group">
        <label>From</label>
        <input type="text" name="source" class="form-control" placeholder="e.g. Delhi" required value="<?= e($filters['source']) ?>">
      </div>
      <div class="input-group">
        <label>To</label>
        <input type="text" name="destination" class="form-control" placeholder="e.g. Mumbai" required value="<?= e($filters['destination']) ?>">
      </div>
      <div class="input-group">
        <label>Departure date</label>
        <input type="date" name="date" class="form-control" required value="<?= e($filters['date']) ?>">
      </div>
      <div class="input-group">
        <label>Passengers</label>
        <select name="passengers" class="form-select">
          <option value="1" <?= $filters['passengers'] === '1' ? 'selected' : '' ?>>1 Passenger</option>
          <option value="2" <?= $filters['passengers'] === '2' ? 'selected' : '' ?>>2 Passengers</option>
          <option value="3" <?= $filters['passengers'] === '3' ? 'selected' : '' ?>>3 Passengers</option>
          <option value="4" <?= $filters['passengers'] === '4' ? 'selected' : '' ?>>4 Passengers</option>
        </select>
      </div>
      <div class="input-group">
        <label>Class</label>
        <select name="class" class="form-select">
          <option value="economy" <?= $filters['class'] === 'economy' ? 'selected' : '' ?>>Economy</option>
          <option value="business" <?= $filters['class'] === 'business' ? 'selected' : '' ?>>Business</option>
          <option value="first" <?= $filters['class'] === 'first' ? 'selected' : '' ?>>First</option>
        </select>
      </div>
      <button type="submit" class="btn btn-primary btn-full btn-lg">Search Flights</button>
    </form>
  </div>

  <?php if ($_SERVER['REQUEST_METHOD'] === 'GET' && !empty($_GET['search'])): ?>
    <div class="results-header">
      <h2>Available Flights</h2>
      <p class="small">Showing simulated demo inventory. Not real airline availability.</p>
    </div>
    <div class="grid grid-1">
      <?php if ($flights): foreach ($flights as $f): ?>
        <div class="result-card">
          <div class="result-image">
            <img src="https://images.unsplash.com/photo-1436491865332-7a61a1d0c067?auto=format&fit=crop&w=600&q=80" alt="Airplane">
          </div>
          <div class="result-body">
            <div class="provider"><?= e($f['airline']) ?> &bull; Flight <?= e($f['flight_number']) ?></div>
            <h3><?= e($f['source']) ?> → <?= e($f['destination']) ?></h3>
            <div class="meta">
              <span>🕐 <?= date('H:i', strtotime($f['departure_time'])) ?></span>
              <span>🕑 <?= date('H:i', strtotime($f['arrival_time'])) ?></span>
              <span>⏱ <?= e($f['duration']) ?></span>
            </div>
            <?php
            $price = $f['class'] === 'business' ? $f['price_business'] : ($f['class'] === 'first' ? $f['price_first'] : $f['price_economy']);
            ?>
            <div class="price"><?= money($price, 'INR') ?></div>
          </div>
          <div class="result-actions">
            <span class="badge badge-info">Seats: <?= e($f['available_seats']) ?></span>
            <a href="<?= url('booking/passenger-details.php?type=flight&id=' . $f['id'] . '&price=' . $price . '&class=' . $f['class']) ?>" class="btn btn-primary btn-full">Select</a>
          </div>
        </div>
      <?php endforeach; else: ?>
        <div class="empty-state" style="grid-column:1/-1;">
          <div class="icon">✈️</div>
          <h3 style="font-size:var(--text-lg);">No flights found</h3>
          <p class="small">Try adjusting your search criteria.</p>
        </div>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>