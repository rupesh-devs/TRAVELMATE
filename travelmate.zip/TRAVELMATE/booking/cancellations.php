<?php
/**
 * TRAVELMATE AI - Booking Cancellation
 */
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../config/auth.php';
requireAuth();

$userId = (int) $_SESSION['user_id'];
$bookingId = (int) ($_GET['id'] ?? 0);

$booking = Database::queryOne('SELECT * FROM bookings WHERE id = ? AND user_id = ?', [$bookingId, $userId]);
if (!$booking) {
  setFlash('access_denied', 'Booking not found.', 'error');
  redirect('dashboard/bookings.php');
}

$message = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $reason = trim($_POST['reason'] ?? '');
  try {
    Database::beginTransaction();
    Database::execute('UPDATE bookings SET cancellation_requested = 1, cancellation_reason = ?, status = ? WHERE id = ?',
      [$reason, 'cancelled', $bookingId]);
    Database::execute('UPDATE payments SET status = ? WHERE booking_id = ?', ['refunded', $bookingId]);
    Database::insert('INSERT INTO refunds (booking_id, payment_id, user_id, amount, currency, reason, status, created_at) 
      VALUES (?, ?, ?, ?, ?, ?, ?, NOW())',
      [$bookingId, 0, $userId, $booking['total_amount'], $booking['currency'], $reason, 'requested']);
    Database::insert('INSERT INTO cancellation_requests (booking_id, user_id, reason, refund_amount, status, created_at) 
      VALUES (?, ?, ?, ?, ?, NOW())',
      [$bookingId, $userId, $reason, $booking['total_amount'], 'pending']);
    Database::commit();
    setFlash('login_success', 'Cancellation requested. Refund will be processed.', 'success');
    redirect('dashboard/bookings.php');
  } catch (Exception $e) {
    Database::rollBack();
    $message = $e->getMessage();
  }
}
?>
<div class="container" style="max-width:560px;margin: var(--space-xl) auto;">
  <div class="dashboard-header">
    <h1>Cancel Booking</h1>
    <a href="<?= url('dashboard/bookings.php') ?>" class="btn btn-outline">← Back</a>
  </div>

  <div class="card">
    <div class="card-body">
      <h3><?= e($booking['reference']) ?></h3>
      <p class="small"><?= ucfirst(e($booking['booking_type'])) ?> &bull; <?= e($booking['source'] ?? '-') ?> → <?= e($booking['destination']) ?></p>
      <p class="small"><?= money($booking['total_amount'], $booking['currency']) ?></p>

      <?php if ($message): ?>
        <div style="background:#fee2e2;color:#991b1b;padding:var(--space-sm);border-radius:var(--radius-md);margin-bottom:var(--space-md);font-size:var(--text-sm);"><?= e($message) ?></div>
      <?php endif; ?>

      <form method="POST" novalidate>
        <?= csrfField() ?>
        <div class="form-group">
          <label>Reason for cancellation</label>
          <textarea name="reason" class="form-control" required placeholder="Why are you cancelling this booking?"></textarea>
        </div>
        <div class="demo-notice">
          <strong>Refund policy:</strong> Refunds are processed per provider terms. Demo refunds are simulated.
        </div>
        <div class="btn-group">
          <button type="submit" class="btn btn-danger">Request Cancellation</button>
          <a href="<?= url('dashboard/bookings.php') ?>" class="btn btn-outline">Keep Booking</a>
        </div>
      </form>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>