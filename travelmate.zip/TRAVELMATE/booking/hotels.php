<?php
/**
 * TRAVELMATE AI - Hotel Booking (demo data from database)
 */
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../config/auth.php';

$hotels = [];
$filters = ['destination' => '', 'checkin' => '', 'checkout' => '', 'guests' => '2'];

if ($_SERVER['REQUEST_METHOD'] === 'GET' && !empty($_GET['search'])) {
  $filters = [
    'destination' => trim($_GET['destination'] ?? ''),
    'checkin' => $_GET['checkin'] ?? '',
    'checkout' => $_GET['checkout'] ?? '',
    'guests' => $_GET['guests'] ?? '2',
  ];

  $sql = "SELECT h.* FROM hotels h WHERE h.is_demo = 1 AND h.is_available = 1";
  $params = [];
  if ($filters['destination']) { $sql .= " AND (h.city = ? OR h.country = ?)"; $params[] = $filters['destination']; $params[] = $filters['destination']; }
  $sql .= " ORDER BY h.rating DESC";

  $hotels = Database::query($sql, $params);
}
?>
<div class="container">
  <div class="booking-search">
    <h1>🏨 Hotel Booking</h1>
    <p class="small">Verified stays worldwide. All hotels below are simulated demo data.</p>
  </div>

  <div class="glass" style="max-width:700px;margin:0 auto var(--space-xl);">
    <form method="GET" action="" class="search-form">
      <input type="hidden" name="search" value="1">
      <div class="input-group">
        <label>Destination</label>
        <input type="text" name="destination" class="form-control" placeholder="e.g. Manali, Paris" required value="<?= e($filters['destination']) ?>">
      </div>
      <div class="input-group">
        <label>Check-in</label>
        <input type="date" name="checkin" class="form-control" required value="<?= e($filters['checkin']) ?>">
      </div>
      <div class="input-group">
        <label>Check-out</label>
        <input type="date" name="checkout" class="form-control" required value="<?= e($filters['checkout']) ?>">
      </div>
      <div class="input-group">
        <label>Guests</label>
        <select name="guests" class="form-select">
          <option value="1" <?= $filters['guests'] === '1' ? 'selected' : '' ?>>1 Guest</option>
          <option value="2" <?= $filters['guests'] === '2' ? 'selected' : '' ?>>2 Guests</option>
          <option value="3" <?= $filters['guests'] === '3' ? 'selected' : '' ?>>3 Guests</option>
          <option value="4" <?= $filters['guests'] === '4' ? 'selected' : '' ?>>4 Guests</option>
        </select>
      </div>
      <button type="submit" class="btn btn-primary btn-full btn-lg">Search Hotels</button>
    </form>
  </div>

  <?php if ($_SERVER['REQUEST_METHOD'] === 'GET' && !empty($_GET['search'])): ?>
    <div class="results-header">
      <h2>Available Hotels</h2>
      <p class="small">Showing simulated demo inventory.</p>
    </div>
    <div class="grid grid-3">
      <?php if ($hotels): foreach ($hotels as $h): ?>
        <div class="card">
          <div class="card-image">
            <img src="<?= e($h['image_url']) ?>" alt="<?= e($h['name']) ?>">
          </div>
          <div class="card-body">
            <span class="badge badge-dark"><?= (int) $h['stars'] ?>★</span>
            <h3><?= e($h['name']) ?></h3>
            <div class="destination-meta" style="margin-top:var(--space-xs);">📍 <?= e($h['city']) ?>, <?= e($h['country']) ?></div>
            <p class="small" style="color:var(--color-muted);"><?= e($h['short_description']) ?></p>
            <div class="meta" style="margin-top:var(--space-sm);">
              <span>📊 <?= e($h['rating']) ?></span>
              <span>🛏 from <?= money($h['price_per_night'], 'INR') ?>/night</span>
            </div>
          </div>
          <div class="card-footer">
            <a href="<?= url('booking/hotel-detail.php?id=' . $h['id'] . '&checkin=' . $filters['checkin'] . '&checkout=' . $filters['checkout'] . '&guests=' . $filters['guests']) ?>" class="btn btn-primary btn-full">Select Room</a>
          </div>
        </div>
      <?php endforeach; else: ?>
        <div class="empty-state" style="grid-column:1/-1;">
          <div class="icon">🏨</div>
          <h3 style="font-size:var(--text-lg);">No hotels found</h3>
          <p class="small">Try adjusting your search criteria.</p>
        </div>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>