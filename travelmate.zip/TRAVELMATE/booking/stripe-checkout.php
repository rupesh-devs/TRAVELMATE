<?php
/**
 * TRAVELMATE AI - Stripe Checkout (sandbox)
 */
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../config/auth.php';
requireAuth();

$paymentId = (int) ($_GET['payment_id'] ?? 0);
$payment = Database::queryOne('SELECT * FROM payments WHERE id = ?', [$paymentId]);
$booking = Database::queryOne('SELECT * FROM bookings WHERE id = ?', [(int) $payment['booking_id']]);
?>
<div class="container">
  <div class="booking-search">
    <h1>💳 Stripe Checkout</h1>
    <p class="small">Sandbox mode — international cards accepted.</p>
  </div>

  <div class="glass" style="max-width:520px;margin:0 auto;">
    <div class="card">
      <div class="card-body">
        <h3>Pay via Stripe</h3>
        <p class="small">Booking: <?= e($booking['reference'] ?? '') ?></p>
        <p class="small">Amount: <?= money($payment['amount'], $payment['currency']) ?></p>
        <form id="stripeForm" action="<?= url('api/payments/stripe-webhook.php') ?>" method="POST" style="display:none;">
          <?= csrfField() ?>
          <input type="hidden" name="payment_id" value="<?= $paymentId ?>">
          <input type="hidden" name="stripe_payment_intent_id" id="stripeIntentId">
        </form>

        <div id="stripeMount"></div>
        <button id="stripePayBtn" class="btn btn-primary btn-full btn-lg">Pay Now</button>
        <p class="small mt-3">Or <a href="<?= url('booking/payment.php') ?>">use demo payment</a>.</p>
      </div>
    </div>
  </div>
</div>

<script src="https://js.stripe.com/v3/"></script>
<script>
var stripe = Stripe('<?= e(STRIPE_PUBLIC_KEY) ?>');
document.getElementById('stripePayBtn').addEventListener('click', async function (e) {
  e.preventDefault();
  try {
    const res = await fetch('<?= url('api/payments/stripe-create.php') ?>', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({ payment_id: <?= $paymentId ?>, amount: <?= (int) ($payment['amount'] * 100) ?>, currency: '<?= e($payment['currency']) ?>' })
    });
    const data = await res.json();
    if (data.url) {
      window.location.href = data.url;
    } else {
      alert('Stripe not configured — using demo mode.');
      location.href = '<?= url('booking/payment.php') ?>';
    }
  } catch (err) {
    location.href = '<?= url('booking/payment.php') ?>';
  }
});
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>