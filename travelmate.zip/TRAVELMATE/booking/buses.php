<?php
/**
 * TRAVELMATE AI - Bus Booking (demo data from database)
 */
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../config/auth.php';

$buses = [];
$filters = ['source' => '', 'destination' => '', 'date' => '', 'type' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'GET' && !empty($_GET['search'])) {
  $filters = [
    'source' => trim($_GET['source'] ?? ''),
    'destination' => trim($_GET['destination'] ?? ''),
    'date' => $_GET['date'] ?? '',
    'type' => $_GET['type'] ?? '',
  ];

  $sql = "SELECT * FROM buses WHERE is_demo = 1 AND status = 'scheduled'";
  $params = [];
  if ($filters['source']) { $sql .= " AND source = ?"; $params[] = $filters['source']; }
  if ($filters['destination']) { $sql .= " AND destination = ?"; $params[] = $filters['destination']; }
  if ($filters['date']) { $sql .= " AND DATE(departure_time) = ?"; $params[] = $filters['date']; }
  if ($filters['type']) { $sql .= " AND bus_type = ?"; $params[] = $filters['type']; }
  $sql .= " ORDER BY departure_time ASC";

  $buses = Database::query($sql, $params);
}
?>
<div class="container">
  <div class="booking-search">
    <h1>🚌 Bus Booking</h1>
    <p class="small">AC, non-AC, sleeper and seater options. All buses below are simulated demo data.</p>
  </div>

  <div class="glass" style="max-width:700px;margin:0 auto var(--space-xl);">
    <form method="GET" action="" class="search-form">
      <input type="hidden" name="search" value="1">
      <div class="input-group">
        <label>From</label>
        <input type="text" name="source" class="form-control" placeholder="e.g. Delhi" required value="<?= e($filters['source']) ?>">
      </div>
      <div class="input-group">
        <label>To</label>
        <input type="text" name="destination" class="form-control" placeholder="e.g. Manali" required value="<?= e($filters['destination']) ?>">
      </div>
      <div class="input-group">
        <label>Journey date</label>
        <input type="date" name="date" class="form-control" required value="<?= e($filters['date']) ?>">
      </div>
      <div class="input-group">
        <label>Bus type</label>
        <select name="type" class="form-select">
          <option value="">All types</option>
          <option value="AC Sleeper" <?= $filters['type'] === 'AC Sleeper' ? 'selected' : '' ?>>AC Sleeper</option>
          <option value="AC Seater" <?= $filters['type'] === 'AC Seater' ? 'selected' : '' ?>>AC Seater</option>
          <option value="Non-AC Sleeper" <?= $filters['type'] === 'Non-AC Sleeper' ? 'selected' : '' ?>>Non-AC Sleeper</option>
        </select>
      </div>
      <button type="submit" class="btn btn-primary btn-full btn-lg">Search Buses</button>
    </form>
  </div>

  <?php if ($_SERVER['REQUEST_METHOD'] === 'GET' && !empty($_GET['search'])): ?>
    <div class="results-header">
      <h2>Available Buses</h2>
      <p class="small">Showing simulated demo inventory.</p>
    </div>
    <div class="grid grid-1">
      <?php if ($buses): foreach ($buses as $b): ?>
        <div class="result-card">
          <div class="result-image">
            <img src="https://images.unsplash.com/photo-1552454612-e95ea719c2c7?auto=format&fit=crop&w=600&q=80" alt="Bus">
          </div>
          <div class="result-body">
            <div class="provider"><?= e($b['operator']) ?> &bull; Bus <?= e($b['bus_number']) ?></div>
            <h3><?= e($b['source']) ?> → <?= e($b['destination']) ?></h3>
            <div class="meta">
              <span>🕐 <?= date('H:i', strtotime($b['departure_time'])) ?></span>
              <span>🕑 <?= date('H:i', strtotime($b['arrival_time'])) ?></span>
              <span>⏱ <?= e($b['duration']) ?></span>
              <span>💺 <?= e($b['bus_type']) ?></span>
            </div>
            <div class="price"><?= money($b['price'], 'INR') ?></div>
          </div>
          <div class="result-actions">
            <span class="badge badge-info">Seats: <?= e($b['available_seats']) ?></span>
            <a href="<?= url('booking/seat-select.php?id=' . $b['id'] . '&price=' . $b['price']) ?>" class="btn btn-primary btn-full">Select Seats</a>
          </div>
        </div>
      <?php endforeach; else: ?>
        <div class="empty-state" style="grid-column:1/-1;">
          <div class="icon">🚌</div>
          <h3 style="font-size:var(--text-lg);">No buses found</h3>
          <p class="small">Try adjusting your search criteria.</p>
        </div>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>