<?php
/**
 * TRAVELMATE AI - Payment Processing
 * Supports Demo (default), Razorpay, Stripe and PayPal in sandbox/demo mode.
 */
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../config/auth.php';
requireAuth();

$userId = (int) $_SESSION['user_id'];

$type        = $_POST['type'] ?? '';
$price       = (float) ($_POST['price'] ?? 0);
$passengers  = $_POST['passengers'] ?? [];
$contactEmail = trim($_POST['contact_email'] ?? '');
$seatsJson   = $_POST['seats'] ?? '[]';
$journeyDate = $_POST['journey_date'] ?? null;
$totalAmount = (float) ($_POST['total_amount'] ?? 0);

$bookingType = $type;
$provider    = DEMO_MODE ? 'demo' : (($_POST['provider'] ?? 'demo'));
$currency    = 'INR';

// Build booking data JSON
$bookingData = [
  'type' => $type,
  'passengers' => $passengers,
  'contact_email' => $contactEmail,
  'class' => $_POST['class'] ?? null,
  'bus' => $_POST['bus'] ?? null,
  'seats' => json_decode($seatsJson, true) ?: [],
  'hotel' => $_POST['hotel'] ?? null,
  'room' => $_POST['room'] ?? null,
  'checkin' => $_POST['checkin'] ?? null,
  'checkout' => $_POST['checkout'] ?? null,
  'guests' => $_POST['guests'] ?? null,
];

// Determine source/destination for display
$source = $destination = $itemName = '';
if ($type === 'flight') {
  $f = Database::queryOne('SELECT source, destination, airline, flight_number FROM flights WHERE id = ?', [(int) $_POST['id']]);
  $source = $f['source'] ?? ''; $destination = $f['destination'] ?? ''; $itemName = ($f['airline'] ?? '') . ' ' . ($f['flight_number'] ?? '');
} elseif ($type === 'bus') {
  $b = Database::queryOne('SELECT source, destination, operator, bus_number FROM buses WHERE id = ?', [(int) $_POST['bus']]);
  $source = $b['source'] ?? ''; $destination = $b['destination'] ?? ''; $itemName = ($b['operator'] ?? '') . ' ' . ($b['bus_number'] ?? '');
} elseif ($type === 'train') {
  $t = Database::queryOne('SELECT source, destination, train_name, train_number FROM trains WHERE id = ?', [(int) $_POST['id']]);
  $source = $t['source'] ?? ''; $destination = $t['destination'] ?? ''; $itemName = ($t['train_name'] ?? '') . ' (' . ($t['train_number'] ?? '') . ')';
} elseif ($type === 'hotel') {
  $h = Database::queryOne('SELECT name, city FROM hotels WHERE id = ?', [(int) $_POST['hotel']]);
  $destination = $h['city'] ?? ''; $itemName = $h['name'] ?? '';
}

$reference = generateReference('TM');
$error = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  try {
    Database::beginTransaction();

    // 1. Create booking (pending)
    $bookingId = Database::insert(
      'INSERT INTO bookings (user_id, reference, booking_type, total_amount, currency, status, payment_status, journey_date, source, destination, passenger_count, booking_data, created_at) 
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())',
      [$userId, $reference, $bookingType, $totalAmount, $currency, 'pending', 'unpaid', $journeyDate, $source, $destination, count($passengers) ?: 1, json_encode($bookingData)]
    );

    // 2. Create passengers
    foreach ($passengers as $i => $p) {
      $seat = isset($bookingData['seats'][$i]) ? $bookingData['seats'][$i] : null;
      Database::insert(
        'INSERT INTO passengers (booking_id, full_name, age, gender, id_type, id_number, seat_number, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, NOW())',
        [$bookingId, $p['name'] ?? '', $p['age'] ?? null, null, $p['id_type'] ?? null, $p['id_number'] ?? null, $seat]
      );
    }

    // 3. Create payment record
    $paymentId = Database::insert(
      'INSERT INTO payments (booking_id, user_id, provider, amount, currency, status, signature, created_at) 
       VALUES (?, ?, ?, ?, ?, ?, ?, NOW())',
      [$bookingId, $userId, $provider, $totalAmount, $currency, 'pending', null]
    );

    Database::commit();

    // 4. Payment provider handling
    if ($provider === 'demo' || DEMO_MODE) {
      // Simulate successful payment
      Database::beginTransaction();
      Database::execute("UPDATE payments SET status = 'success', provider_payment_id = 'DEMO_" . bin2hex(random_bytes(4)) . "', paid_at = NOW() WHERE id = ?", [$paymentId]);
      Database::execute("UPDATE bookings SET payment_status = 'paid', status = 'confirmed' WHERE id = ?", [$bookingId]);

      // QR code data (verifiable reference)
      $qrPayload = json_encode(['ref' => $reference, 'booking_id' => $bookingId, 'user_id' => $userId]);
      $qrUrl = 'https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=' . urlencode($qrPayload);
      Database::execute("UPDATE bookings SET qr_code_url = ?, qr_verified = 1 WHERE id = ?", [$qrUrl, $bookingId]);

      // Reward points (10 per ₹100)
      $points = (int) floor($totalAmount / 100) * 10;
      Database::insert('INSERT INTO rewards (user_id, points, type, description, reference_id, created_at) VALUES (?, ?, ?, ?, ?, NOW())',
        [$userId, $points, 'booking', 'Points earned for booking #' . $reference, $bookingId]);

      // Notification
      Database::insert('INSERT INTO notifications (user_id, title, message, type, link, created_at) VALUES (?, ?, ?, ?, ?, NOW())',
        [$userId, 'Booking Confirmed', 'Your booking ' . $reference . ' has been confirmed.', 'booking', url('booking/ticket.php?ref=' . $reference)]);

      Database::commit();
      setFlash('login_success', 'Payment successful! Booking confirmed: ' . $reference, 'success');
      redirect('booking/ticket.php?ref=' . $reference);
    }

    // Razorpay (sandbox)
    if ($provider === 'razorpay' && !empty(RAZORPAY_KEY_ID)) {
      $orderData = [
        'amount' => (int) ($totalAmount * 100), // paise
        'currency' => 'INR',
        'receipt' => $reference,
        'notes' => ['booking_id' => $bookingId, 'user_id' => $userId]
      ];
      $ch = curl_init('https://api.razorpay.com/v1/orders');
      curl_setopt($ch, CURLOPT_USERPWD, RAZORPAY_KEY_ID . ':' . RAZORPAY_KEY_SECRET);
      curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
      curl_setopt($ch, CURLOPT_POST, true);
      curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($orderData));
      curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
      $res = curl_exec($ch);
      curl_close($ch);
      $order = json_decode($res, true);
      if (!empty($order['id'])) {
        Database::execute('UPDATE payments SET provider_payment_id = ? WHERE id = ?', [$order['id'], $paymentId]);
        header('Location: ' . url('booking/razorpay-checkout.php?order_id=' . $order['id'] . '&payment_id=' . $paymentId));
        exit;
      }
      $error = 'Razorpay order creation failed. Falling back to demo mode.';
      // fall through to demo
    }

    // Stripe
    if ($provider === 'stripe' && !empty(STRIPE_SECRET_KEY)) {
      header('Location: ' . url('booking/stripe-checkout.php?payment_id=' . $paymentId));
      exit;
    }

    // PayPal
    if ($provider === 'paypal' && !empty(PAYPAL_CLIENT_ID)) {
      header('Location: ' . url('booking/paypal-checkout.php?payment_id=' . $paymentId));
      exit;
    }

  } catch (Exception $e) {
    Database::rollBack();
    error_log('Payment error: ' . $e->getMessage());
    $error = $e->getMessage();
  }
}
?>
<div class="container">
  <div class="booking-search">
    <h1>💳 Secure Checkout</h1>
    <p class="small">Review and pay for your booking.</p>
  </div>

  <?php if ($error): ?>
    <div style="background:#fee2e2;color:#991b1b;padding:var(--space-sm);border-radius:var(--radius-md);margin-bottom:var(--space-lg);font-size:var(--text-sm);"><?= e($error) ?></div>
  <?php endif; ?>

  <div class="grid grid-2">
    <div class="card">
      <div class="card-body">
        <h3>Order Summary</h3>
        <div class="order-line"><span>Booking reference</span><strong><?= e($reference) ?></strong></div>
        <div class="order-line"><span>Service</span><strong><?= e($itemName) ?></strong></div>
        <div class="order-line"><span>Route</span><strong><?= e($source . ' → ' . $destination) ?></strong></div>
        <div class="order-line"><span>Travellers</span><strong><?= count($passengers) ?: 1 ?></strong></div>
        <div class="order-line"><span>Total amount</span><strong><?= money($totalAmount, $currency) ?></strong></div>
        <div class="order-total">
          <span>Payable</span>
          <strong><?= money($totalAmount, $currency) ?></strong>
        </div>
      </div>
    </div>

    <div class="card">
      <div class="card-body">
        <h3>Choose Payment Method</h3>
        <form method="POST" action="" id="paymentForm" novalidate>
          <?= csrfField() ?>
          <input type="hidden" name="type" value="<?= e($type) ?>">
          <input type="hidden" name="id" value="<?= e($_POST['id'] ?? '') ?>">
          <input type="hidden" name="price" value="<?= e($price) ?>">
          <input type="hidden" name="class" value="<?= e($_POST['class'] ?? '') ?>">
          <input type="hidden" name="bus" value="<?= e($_POST['bus'] ?? '') ?>">
          <input type="hidden" name="hotel" value="<?= e($_POST['hotel'] ?? '') ?>">
          <input type="hidden" name="room" value="<?= e($_POST['room'] ?? '') ?>">
          <input type="hidden" name="checkin" value="<?= e($_POST['checkin'] ?? '') ?>">
          <input type="hidden" name="checkout" value="<?= e($_POST['checkout'] ?? '') ?>">
          <input type="hidden" name="guests" value="<?= e($_POST['guests'] ?? '') ?>">
          <input type="hidden" name="seats" value="<?= e($seatsJson) ?>">
          <input type="hidden" name="journey_date" value="<?= e($journeyDate) ?>">
          <input type="hidden" name="total_amount" value="<?= e($totalAmount) ?>">
          <?php foreach ($passengers as $i => $p): ?>
            <input type="hidden" name="passengers[<?= $i ?>][name]" value="<?= e($p['name'] ?? '') ?>">
            <input type="hidden" name="passengers[<?= $i ?>][age]" value="<?= e($p['age'] ?? '') ?>">
            <input type="hidden" name="passengers[<?= $i ?>][id_type]" value="<?= e($p['id_type'] ?? '') ?>">
            <input type="hidden" name="passengers[<?= $i ?>][id_number]" value="<?= e($p['id_number'] ?? '') ?>">
          <?php endforeach; ?>
          <input type="hidden" name="contact_email" value="<?= e($contactEmail) ?>">

          <div class="payment-methods">
            <div class="payment-method <?= DEMO_MODE ? 'selected' : '' ?>" onclick="selectMethod(this, 'demo')">
              <div class="logo">💳</div>
              <div>Demo Payment</div>
              <div class="small">Simulated success (sandbox)</div>
            </div>
            <?php if (!DEMO_MODE && !empty(RAZORPAY_KEY_ID)): ?>
            <div class="payment-method" onclick="selectMethod(this, 'razorpay')">
              <div class="logo">🏦</div>
              <div>Razorpay</div>
              <div class="small">UPI, Cards, Net Banking</div>
            </div>
            <?php endif; ?>
            <?php if (!DEMO_MODE && !empty(STRIPE_SECRET_KEY)): ?>
            <div class="payment-method" onclick="selectMethod(this, 'stripe')">
              <div class="logo">💳</div>
              <div>Stripe</div>
              <div class="small">International cards</div>
            </div>
            <?php endif; ?>
            <?php if (!DEMO_MODE && !empty(PAYPAL_CLIENT_ID)): ?>
            <div class="payment-method" onclick="selectMethod(this, 'paypal')">
              <div class="logo">🅿️</div>
              <div>PayPal</div>
              <div class="small">PayPal checkout</div>
            </div>
            <?php endif; ?>
          </div>
          <input type="hidden" name="provider" id="provider" value="<?= e($provider) ?>">

          <div class="form-group mt-4">
            <button type="submit" class="btn btn-primary btn-full btn-lg">Pay Now</button>
          </div>
        </form>

        <div class="demo-notice" style="margin-top:var(--space-lg);">
          <strong>Security notice:</strong> No card numbers or CVV are stored on our servers. All real payments are verified server-side via provider webhooks.
        </div>
      </div>
    </div>
  </div>
</div>

<script>
function selectMethod(el, method) {
  document.querySelectorAll('.payment-method').forEach(m => m.classList.remove('selected'));
  el.classList.add('selected');
  document.getElementById('provider').value = method;
}
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>