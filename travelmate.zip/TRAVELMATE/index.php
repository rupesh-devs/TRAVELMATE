<?php
/**
 * TRAVELMATE AI - Homepage
 */
require_once __DIR__ . '/includes/header.php';
?>

<!-- ============ HERO ============ -->
<section class="hero" id="hero">
  <div class="hero-bg">
    <img id="heroImg" src="https://images.unsplash.com/photo-1469854523076-904d97e86e29?auto=format&fit=crop&w=1600&q=80" alt="World destination">
  </div>
  <div class="hero-overlay"></div>
  <div class="hero-content container">
    <div class="chip">✈️ Global Destinations &bull; 🏨 Verified Hotels &bull; 🤖 AI Travel Assistant</div>
    <h1 class="display-heading">Explore The World, Your Way.</h1>
    <p class="subtitle">Your intelligent travel companion for every journey. Plan, book, and manage trips with TRAVELMATE AI.</p>
    <div class="search-panel">
      <div class="glass">
        <form id="heroSearch" class="search-form" onsubmit="event.preventDefault();">
          <div class="input-group">
            <label>From / City</label>
            <input type="text" class="form-control" placeholder="e.g. Delhi" required>
          </div>
          <div class="input-group">
            <label>Going to</label>
            <input type="text" class="form-control" placeholder="e.g. Manali" required>
          </div>
          <div class="input-group">
            <label>Departure</label>
            <input type="date" class="form-control" required>
          </div>
          <div class="input-group">
            <label>Travelers</label>
            <select class="form-select">
              <option>1 Traveler</option>
              <option>2 Travelers</option>
              <option>3 Travelers</option>
              <option>4+ Travelers</option>
            </select>
          </div>
          <button type="submit" class="btn btn-primary btn-lg btn-full">Search Trips</button>
        </form>
      </div>
    </div>
    <div class="hero-actions mt-4">
      <a href="<?= url('auth/login.php') ?>" class="btn btn-outline btn-lg">Plan My Trip</a>
      <a href="<?= url('destinations.php') ?>" class="btn btn-secondary btn-lg">Explore Now</a>
    </div>
  </div>
</section>

<script>
/* ---------- Hero rotating background ---------- */
(function(){
  const images = [
    'https://images.unsplash.com/photo-1469854523076-904d97e86e29?auto=format&fit=crop&w=1600&q=80',
    'https://images.unsplash.com/photo-1502602898657-3e91760cbb34?auto=format&fit=crop&w=1600&q=80',
    'https://images.unsplash.com/photo-1537906632651-25497797149a?auto=format&fit=crop&w=1600&q=80',
    'https://images.unsplash.com/photo-1512453977769-79b85c543de4?auto=format&fit=crop&w=1600&q=80',
    'https://images.unsplash.com/photo-1544453938-11614650d7c3?auto=format&fit=crop&w=1600&q=80',
    'https://images.unsplash.com/photo-1540959733332-eab4deabeeaf?auto=format&fit=crop&w=1600&q=80',
    'https://images.unsplash.com/photo-1512352308367-c37e69232748?auto=format&fit=crop&w=1600&q=80',
    'https://images.unsplash.com/photo-1603774874264-8de4e03e77a6?auto=format&fit=crop&w=1600&q=80'
  ];
  let i = 0;
  const img = document.getElementById('heroImg');
  setInterval(() => {
    i = (i + 1) % images.length;
    img.style.opacity = '0';
    setTimeout(() => { img.src = images[i]; img.style.opacity = '1'; }, 500);
  }, 5000);
})();
</script>

<!-- ============ POPULAR DESTINATIONS ============ -->
<section class="section" id="popular">
  <div class="container">
    <div class="section-header">
      <h2>Popular Destinations</h2>
      <div class="section-divider"></div>
      <p class="subtitle">Hand-picked places travellers love most.</p>
    </div>
    <div class="grid grid-3" id="popularDestinations">
      <!-- populated by JS -->
    </div>
  </div>
</section>

<!-- ============ TRENDING DESTINATIONS ============ -->
<section class="section" id="trending" style="background:var(--color-offwhite);">
  <div class="container">
    <div class="section-header">
      <h2>Trending Now</h2>
      <div class="section-divider"></div>
      <p class="subtitle">This season's most searched getaways.</p>
    </div>
    <div class="grid grid-3" id="trendingDestinations">
      <!-- populated by JS -->
    </div>
  </div>
</section>

<!-- ============ BOOKING TILES ============ -->
<section class="section" id="book">
  <div class="container">
    <div class="section-header">
      <h2>Book Your Journey</h2>
      <div class="section-divider"></div>
      <p class="subtitle">Flights, trains, buses and hotels — all in one place.</p>
    </div>
    <div class="grid grid-4">
      <a href="<?= url('booking/flights.php') ?>" class="booking-tile">
        <div class="icon">✈️</div>
        <h3>Flights</h3>
        <p>Domestic &amp; international airfare</p>
      </a>
      <a href="<?= url('booking/trains.php') ?>" class="booking-tile">
        <div class="icon">🚆</div>
        <h3>Trains</h3>
        <p>Rail travel across the country</p>
      </a>
      <a href="<?= url('booking/buses.php') ?>" class="booking-tile">
        <div class="icon">🚌</div>
        <h3>Buses</h3>
        <p>AC, non-AC, sleeper &amp; seater</p>
      </a>
      <a href="<?= url('booking/hotels.php') ?>" class="booking-tile">
        <div class="icon">🏨</div>
        <h3>Hotels</h3>
        <p>Verified stays worldwide</p>
      </a>
    </div>
  </div>
</section>

<!-- ============ EXCLUSIVE PACKAGES ============ -->
<section class="section" id="packages">
  <div class="container">
    <div class="section-header">
      <h2>Exclusive Travel Packages</h2>
      <div class="section-divider"></div>
      <p class="subtitle">Curated itineraries for every kind of traveller.</p>
    </div>
    <div class="grid grid-3" id="packagesList">
      <div class="package-card">
        <div class="package-image">
          <img src="https://images.unsplash.com/photo-1549087783-da29220f0e29?auto=format&fit=crop&w=800&q=80" alt="Manali">
        </div>
        <div class="package-body">
          <h3>Himalayan Escape — Manali</h3>
          <p class="small">5 days / 4 nights &bull; From Delhi</p>
        </div>
        <div class="package-footer">
          <div class="package-price">₹14,999</div>
          <span class="badge badge-dark">4.5★</span>
        </div>
      </div>
      <div class="package-card">
        <div class="package-image">
          <img src="https://images.unsplash.com/photo-1512352308367-c37e69232748?auto=format&fit=crop&w=800&q=80" alt="Goa">
        </div>
        <div class="package-body">
          <h3>Beach Bliss — Goa</h3>
          <p class="small">4 days / 3 nights &bull; From Mumbai</p>
        </div>
        <div class="package-footer">
          <div class="package-price">₹12,499</div>
          <span class="badge badge-dark">4.4★</span>
        </div>
      </div>
      <div class="package-card">
        <div class="package-image">
          <img src="https://images.unsplash.com/photo-1603774874264-8de4e03e77a6?auto=format&fit=crop&w=800&q=80" alt="Jaipur">
        </div>
        <div class="package-body">
          <h3>Royal Rajasthan — Jaipur</h3>
          <p class="small">3 days / 2 nights &bull; From Delhi</p>
        </div>
        <div class="package-footer">
          <div class="package-price">₹9,999</div>
          <span class="badge badge-dark">4.6★</span>
        </div>
      </div>
      <div class="package-card">
        <div class="package-image">
          <img src="https://images.unsplash.com/photo-1502602898657-3e91760cbb34?auto=format&fit=crop&w=800&q=80" alt="Paris">
        </div>
        <div class="package-body">
          <h3>Romantic Paris</h3>
          <p class="small">6 days / 5 nights &bull; International</p>
        </div>
        <div class="package-footer">
          <div class="package-price">₹84,500</div>
          <span class="badge badge-dark">4.7★</span>
        </div>
      </div>
      <div class="package-card">
        <div class="package-image">
          <img src="https://images.unsplash.com/photo-1537906632651-25497797149a?auto=format&fit=crop&w=800&q=80" alt="Bali">
        </div>
        <div class="package-body">
          <h3>Tropical Bali</h3>
          <p class="small">7 days / 6 nights &bull; International</p>
        </div>
        <div class="package-footer">
          <div class="package-price">₹68,000</div>
          <span class="badge badge-dark">4.6★</span>
        </div>
      </div>
      <div class="package-card">
        <div class="package-image">
          <img src="https://images.unsplash.com/photo-1544453938-11614650d7c3?auto=format&fit=crop&w=800&q=80" alt="Maldives">
        </div>
        <div class="package-body">
          <h3>Island Maldives</h3>
          <p class="small">5 days / 4 nights &bull; International</p>
        </div>
        <div class="package-footer">
          <div class="package-price">₹112,000</div>
          <span class="badge badge-dark">4.8★</span>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- ============ AI ASSISTANT ============ -->
<section class="section" id="ai">
  <div class="container">
    <div class="section-header">
      <h2>AI Travel Assistant</h2>
      <div class="section-divider"></div>
      <p class="subtitle">Ask anything — itineraries, budgets, packing, and more.</p>
    </div>
    <div class="grid grid-2">
      <div>
        <h3>Plan with AI</h3>
        <p class="small mb-3">Tell the assistant: <em>"Plan a 5-day trip from Lucknow to Manali under ₹15,000"</em> and get a day-wise itinerary with cost estimates.</p>
        <a href="<?= url('ai/assistant.php') ?>" class="btn btn-primary">Open AI Assistant</a>
      </div>
      <div class="card">
        <div class="card-body">
          <div class="feature-card">
            <div class="feature-icon">💬</div>
            <h4>Text &amp; Voice Chat</h4>
            <p class="small">Hindi and English support.</p>
          </div>
          <div class="feature-card">
            <div class="feature-icon">📅</div>
            <h4>Smart Itineraries</h4>
            <p class="small">Day-wise plans with budget.</p>
          </div>
          <div class="feature-card">
            <div class="feature-icon">🎒</div>
            <h4>Packing Checklist</h4>
            <p class="small">AI-generated packing lists.</p>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- ============ TESTIMONIALS ============ -->
<section class="section" id="testimonials" style="background:var(--color-offwhite);">
  <div class="container">
    <div class="section-header">
      <h2>Traveller Stories</h2>
      <div class="section-divider"></div>
      <p class="subtitle">What our community says.</p>
    </div>
    <div class="grid grid-3">
      <div class="testimonial-card">
        <div class="stars">★★★★★</div>
        <p class="small">"TRAVELMATE AI made planning my Manali trip effortless. The AI itinerary was spot-on!"</p>
        <div class="testimonial-avatar">RS</div>
        <h5 style="margin:var(--space-sm) 0 0; font-size:var(--text-sm);">Rahul Sharma</h5>
        <p class="small" style="color:var(--color-muted);">Manali, Himachal</p>
      </div>
      <div class="testimonial-card">
        <div class="stars">★★★★★</div>
        <p class="small">"Booked my Goa flights and hotel in minutes. The QR e-ticket worked perfectly at check-in."</p>
        <div class="testimonial-avatar">PS</div>
        <h5 style="margin:var(--space-sm) 0 0; font-size:var(--text-sm);">Priya Singh</h5>
        <p class="small" style="color:var(--color-muted);">Goa, India</p>
      </div>
      <div class="testimonial-card">
        <div class="stars">★★★★☆</div>
        <p class="small">"The currency converter and weather widget helped me pack right for my Dubai trip."</p>
        <div class="testimonial-avatar">AK</div>
        <h5 style="margin:var(--space-sm) 0 0; font-size:var(--text-sm);">Arjun Kapoor</h5>
        <p class="small" style="color:var(--color-muted);">Dubai, UAE</p>
      </div>
    </div>
  </div>
</section>

<!-- ============ GALLERY ============ -->
<section class="section" id="gallery">
  <div class="container">
    <div class="section-header">
      <h2>Travel Inspiration</h2>
      <div class="section-divider"></div>
      <p class="subtitle">A world waiting to be explored.</p>
    </div>
    <div class="gallery-grid">
      <div class="gallery-item"><img src="https://images.unsplash.com/photo-1502602898657-3e91760cbb34?auto=format&fit=crop&w=600&q=80" alt="Eiffel Tower"></div>
      <div class="gallery-item"><img src="https://images.unsplash.com/photo-1549087783-da29220f0e29?auto=format&fit=crop&w=600&q=80" alt="Manali"></div>
      <div class="gallery-item"><img src="https://images.unsplash.com/photo-1537906632651-25497797149a?auto=format&fit=crop&w=600&q=80" alt="Bali"></div>
      <div class="gallery-item"><img src="https://images.unsplash.com/photo-1512453977769-79b85c543de4?auto=format&fit=crop&w=600&q=80" alt="Dubai"></div>
      <div class="gallery-item"><img src="https://images.unsplash.com/photo-1544453938-11614650d7c3?auto=format&fit=crop&w=600&q=80" alt="Maldives"></div>
      <div class="gallery-item"><img src="https://images.unsplash.com/photo-1540959733332-eab4deabeeaf?auto=format&fit=crop&w=600&q=80" alt="Tokyo"></div>
      <div class="gallery-item"><img src="https://images.unsplash.com/photo-1512352308367-c37e69232748?auto=format&fit=crop&w=600&q=80" alt="Goa"></div>
      <div class="gallery-item"><img src="https://images.unsplash.com/photo-1603774874264-8de4e03e77a6?auto=format&fit=crop&w=600&q=80" alt="Jaipur"></div>
    </div>
  </div>
</section>

<?php require_once __DIR__ . '/includes/footer.php'; ?>

<script>
/* ---------- Popular / Trending destination cards ---------- */
(function(){
  const destinations = [
    { name:'Manali', country:'India', img:'https://images.unsplash.com/photo-1549087783-da29220f0e29?auto=format&fit=crop&w=600&q=80', price:'₹4,500', rating:'4.5' },
    { name:'Goa', country:'India', img:'https://images.unsplash.com/photo-1512352308367-c37e69232748?auto=format&fit=crop&w=600&q=80', price:'₹3,200', rating:'4.4' },
    { name:'Jaipur', country:'India', img:'https://images.unsplash.com/photo-1603774874264-8de4e03e77a6?auto=format&fit=crop&w=600&q=80', price:'₹2,800', rating:'4.6' },
    { name:'Paris', country:'France', img:'https://images.unsplash.com/photo-1502602898657-3e91760cbb34?auto=format&fit=crop&w=600&q=80', price:'₹42,000', rating:'4.7' },
    { name:'Bali', country:'Indonesia', img:'https://images.unsplash.com/photo-1537906632651-25497797149a?auto=format&fit=crop&w=600&q=80', price:'₹34,000', rating:'4.6' },
    { name:'Dubai', country:'UAE', img:'https://images.unsplash.com/photo-1512453977769-79b85c543de4?auto=format&fit=crop&w=600&q=80', price:'₹18,000', rating:'4.5' },
    { name:'Maldives', country:'Maldives', img:'https://images.unsplash.com/photo-1544453938-11614650d7c3?auto=format&fit=crop&w=600&q=80', price:'₹56,000', rating:'4.8' },
    { name:'Tokyo', country:'Japan', img:'https://images.unsplash.com/photo-1540959733332-eab4deabeeaf?auto=format&fit=crop&w=600&q=80', price:'₹52,000', rating:'4.6' }
  ];

  const card = d => `
    <div class="destination-card">
      <div class="destination-image">
        <img src="${d.img}" alt="${d.name}">
        <div class="destination-badge badge badge-dark">${d.rating}★</div>
      </div>
      <div class="destination-body">
        <h3>${d.name}</h3>
        <div class="destination-meta">📍 ${d.country} &bull; ${d.price} /night</div>
      </div>
      <div class="destination-overlay">
        <div style="font-size:2rem; margin-bottom:var(--space-sm);">✈️</div>
        <div>Visit ${d.name}</div>
        <div class="destination-actions mt-3">
          <a href="<?= url('booking/flights.php') ?>" class="btn btn-outline btn-sm">Explore</a>
        </div>
      </div>
    </div>`;

  const popular = document.getElementById('popularDestinations');
  const trending = document.getElementById('trendingDestinations');
  if (popular) popular.innerHTML = destinations.slice(0,3).map(card).join('');
  if (trending) trending.innerHTML = destinations.slice(3,6).map(card).join('');
})();
</script>