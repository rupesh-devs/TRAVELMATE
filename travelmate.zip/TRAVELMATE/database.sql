-- =============================================================================
-- TRAVELMATE AI - MySQL Database Schema
-- BCA Final Year Major Project
-- =============================================================================
-- Run this in phpMyAdmin or via: mysql -u root -p travelmate < database.sql
-- =============================================================================

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

CREATE DATABASE IF NOT EXISTS `travelmate` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `travelmate`;

-- -----------------------------------------------------------------------------
-- users
-- -----------------------------------------------------------------------------
CREATE TABLE `users` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `full_name` varchar(100) NOT NULL,
  `email` varchar(190) NOT NULL,
  `mobile` varchar(20) DEFAULT NULL,
  `country` varchar(100) NOT NULL DEFAULT 'India',
  `password` varchar(255) NOT NULL,
  `role` enum('user','admin') NOT NULL DEFAULT 'user',
  `status` enum('active','inactive','suspended') NOT NULL DEFAULT 'active',
  `email_verified` tinyint(1) NOT NULL DEFAULT 0,
  `google_id` varchar(100) DEFAULT NULL COMMENT 'Google OAuth ID',
  `profile_photo` varchar(255) DEFAULT NULL,
  `date_of_birth` date DEFAULT NULL,
  `gender` enum('male','female','other','prefer_not_to_say') DEFAULT NULL,
  `last_login_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_users_email` (`email`),
  KEY `idx_users_status` (`status`),
  KEY `idx_users_role` (`role`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -----------------------------------------------------------------------------
-- admins (separate admin accounts)
-- -----------------------------------------------------------------------------
CREATE TABLE `admins` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `full_name` varchar(100) NOT NULL,
  `email` varchar(190) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('super_admin','admin','moderator') NOT NULL DEFAULT 'admin',
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `last_login_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_admins_email` (`email`),
  KEY `idx_admins_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -----------------------------------------------------------------------------
-- destinations
-- -----------------------------------------------------------------------------
CREATE TABLE `destinations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  `country` varchar(100) NOT NULL,
  `city` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `short_description` varchar(255) DEFAULT NULL,
  `image_url` varchar(255) DEFAULT NULL,
  `gallery_images` json DEFAULT NULL COMMENT 'Array of image URLs',
  `best_season` varchar(100) DEFAULT NULL,
  `latitude` decimal(10,7) DEFAULT NULL,
  `longitude` decimal(10,7) DEFAULT NULL,
  `type` enum('domestic','international') NOT NULL DEFAULT 'domestic',
  `is_popular` tinyint(1) NOT NULL DEFAULT 0,
  `is_trending` tinyint(1) NOT NULL DEFAULT 0,
  `rating` decimal(3,2) DEFAULT 0.00,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_destinations_country` (`country`),
  KEY `idx_destinations_type` (`type`),
  KEY `idx_destinations_popular` (`is_popular`),
  KEY `idx_destinations_trending` (`is_trending`),
  KEY `idx_destinations_rating` (`rating`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -----------------------------------------------------------------------------
-- flights
-- -----------------------------------------------------------------------------
CREATE TABLE `flights` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `airline` varchar(100) NOT NULL,
  `flight_number` varchar(20) NOT NULL,
  `source` varchar(100) NOT NULL,
  `destination` varchar(100) NOT NULL,
  `departure_time` datetime NOT NULL,
  `arrival_time` datetime NOT NULL,
  `duration` varchar(20) DEFAULT NULL,
  `price_economy` decimal(10,2) NOT NULL,
  `price_business` decimal(10,2) DEFAULT NULL,
  `price_first` decimal(10,2) DEFAULT NULL,
  `total_seats` int NOT NULL DEFAULT 180,
  `available_seats` int NOT NULL DEFAULT 180,
  `image_url` varchar(255) DEFAULT NULL,
  `status` enum('scheduled','cancelled','completed') NOT NULL DEFAULT 'scheduled',
  `is_demo` tinyint(1) NOT NULL DEFAULT 1 COMMENT '1 = simulated/demo data',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_flights_route` (`source`,`destination`),
  KEY `idx_flights_departure` (`departure_time`),
  KEY `idx_flights_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -----------------------------------------------------------------------------
-- buses
-- -----------------------------------------------------------------------------
CREATE TABLE `buses` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `operator` varchar(100) NOT NULL,
  `bus_number` varchar(30) NOT NULL,
  `source` varchar(100) NOT NULL,
  `destination` varchar(100) NOT NULL,
  `departure_time` datetime NOT NULL,
  `arrival_time` datetime NOT NULL,
  `duration` varchar(20) DEFAULT NULL,
  `bus_type` enum('AC','Non-AC','Sleeper','Seater','AC Sleeper','Non-AC Sleeper') NOT NULL DEFAULT 'AC',
  `price` decimal(10,2) NOT NULL,
  `total_seats` int NOT NULL DEFAULT 40,
  `available_seats` int NOT NULL DEFAULT 40,
  `image_url` varchar(255) DEFAULT NULL,
  `amenities` json DEFAULT NULL COMMENT 'e.g. ["WiFi","Water","Blanket"]',
  `status` enum('scheduled','cancelled','completed') NOT NULL DEFAULT 'scheduled',
  `is_demo` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_buses_route` (`source`,`destination`),
  KEY `idx_buses_departure` (`departure_time`),
  KEY `idx_buses_type` (`bus_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -----------------------------------------------------------------------------
-- trains
-- -----------------------------------------------------------------------------
CREATE TABLE `trains` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `train_number` varchar(20) NOT NULL,
  `train_name` varchar(100) NOT NULL,
  `source` varchar(100) NOT NULL,
  `destination` varchar(100) NOT NULL,
  `departure_time` time NOT NULL,
  `arrival_time` time NOT NULL,
  `duration` varchar(20) DEFAULT NULL,
  `classes_available` json DEFAULT NULL COMMENT 'e.g. ["1A","2A","3A","SL"]',
  `price_sleeper` decimal(10,2) DEFAULT NULL,
  `price_3ac` decimal(10,2) DEFAULT NULL,
  `price_2ac` decimal(10,2) DEFAULT NULL,
  `price_1ac` decimal(10,2) DEFAULT NULL,
  `image_url` varchar(255) DEFAULT NULL,
  `status` enum('scheduled','cancelled','completed') NOT NULL DEFAULT 'scheduled',
  `is_demo` tinyint(1) NOT NULL DEFAULT 1 COMMENT '1 = simulated/demo data',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_trains_route` (`source`,`destination`),
  KEY `idx_trains_number` (`train_number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -----------------------------------------------------------------------------
-- hotels
-- -----------------------------------------------------------------------------
CREATE TABLE `hotels` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  `destination_id` int unsigned DEFAULT NULL,
  `city` varchar(100) NOT NULL,
  `country` varchar(100) NOT NULL,
  `address` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `short_description` varchar(255) DEFAULT NULL,
  `image_url` varchar(255) DEFAULT NULL,
  `gallery_images` json DEFAULT NULL,
  `rating` decimal(3,2) DEFAULT 0.00,
  `stars` tinyint unsigned DEFAULT 3,
  `price_per_night` decimal(10,2) NOT NULL,
  `amenities` json DEFAULT NULL COMMENT 'e.g. ["WiFi","Pool","Spa","Breakfast"]',
  `latitude` decimal(10,7) DEFAULT NULL,
  `longitude` decimal(10,7) DEFAULT NULL,
  `is_available` tinyint(1) NOT NULL DEFAULT 1,
  `is_demo` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_hotels_city` (`city`),
  KEY `idx_hotels_destination` (`destination_id`),
  KEY `idx_hotels_rating` (`rating`),
  KEY `idx_hotels_price` (`price_per_night`),
  CONSTRAINT `fk_hotels_destination` FOREIGN KEY (`destination_id`) REFERENCES `destinations` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -----------------------------------------------------------------------------
-- hotel_rooms (room types per hotel)
-- -----------------------------------------------------------------------------
CREATE TABLE `hotel_rooms` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `hotel_id` int unsigned NOT NULL,
  `room_type` varchar(50) NOT NULL COMMENT 'e.g. Deluxe, Suite, Deluxe Double',
  `price_per_night` decimal(10,2) NOT NULL,
  `total_rooms` int NOT NULL DEFAULT 10,
  `available_rooms` int NOT NULL DEFAULT 10,
  `max_occupancy` int NOT NULL DEFAULT 2,
  `amenities` json DEFAULT NULL,
  `is_available` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `idx_hotel_rooms_hotel` (`hotel_id`),
  CONSTRAINT `fk_hotel_rooms_hotel` FOREIGN KEY (`hotel_id`) REFERENCES `hotels` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -----------------------------------------------------------------------------
-- bookings (master booking table for all transport + hotels)
-- -----------------------------------------------------------------------------
CREATE TABLE `bookings` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int unsigned NOT NULL,
  `reference` varchar(30) NOT NULL COMMENT 'Unique booking reference e.g. TMX9F2K1L8',
  `booking_type` enum('flight','bus','train','hotel','package') NOT NULL,
  `provider_reference` varchar(100) DEFAULT NULL COMMENT 'External provider reference',
  `total_amount` decimal(10,2) NOT NULL,
  `currency` char(3) NOT NULL DEFAULT 'INR',
  `status` enum('pending','confirmed','cancelled','refunded','failed') NOT NULL DEFAULT 'pending',
  `payment_status` enum('unpaid','paid','partially_paid','refunded','failed') NOT NULL DEFAULT 'unpaid',
  `journey_date` date DEFAULT NULL,
  `source` varchar(100) DEFAULT NULL,
  `destination` varchar(100) DEFAULT NULL,
  `passenger_count` int unsigned NOT NULL DEFAULT 1,
  `booking_data` json DEFAULT NULL COMMENT 'Flexible booking details (flight seats, hotel rooms, etc.)',
  `qr_code_url` varchar(255) DEFAULT NULL,
  `qr_verified` tinyint(1) NOT NULL DEFAULT 0,
  `cancellation_requested` tinyint(1) NOT NULL DEFAULT 0,
  `cancellation_reason` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_bookings_reference` (`reference`),
  KEY `idx_bookings_user` (`user_id`),
  KEY `idx_bookings_type` (`booking_type`),
  KEY `idx_bookings_status` (`status`),
  KEY `idx_bookings_payment` (`payment_status`),
  KEY `idx_bookings_journey` (`journey_date`),
  CONSTRAINT `fk_bookings_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -----------------------------------------------------------------------------
-- passengers
-- -----------------------------------------------------------------------------
CREATE TABLE `passengers` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `booking_id` int unsigned NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `age` int unsigned DEFAULT NULL,
  `gender` enum('male','female','other') DEFAULT NULL,
  `id_type` enum('passport','aadhaar','driving_license','voter_id','other') DEFAULT NULL,
  `id_number` varchar(50) DEFAULT NULL,
  `seat_number` varchar(10) DEFAULT NULL,
  `meal_preference` enum('veg','non_veg','vegan','jain','none') DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_passengers_booking` (`booking_id`),
  CONSTRAINT `fk_passengers_booking` FOREIGN KEY (`booking_id`) REFERENCES `bookings` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -----------------------------------------------------------------------------
-- payments
-- -----------------------------------------------------------------------------
CREATE TABLE `payments` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `booking_id` int unsigned NOT NULL,
  `user_id` int unsigned NOT NULL,
  `provider` enum('razorpay','stripe','paypal','demo','wallet') NOT NULL DEFAULT 'demo',
  `provider_payment_id` varchar(100) DEFAULT NULL,
  `amount` decimal(10,2) NOT NULL,
  `currency` char(3) NOT NULL DEFAULT 'INR',
  `status` enum('pending','success','failed','refunded','partially_refunded') NOT NULL DEFAULT 'pending',
  `signature` varchar(255) DEFAULT NULL COMMENT 'Provider signature for verification',
  `receipt_url` varchar(255) DEFAULT NULL,
  `raw_response` json DEFAULT NULL COMMENT 'Provider webhook/API response',
  `paid_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_payments_provider` (`provider`,`provider_payment_id`),
  KEY `idx_payments_booking` (`booking_id`),
  KEY `idx_payments_user` (`user_id`),
  KEY `idx_payments_status` (`status`),
  CONSTRAINT `fk_payments_booking` FOREIGN KEY (`booking_id`) REFERENCES `bookings` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_payments_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -----------------------------------------------------------------------------
-- payment_events (webhook event log)
-- -----------------------------------------------------------------------------
CREATE TABLE `payment_events` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `payment_id` int unsigned DEFAULT NULL,
  `provider` enum('razorpay','stripe','paypal','demo') NOT NULL,
  `event_type` varchar(100) NOT NULL,
  `event_id` varchar(100) DEFAULT NULL,
  `received_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `processed` tinyint(1) NOT NULL DEFAULT 0,
  `raw_payload` json DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_payment_events_payment` (`payment_id`),
  KEY `idx_payment_events_event` (`event_id`),
  CONSTRAINT `fk_payment_events_payment` FOREIGN KEY (`payment_id`) REFERENCES `payments` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -----------------------------------------------------------------------------
-- refunds
-- -----------------------------------------------------------------------------
CREATE TABLE `refunds` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `booking_id` int unsigned NOT NULL,
  `payment_id` int unsigned NOT NULL,
  `user_id` int unsigned NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `currency` char(3) NOT NULL DEFAULT 'INR',
  `reason` varchar(255) DEFAULT NULL,
  `status` enum('requested','approved','rejected','processed','failed') NOT NULL DEFAULT 'requested',
  `provider_refund_id` varchar(100) DEFAULT NULL,
  `processed_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_refunds_booking` (`booking_id`),
  KEY `idx_refunds_user` (`user_id`),
  KEY `idx_refunds_status` (`status`),
  CONSTRAINT `fk_refunds_booking` FOREIGN KEY (`booking_id`) REFERENCES `bookings` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_refunds_payment` FOREIGN KEY (`payment_id`) REFERENCES `payments` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_refunds_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -----------------------------------------------------------------------------
-- reviews
-- -----------------------------------------------------------------------------
CREATE TABLE `reviews` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int unsigned NOT NULL,
  `destination_id` int unsigned DEFAULT NULL,
  `hotel_id` int unsigned DEFAULT NULL,
  `booking_id` int unsigned DEFAULT NULL,
  `rating` tinyint unsigned NOT NULL CHECK (`rating` BETWEEN 1 AND 5),
  `title` varchar(150) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `is_approved` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_reviews_user` (`user_id`),
  KEY `idx_reviews_destination` (`destination_id`),
  KEY `idx_reviews_hotel` (`hotel_id`),
  KEY `idx_reviews_approved` (`is_approved`),
  CONSTRAINT `fk_reviews_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_reviews_destination` FOREIGN KEY (`destination_id`) REFERENCES `destinations` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_reviews_hotel` FOREIGN KEY (`hotel_id`) REFERENCES `hotels` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_reviews_booking` FOREIGN KEY (`booking_id`) REFERENCES `bookings` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -----------------------------------------------------------------------------
-- itineraries (AI-generated / user trip plans)
-- -----------------------------------------------------------------------------
CREATE TABLE `itineraries` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int unsigned NOT NULL,
  `title` varchar(150) NOT NULL,
  `start_city` varchar(100) NOT NULL,
  `destination` varchar(100) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `budget` decimal(10,2) DEFAULT NULL,
  `currency` char(3) DEFAULT 'INR',
  `interests` json DEFAULT NULL,
  `travellers` int unsigned DEFAULT 1,
  `plan_data` json NOT NULL COMMENT 'Day-wise itinerary JSON',
  `is_public` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_itineraries_user` (`user_id`),
  CONSTRAINT `fk_itineraries_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -----------------------------------------------------------------------------
-- trip_expenses
-- -----------------------------------------------------------------------------
CREATE TABLE `trip_expenses` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int unsigned NOT NULL,
  `itinerary_id` int unsigned DEFAULT NULL,
  `category` enum('transport','hotel','food','activities','misc') NOT NULL,
  `description` varchar(150) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `currency` char(3) DEFAULT 'INR',
  `expense_date` date NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_trip_expenses_user` (`user_id`),
  KEY `idx_trip_expenses_itinerary` (`itinerary_id`),
  CONSTRAINT `fk_trip_expenses_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_trip_expenses_itinerary` FOREIGN KEY (`itinerary_id`) REFERENCES `itineraries` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -----------------------------------------------------------------------------
-- group_trips
-- -----------------------------------------------------------------------------
CREATE TABLE `group_trips` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `creator_id` int unsigned NOT NULL,
  `title` varchar(150) NOT NULL,
  `destination` varchar(100) NOT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `budget_per_person` decimal(10,2) DEFAULT NULL,
  `currency` char(3) DEFAULT 'INR',
  `is_private` tinyint(1) NOT NULL DEFAULT 1,
  `invite_code` varchar(20) DEFAULT NULL,
  `status` enum('planning','active','completed','cancelled') NOT NULL DEFAULT 'planning',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_group_trips_invite` (`invite_code`),
  KEY `idx_group_trips_creator` (`creator_id`),
  CONSTRAINT `fk_group_trips_creator` FOREIGN KEY (`creator_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -----------------------------------------------------------------------------
-- group_members
-- -----------------------------------------------------------------------------
CREATE TABLE `group_members` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `group_id` int unsigned NOT NULL,
  `user_id` int unsigned NOT NULL,
  `role` enum('admin','member') NOT NULL DEFAULT 'member',
  `joined_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_group_members` (`group_id`,`user_id`),
  KEY `idx_group_members_user` (`user_id`),
  CONSTRAINT `fk_group_members_group` FOREIGN KEY (`group_id`) REFERENCES `group_trips` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_group_members_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -----------------------------------------------------------------------------
-- travel_buddies (buddy finder connections)
-- -----------------------------------------------------------------------------
CREATE TABLE `travel_buddies` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int unsigned NOT NULL COMMENT 'Profile owner',
  `destination` varchar(100) DEFAULT NULL,
  `interests` json DEFAULT NULL,
  `travel_dates` varchar(100) DEFAULT NULL,
  `budget` decimal(10,2) DEFAULT NULL,
  `bio` text DEFAULT NULL,
  `profile_public` tinyint(1) NOT NULL DEFAULT 0,
  `consent_to_share` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'User consent before sharing profile',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_travel_buddies_user` (`user_id`),
  KEY `idx_travel_buddies_public` (`profile_public`,`consent_to_share`),
  CONSTRAINT `fk_travel_buddies_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -----------------------------------------------------------------------------
-- notifications
-- -----------------------------------------------------------------------------
CREATE TABLE `notifications` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int unsigned NOT NULL,
  `title` varchar(150) NOT NULL,
  `message` text DEFAULT NULL,
  `type` enum('booking','payment','refund','system','ai','reminder') NOT NULL DEFAULT 'system',
  `is_read` tinyint(1) NOT NULL DEFAULT 0,
  `link` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_notifications_user` (`user_id`),
  KEY `idx_notifications_read` (`is_read`),
  CONSTRAINT `fk_notifications_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -----------------------------------------------------------------------------
-- rewards (loyalty points ledger per user)
-- -----------------------------------------------------------------------------
CREATE TABLE `rewards` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int unsigned NOT NULL,
  `points` int NOT NULL DEFAULT 0,
  `type` enum('signup','booking','referral','review','loyalty') NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `reference_id` int unsigned DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_rewards_user` (`user_id`),
  CONSTRAINT `fk_rewards_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -----------------------------------------------------------------------------
-- reward_transactions (points spend / redeem)
-- -----------------------------------------------------------------------------
CREATE TABLE `reward_transactions` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int unsigned NOT NULL,
  `points` int NOT NULL COMMENT 'negative = spent, positive = earned',
  `type` enum('earn','redeem') NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_reward_transactions_user` (`user_id`),
  CONSTRAINT `fk_reward_transactions_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -----------------------------------------------------------------------------
-- wishlists
-- -----------------------------------------------------------------------------
CREATE TABLE `wishlists` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int unsigned NOT NULL,
  `destination_id` int unsigned DEFAULT NULL,
  `hotel_id` int unsigned DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_wishlist_user_dest` (`user_id`,`destination_id`),
  UNIQUE KEY `uk_wishlist_user_hotel` (`user_id`,`hotel_id`),
  KEY `idx_wishlist_user` (`user_id`),
  CONSTRAINT `fk_wishlists_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_wishlists_destination` FOREIGN KEY (`destination_id`) REFERENCES `destinations` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_wishlists_hotel` FOREIGN KEY (`hotel_id`) REFERENCES `hotels` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -----------------------------------------------------------------------------
-- packing_checklists
-- -----------------------------------------------------------------------------
CREATE TABLE `packing_checklists` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int unsigned NOT NULL,
  `itinerary_id` int unsigned DEFAULT NULL,
  `title` varchar(150) NOT NULL,
  `destination` varchar(100) DEFAULT NULL,
  `travel_date` date DEFAULT NULL,
  `is_ai_generated` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_packing_user` (`user_id`),
  KEY `idx_packing_itinerary` (`itinerary_id`),
  CONSTRAINT `fk_packing_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_packing_itinerary` FOREIGN KEY (`itinerary_id`) REFERENCES `itineraries` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -----------------------------------------------------------------------------
-- packing_items
-- -----------------------------------------------------------------------------
CREATE TABLE `packing_items` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `checklist_id` int unsigned NOT NULL,
  `item_name` varchar(100) NOT NULL,
  `category` enum('clothing','toiletries','electronics','documents','medicine','misc') NOT NULL,
  `is_packed` tinyint(1) NOT NULL DEFAULT 0,
  `notes` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_packing_items_checklist` (`checklist_id`),
  CONSTRAINT `fk_packing_items_checklist` FOREIGN KEY (`checklist_id`) REFERENCES `packing_checklists` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -----------------------------------------------------------------------------
-- emergency_contacts
-- -----------------------------------------------------------------------------
CREATE TABLE `emergency_contacts` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int unsigned NOT NULL,
  `name` varchar(100) NOT NULL,
  `relationship` varchar(50) DEFAULT NULL,
  `phone` varchar(20) NOT NULL,
  `email` varchar(190) DEFAULT NULL,
  `is_primary` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_emergency_contacts_user` (`user_id`),
  CONSTRAINT `fk_emergency_contacts_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -----------------------------------------------------------------------------
-- user_preferences
-- -----------------------------------------------------------------------------
CREATE TABLE `user_preferences` (
  `user_id` int unsigned NOT NULL,
  `currency` char(3) NOT NULL DEFAULT 'INR',
  `language` char(5) NOT NULL DEFAULT 'en',
  `theme` enum('light','dark','system') NOT NULL DEFAULT 'light',
  `notifications_enabled` tinyint(1) NOT NULL DEFAULT 1,
  `email_notifications` tinyint(1) NOT NULL DEFAULT 1,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_id`),
  CONSTRAINT `fk_user_preferences_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -----------------------------------------------------------------------------
-- search_history
-- -----------------------------------------------------------------------------
CREATE TABLE `search_history` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int unsigned DEFAULT NULL,
  `search_type` enum('flight','bus','train','hotel','destination') NOT NULL,
  `query` varchar(255) NOT NULL,
  `searched_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_search_history_user` (`user_id`),
  KEY `idx_search_history_type` (`search_type`),
  CONSTRAINT `fk_search_history_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -----------------------------------------------------------------------------
-- cancellation_requests
-- -----------------------------------------------------------------------------
CREATE TABLE `cancellation_requests` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `booking_id` int unsigned NOT NULL,
  `user_id` int unsigned NOT NULL,
  `reason` varchar(255) DEFAULT NULL,
  `refund_amount` decimal(10,2) DEFAULT NULL,
  `status` enum('pending','approved','rejected','processed') NOT NULL DEFAULT 'pending',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `processed_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_cancellation_requests_booking` (`booking_id`),
  KEY `idx_cancellation_requests_user` (`user_id`),
  KEY `idx_cancellation_requests_status` (`status`),
  CONSTRAINT `fk_cancellation_requests_booking` FOREIGN KEY (`booking_id`) REFERENCES `bookings` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_cancellation_requests_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -----------------------------------------------------------------------------
-- password_resets (used by auth system)
-- -----------------------------------------------------------------------------
CREATE TABLE `password_resets` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(190) NOT NULL,
  `token` varchar(100) NOT NULL,
  `expires_at` datetime NOT NULL,
  `used` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_password_resets_token` (`token`),
  KEY `idx_password_resets_email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -----------------------------------------------------------------------------
-- SAMPLE DATA
-- -----------------------------------------------------------------------------

-- Default admin (password: Admin@123)
INSERT INTO `admins` (`full_name`, `email`, `password`, `role`) VALUES
('System Administrator', 'admin@travelmate.ai', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'super_admin');

-- Demo user (password: Travel@123)
INSERT INTO `users` (`full_name`, `email`, `mobile`, `country`, `password`, `role`, `status`, `email_verified`) VALUES
('Rahul Sharma', 'rahul@example.com', '+91 98765 43210', 'India', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'user', 'active', 1);

-- user_preferences for demo user
INSERT INTO `user_preferences` (`user_id`, `currency`, `language`, `theme`, `notifications_enabled`) VALUES
(1, 'INR', 'en', 'light', 1);

-- Destinations (Domestic & International)
INSERT INTO `destinations` (`name`, `country`, `city`, `description`, `short_description`, `image_url`, `gallery_images`, `best_season`, `latitude`, `longitude`, `type`, `is_popular`, `is_trending`, `rating`) VALUES
('Manali', 'India', 'Manali', 'A scenic hill station in Himachal Pradesh known for snow-capped mountains, adventure sports, and apple orchards.', 'Himalayan hill station', 'https://images.unsplash.com/photo-1549087783-da29220f0e29?auto=format&fit=crop&w=800&q=80', '["https://images.unsplash.com/photo-1549087783-da29220f0e29?auto=format&fit=crop&w=800&q=80"]', 'March to June', 32.2432, 77.1892, 'domestic', 1, 1, 4.50),
('Goa', 'India', 'Goa', 'Sunny beaches, Portuguese heritage, nightlife, and water sports on India\'s western coast.', 'Beach paradise', 'https://images.unsplash.com/photo-1512352308367-c37e69232748?auto=format&fit=crop&w=800&q=80', '["https://images.unsplash.com/photo-1512352308367-c37e69232748?auto=format&fit=crop&w=800&q=80"]', 'November to February', 15.2993, 74.1240, 'domestic', 1, 1, 4.40),
('Jaipur', 'India', 'Jaipur', 'The Pink City of Rajasthan, famous for forts, palaces, and vibrant bazaars.', 'Pink City', 'https://images.unsplash.com/photo-1603774874264-8de4e03e77a6?auto=format&fit=crop&w=800&q=80', '["https://images.unsplash.com/photo-1603774874264-8de4e03e77a6?auto=format&fit=crop&w=800&q=80"]', 'October to March', 26.9124, 75.7873, 'domestic', 1, 0, 4.60),
('Paris', 'France', 'Paris', 'City of light, home to the Eiffel Tower, Louvre Museum, and romantic Seine cruises.', 'City of Love', 'https://images.unsplash.com/photo-1502602898657-3e91760cbb34?auto=format&fit=crop&w=800&q=80', '["https://images.unsplash.com/photo-1502602898657-3e91760cbb34?auto=format&fit=crop&w=800&q=80"]', 'April to October', 48.8566, 2.3522, 'international', 1, 1, 4.70),
('Bali', 'Indonesia', 'Bali', 'Tropical island known for temples, rice terraces, beaches, and wellness retreats.', 'Island of the Gods', 'https://images.unsplash.com/photo-1537906632651-25497797149a?auto=format&fit=crop&w=800&q=80', '["https://images.unsplash.com/photo-1537906632651-25497797149a?auto=format&fit=crop&w=800&q=80"]', 'April to October', -8.4095, 115.1889, 'international', 1, 1, 4.60),
('Dubai', 'UAE', 'Dubai', 'Ultra-modern city with Burj Khalifa, luxury shopping, and desert safaris.', 'City of Gold', 'https://images.unsplash.com/photo-1512453977769-79b85c543de4?auto=format&fit=crop&w=800&q=80', '["https://images.unsplash.com/photo-1512453977769-79b85c543de4?auto=format&fit=crop&w=800&q=80"]', 'November to March', 25.2048, 55.2708, 'international', 1, 1, 4.50),
('Maldives', 'Maldives', 'Malé', 'Pristine white-sand islands, turquoise lagoons, and overwater bungalows.', 'Tropical Paradise', 'https://images.unsplash.com/photo-1544453938-11614650d7c3?auto=format&fit=crop&w=800&q=80', '["https://images.unsplash.com/photo-1544453938-11614650d7c3?auto=format&fit=crop&w=800&q=80"]', 'November to April', 4.1755, 73.5093, 'international', 1, 1, 4.80),
('Tokyo', 'Japan', 'Tokyo', 'A fusion of ancient temples and cutting-edge technology, from Shibuya Crossing to Mount Fuji.', 'Capital of Japan', 'https://images.unsplash.com/photo-1540959733332-eab4deabeeaf?auto=format&fit=crop&w=800&q=80', '["https://images.unsplash.com/photo-1540959733332-eab4deabeeaf?auto=format&fit=crop&w=800&q=80"]', 'March to May, September to November', 35.6762, 139.6503, 'international', 1, 1, 4.60);

-- Flights (demo)
INSERT INTO `flights` (`airline`, `flight_number`, `source`, `destination`, `departure_time`, `arrival_time`, `duration`, `price_economy`, `price_business`, `price_first`, `total_seats`, `available_seats`, `status`, `is_demo`) VALUES
('Air India', 'AI 802', 'Delhi', 'Mumbai', DATE_ADD(NOW(), INTERVAL 1 DAY), DATE_ADD(DATE_ADD(NOW(), INTERVAL 1 DAY), INTERVAL 2 HOUR), '2h 00m', 4500.00, 12000.00, 22000.00, 180, 175, 'scheduled', 1),
('IndiGo', '6E 654', 'Delhi', 'Bangalore', DATE_ADD(NOW(), INTERVAL 2 DAY), DATE_ADD(DATE_ADD(NOW(), INTERVAL 2 DAY), INTERVAL 2 HOUR), '2h 30m', 3800.00, 10500.00, 19000.00, 180, 178, 'scheduled', 1),
('Emirates', 'EK 532', 'Delhi', 'Dubai', DATE_ADD(NOW(), INTERVAL 3 DAY), DATE_ADD(DATE_ADD(NOW(), INTERVAL 3 DAY), INTERVAL 4 HOUR), '4h 15m', 18000.00, 45000.00, 85000.00, 220, 210, 'scheduled', 1),
('Air France', 'AF 130', 'Delhi', 'Paris', DATE_ADD(NOW(), INTERVAL 5 DAY), DATE_ADD(DATE_ADD(NOW(), INTERVAL 5 DAY), INTERVAL 9 HOUR), '9h 00m', 42000.00, 95000.00, 180000.00, 250, 240, 'scheduled', 1),
('Singapore Airlines', 'SQ 452', 'Mumbai', 'Singapore', DATE_ADD(NOW(), INTERVAL 7 DAY), DATE_ADD(DATE_ADD(NOW(), INTERVAL 7 DAY), INTERVAL 5 HOUR), '5h 30m', 22000.00, 55000.00, 98000.00, 200, 195, 'scheduled', 1);

-- Buses (demo)
INSERT INTO `buses` (`operator`, `bus_number`, `source`, `destination`, `departure_time`, `arrival_time`, `duration`, `bus_type`, `price`, `total_seats`, `available_seats`, `amenities`, `status`, `is_demo`) VALUES
('RedBus Express', 'RB101', 'Delhi', 'Manali', DATE_ADD(NOW(), INTERVAL 1 DAY), DATE_ADD(DATE_ADD(NOW(), INTERVAL 1 DAY), INTERVAL 14 HOUR), '14h 00m', 'AC Sleeper', 850.00, 40, 35, '["WiFi","Water","Blanket","Charging Point"]', 'scheduled', 1),
('Zingbus', 'ZB202', 'Delhi', 'Jaipur', DATE_ADD(NOW(), INTERVAL 1 DAY), DATE_ADD(DATE_ADD(NOW(), INTERVAL 1 DAY), INTERVAL 5 HOUR), '5h 00m', 'AC Seater', 550.00, 40, 38, '["WiFi","Water","Charging Point"]', 'scheduled', 1),
('Goa Travels', 'GT303', 'Mumbai', 'Goa', DATE_ADD(NOW(), INTERVAL 2 DAY), DATE_ADD(DATE_ADD(NOW(), INTERVAL 2 DAY), INTERVAL 10 HOUR), '10h 00m', 'Non-AC Sleeper', 700.00, 40, 32, '["Water","Blanket"]', 'scheduled', 1);

-- Trains (demo) — clearly labeled demo, not official
INSERT INTO `trains` (`train_number`, `train_name`, `source`, `destination`, `departure_time`, `arrival_time`, `duration`, `classes_available`, `price_sleeper`, `price_3ac`, `price_2ac`, `price_1ac`, `status`, `is_demo`) VALUES
('12433', 'Goa Express', 'Delhi', 'Goa', '08:00:00', '16:00:00', '8h 00m', '["SL","3A","2A","1A"]', 450.00, 1200.00, 1800.00, 3000.00, 'scheduled', 1),
('12801', 'Himachal Express', 'Delhi', 'Manali', '17:00:00', '07:00:00', '14h 00m', '["SL","3A","2A"]', 300.00, 900.00, 1400.00, NULL, 'scheduled', 1),
('12951', 'Rajasthan Express', 'Delhi', 'Jaipur', '16:40:00', '20:40:00', '4h 00m', '["SL","3A","2A","1A"]', 200.00, 600.00, 900.00, 1500.00, 'scheduled', 1);

-- Hotels
INSERT INTO `hotels` (`name`, `destination_id`, `city`, `country`, `address`, `description`, `short_description`, `image_url`, `gallery_images`, `rating`, `stars`, `price_per_night`, `amenities`, `latitude`, `longitude`, `is_available`, `is_demo`) VALUES
('The Himalayan Retreat', 1, 'Manali', 'India', 'Old Manali, Himachal Pradesh', 'Cozy mountain resort with valley views and a fireplace lounge.', 'Mountain resort', 'https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?auto=format&fit=crop&w=800&q=80', '["https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?auto=format&fit=crop&w=800&q=80"]', 4.50, 4, 4500.00, '["WiFi","Room Service","Fireplace","Mountain View"]', 32.2432, 77.1892, 1, 1),
('Beach Haven Goa', 2, 'Goa', 'India', 'Baga Beach, Goa', 'Beachfront property steps from the sand with a rooftop bar.', 'Beachfront hotel', 'https://images.unsplash.com/photo-1566073771259-6a8506099945?auto=format&fit=crop&w=800&q=80', '["https://images.unsplash.com/photo-1566073771259-6a8506099945?auto=format&fit=crop&w=800&q=80"]', 4.30, 3, 3200.00, '["WiFi","Pool","Restaurant","Beach Access"]', 15.2993, 74.1240, 1, 1),
('Le Royal Paris', 4, 'Paris', 'France', 'Champs-Élysées, Paris', 'Luxury hotel near the Eiffel Tower with classic French interiors.', 'Luxury hotel', 'https://images.unsplash.com/photo-1515378791036-0648a3ef77b2?auto=format&fit=crop&w=800&q=80', '["https://images.unsplash.com/photo-1515378791036-0648a3ef77b2?auto=format&fit=crop&w=800&q=80"]', 4.80, 5, 18000.00, '["WiFi","Spa","Fine Dining","Concierge"]', 48.8566, 2.3522, 1, 1);

-- Hotel rooms
INSERT INTO `hotel_rooms` (`hotel_id`, `room_type`, `price_per_night`, `total_rooms`, `available_rooms`, `max_occupancy`, `amenities`, `is_available`) VALUES
(1, 'Deluxe Mountain View', 4500.00, 10, 10, 2, '["WiFi","Fireplace","Balcony"]', 1),
(1, 'Suite', 7500.00, 5, 5, 4, '["WiFi","Fireplace","Balcony","Living Room"]', 1),
(2, 'Standard Sea View', 3200.00, 15, 15, 2, '["WiFi","TV","Balcony"]', 1),
(3, 'Deluxe Room', 18000.00, 20, 20, 2, '["WiFi","Minibar","Eiffel View"]', 1);

-- Rewards for demo user
INSERT INTO `rewards` (`user_id`, `points`, `type`, `description`) VALUES
(1, 100, 'signup', 'Welcome bonus');

SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;

-- =============================================================================
-- End of schema
-- =============================================================================