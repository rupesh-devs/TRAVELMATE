<?php
/**
 * TRAVELMATE AI - Admin: Review Management
 */
require_once __DIR__ . '/../includes/header.php';
if (!isset($_SESSION['admin_id'])) redirect('admin/login.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $rid = (int) ($_POST['review_id'] ?? 0);
  $approve = isset($_POST['approve']);
  Database::execute('UPDATE reviews SET is_approved = ? WHERE id = ?', [$approve ? 1 : 0, $rid]);
  setFlash('login_success', 'Review updated.', 'success');
  redirect('admin/reviews.php');
}

$reviews = Database::query('SELECT r.*, u.full_name, d.name AS dest_name, h.name AS hotel_name FROM reviews r LEFT JOIN users u ON r.user_id = u.id LEFT JOIN destinations d ON r.destination_id = d.id LEFT JOIN hotels h ON r.hotel_id = h.id ORDER BY r.created_at DESC');
?>
<div class="container">
  <div class="admin-header">
    <h1>Review Management</h1>
    <a href="<?= url('admin/index.php') ?>" class="btn btn-outline">← Dashboard</a>
  </div>

  <div class="table-wrap">
    <table>
      <thead><tr><th>User</th><th>Target</th><th>Rating</th><th>Comment</th><th>Approved</th><th>Date</th><th>Action</th></tr></thead>
      <tbody>
        <?php if ($reviews): foreach ($reviews as $r): ?>
          <tr>
            <td><?= e($r['full_name'] ?? '-') ?></td>
            <td><?= e($r['dest_name'] ?? ($r['hotel_name'] ?? 'General')) ?></td>
            <td><?= str_repeat('★', (int) $r['rating']) ?></td>
            <td><?= e($r['comment'] ?? '-') ?></td>
            <td><span class="badge badge-<?= $r['is_approved'] ? 'success' : 'warning' ?>"><?= $r['is_approved'] ? 'Yes' : 'No' ?></span></td>
            <td><?= date('d M Y', strtotime($r['created_at'])) ?></td>
            <td>
              <form method="POST" style="display:inline;">
                <?= csrfField() ?>
                <input type="hidden" name="review_id" value="<?= $r['id'] ?>">
                <input type="hidden" name="approve" value="1">
                <button type="submit" class="btn btn-sm btn-outline">Approve</button>
              </form>
              <form method="POST" style="display:inline;margin-left:var(--space-xs);">
                <?= csrfField() ?>
                <input type="hidden" name="review_id" value="<?= $r['id'] ?>">
                <input type="hidden" name="approve" value="0">
                <button type="submit" class="btn btn-sm btn-outline">Reject</button>
              </form>
            </td>
          </tr>
        <?php endforeach; else: ?>
          <tr><td colspan="7" style="text-align:center;color:var(--color-muted);">No reviews.</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>