<?php
/**
 * TRAVELMATE AI - Admin Login
 */
require_once __DIR__ . '/../includes/header.php';

$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $email = trim($_POST['email'] ?? '');
  $password = $_POST['password'] ?? '';

  $admin = Database::queryOne('SELECT * FROM admins WHERE email = ? AND status = ?', [$email, 'active']);
  if ($admin && password_verify($password, $admin['password'])) {
    rotateCsrfToken();
    $_SESSION['admin_id'] = (int) $admin['id'];
    $_SESSION['admin_name'] = $admin['full_name'];
    $_SESSION['admin_role'] = $admin['role'];
    Database::execute('UPDATE admins SET last_login_at = NOW() WHERE id = ?', [$admin['id']]);
    redirect('admin/index.php');
  } else {
    $errors[] = 'Invalid admin email or password.';
  }
}
?>
<div class="container" style="max-width:420px; margin: var(--space-xl) auto;">
  <div class="card">
    <div class="card-body">
      <div class="text-center mb-4">
        <div class="brand-mark" style="margin:0 auto var(--space-md);">T</div>
        <h2>Admin Login</h2>
        <p class="small">TRAVELMATE AI Administration</p>
      </div>

      <?php foreach ($errors as $err): ?>
        <div style="background:#fee2e2;color:#991b1b;padding:var(--space-sm);border-radius:var(--radius-md);margin-bottom:var(--space-md);font-size:var(--text-sm);"><?= e($err) ?></div>
      <?php endforeach; ?>

      <form method="POST" action="" novalidate>
        <?= csrfField() ?>
        <div class="form-group">
          <label>Email</label>
          <input type="email" name="email" class="form-control" required value="<?= e($_POST['email'] ?? '') ?>">
        </div>
        <div class="form-group">
          <label>Password</label>
          <input type="password" name="password" class="form-control" required>
        </div>
        <div class="form-group">
          <button type="submit" class="btn btn-primary btn-full btn-lg">Admin Sign in</button>
        </div>
      </form>
      <div class="form-group text-center mt-3">
        <p class="small"><a href="<?= url('auth/login.php') ?>">Customer login</a></p>
      </div>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>