<?php
/**
 * TRAVELMATE AI - Admin: Hotel Management
 */
require_once __DIR__ . '/../includes/header.php';
if (!isset($_SESSION['admin_id'])) redirect('admin/login.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  if ($_POST['action'] === 'add') {
    Database::insert('INSERT INTO hotels (name, city, country, address, description, short_description, rating, stars, price_per_night, amenities, is_available, is_demo) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1)',
      [$_POST['name'], $_POST['city'], $_POST['country'], $_POST['address'], $_POST['description'], $_POST['short_description'], $_POST['rating'], $_POST['stars'], $_POST['price_per_night'], json_encode(['WiFi']), $_POST['is_available'] === '1' ? 1 : 0]);
    setFlash('login_success', 'Hotel added (demo).', 'success');
    redirect('admin/hotels.php');
  } elseif ($_POST['action'] === 'delete') {
    Database::execute('DELETE FROM hotels WHERE id = ?', [(int) $_POST['id']]);
    setFlash('login_success', 'Hotel deleted.', 'success');
    redirect('admin/hotels.php');
  }
}
$hotels = Database::query('SELECT * FROM hotels ORDER BY rating DESC');
?>
<div class="container">
  <div class="admin-header">
    <h1>Hotel Management</h1>
    <a href="<?= url('admin/index.php') ?>" class="btn btn-outline">← Dashboard</a>
    <button class="btn btn-primary" onclick="document.getElementById('addForm').style.display='block'">+ Add Hotel (demo)</button>
  </div>

  <div id="addForm" style="display:none;margin-bottom:var(--space-lg);" class="card">
    <div class="card-body">
      <h3>Add Hotel</h3>
      <form method="POST" class="grid grid-3">
        <?= csrfField() ?>
        <input type="hidden" name="action" value="add">
        <div class="form-group"><label>Name</label><input type="text" name="name" class="form-control" required></div>
        <div class="form-group"><label>City</label><input type="text" name="city" class="form-control" required></div>
        <div class="form-group"><label>Country</label><input type="text" name="country" class="form-control" required></div>
        <div class="form-group" style="grid-column:1/-1;"><label>Address</label><input type="text" name="address" class="form-control"></div>
        <div class="form-group" style="grid-column:1/-1;"><label>Description</label><textarea name="description" class="form-control"></textarea></div>
        <div class="form-group" style="grid-column:1/-1;"><label>Short Description</label><input type="text" name="short_description" class="form-control"></div>
        <div class="form-group"><label>Rating</label><input type="number" name="rating" class="form-control" step="0.1" min="0" max="5" value="4.0"></div>
        <div class="form-group"><label>Stars</label><input type="number" name="stars" class="form-control" min="1" max="5" value="3"></div>
        <div class="form-group"><label>Price per night</label><input type="number" name="price_per_night" class="form-control" required></div>
        <div class="form-group"><label>Available</label><select name="is_available" class="form-select"><option value="1">Yes</option><option value="0">No</option></select></div>
        <div class="form-group" style="grid-column:1/-1;"><button type="submit" class="btn btn-primary">Add Hotel</button></div>
      </form>
    </div>
  </div>

  <div class="table-wrap">
    <table>
      <thead><tr><th>Hotel</th><th>City / Country</th><th>Stars</th><th>Rating</th><th>Price/Night</th><th>Available</th><th>Action</th></tr></thead>
      <tbody>
        <?php if ($hotels): foreach ($hotels as $h): ?>
          <tr>
            <td><?= e($h['name']) ?></td>
            <td><?= e($h['city']) ?>, <?= e($h['country']) ?></td>
            <td><?= (int) $h['stars'] ?>★</td>
            <td><?= e($h['rating']) ?></td>
            <td><?= money($h['price_per_night'], 'INR') ?></td>
            <td><span class="badge badge-<?= $h['is_available'] ? 'success' : 'error' ?>"><?= $h['is_available'] ? 'Yes' : 'No' ?></span></td>
            <td>
              <form method="POST" style="display:inline;" onsubmit="return confirm('Delete this hotel?')">
                <?= csrfField() ?>
                <input type="hidden" name="id" value="<?= $h['id'] ?>">
                <input type="hidden" name="action" value="delete">
                <button type="submit" class="btn btn-sm btn-outline" style="color:var(--color-error);border-color:var(--color-error);">Delete</button>
              </form>
            </td>
          </tr>
        <?php endforeach; else: ?>
          <tr><td colspan="7" style="text-align:center;color:var(--color-muted);">No hotels.</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>