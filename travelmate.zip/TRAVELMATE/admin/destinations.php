<?php
/**
 * TRAVELMATE AI - Admin: Destination Management
 */
require_once __DIR__ . '/../includes/header.php';
if (!isset($_SESSION['admin_id'])) redirect('admin/login.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $action = $_POST['action'] ?? '';
  if ($action === 'add') {
    Database::insert('INSERT INTO destinations (name, country, city, description, short_description, best_season, type, is_popular, is_trending, rating) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
      [$_POST['name'], $_POST['country'], $_POST['city'], $_POST['description'], $_POST['short_description'], $_POST['best_season'], $_POST['type'], !empty($_POST['is_popular']) ? 1 : 0, !empty($_POST['is_trending']) ? 1 : 0, $_POST['rating'] ?? 0]);
    setFlash('login_success', 'Destination added.', 'success');
    redirect('admin/destinations.php');
  } elseif ($action === 'delete') {
    Database::execute('DELETE FROM destinations WHERE id = ?', [(int) $_POST['id']]);
    setFlash('login_success', 'Destination deleted.', 'success');
    redirect('admin/destinations.php');
  }
}

$destinations = Database::query('SELECT * FROM destinations ORDER BY created_at DESC');
?>
<div class="container">
  <div class="admin-header">
    <h1>Destination Management</h1>
    <a href="<?= url('admin/index.php') ?>" class="btn btn-outline">← Dashboard</a>
    <button class="btn btn-primary" onclick="document.getElementById('addForm').style.display='block'">+ Add Destination</button>
  </div>

  <div id="addForm" style="display:none;margin-bottom:var(--space-lg);" class="card">
    <div class="card-body">
      <h3>Add Destination</h3>
      <form method="POST" class="grid grid-2">
        <?= csrfField() ?>
        <input type="hidden" name="action" value="add">
        <div class="form-group"><label>Name</label><input type="text" name="name" class="form-control" required></div>
        <div class="form-group"><label>Country</label><input type="text" name="country" class="form-control" required></div>
        <div class="form-group"><label>City</label><input type="text" name="city" class="form-control" required></div>
        <div class="form-group"><label>Type</label><select name="type" class="form-select"><option value="domestic">Domestic</option><option value="international">International</option></select></div>
        <div class="form-group"><label>Best Season</label><input type="text" name="best_season" class="form-control"></div>
        <div class="form-group"><label>Rating (0-5)</label><input type="number" name="rating" class="form-control" step="0.1" min="0" max="5" value="4.5"></div>
        <div class="form-group" style="grid-column:1/-1;"><label>Description</label><textarea name="description" class="form-control"></textarea></div>
        <div class="form-group" style="grid-column:1/-1;"><label>Short Description</label><input type="text" name="short_description" class="form-control"></div>
        <div class="form-group" style="grid-column:1/-1;display:flex;gap:var(--space-sm);align-items:center;">
          <label><input type="checkbox" name="is_popular" value="1"> Popular</label>
          <label style="margin-left:var(--space-md);"><input type="checkbox" name="is_trending" value="1"> Trending</label>
        </div>
        <div class="form-group" style="grid-column:1/-1;"><button type="submit" class="btn btn-primary">Add Destination</button></div>
      </form>
    </div>
  </div>

  <div class="table-wrap">
    <table>
      <thead>
        <tr><th>Name</th><th>Country / City</th><th>Type</th><th>Popular</th><th>Trending</th><th>Rating</th><th>Action</th></tr>
      </thead>
      <tbody>
        <?php if ($destinations): foreach ($destinations as $d): ?>
          <tr>
            <td><?= e($d['name']) ?></td>
            <td><?= e($d['country']) ?> / <?= e($d['city']) ?></td>
            <td><?= ucfirst(e($d['type'])) ?></td>
            <td><span class="badge badge-<?= $d['is_popular'] ? 'success' : 'error' ?>"><?= $d['is_popular'] ? 'Yes' : 'No' ?></span></td>
            <td><span class="badge badge-<?= $d['is_trending'] ? 'success' : 'error' ?>"><?= $d['is_trending'] ? 'Yes' : 'No' ?></span></td>
            <td><?= e($d['rating']) ?></td>
            <td>
              <form method="POST" style="display:inline;" onsubmit="return confirm('Delete this destination?')">
                <?= csrfField() ?>
                <input type="hidden" name="id" value="<?= $d['id'] ?>">
                <input type="hidden" name="action" value="delete">
                <button type="submit" class="btn btn-sm btn-outline" style="color:var(--color-error);border-color:var(--color-error);">Delete</button>
              </form>
            </td>
          </tr>
        <?php endforeach; else: ?>
          <tr><td colspan="7" style="text-align:center;color:var(--color-muted);">No destinations.</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>