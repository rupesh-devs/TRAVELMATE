<?php
/**
 * TRAVELMATE AI - Admin: User Management
 */
require_once __DIR__ . '/../includes/header.php';
if (!isset($_SESSION['admin_id'])) redirect('admin/login.php');

$users = Database::query('SELECT u.*, COALESCE(SUM(r.points),0) AS points FROM users u LEFT JOIN rewards r ON u.id = r.user_id WHERE u.role = "user" GROUP BY u.id ORDER BY u.created_at DESC');
$message = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $action = $_POST['action'] ?? '';
  $uid = (int) ($_POST['user_id'] ?? 0);
  if ($action === 'suspend' || $action === 'activate') {
    Database::execute('UPDATE users SET status = ? WHERE id = ?', [$action === 'activate' ? 'active' : 'suspended', $uid]);
    $message = ['User status updated.', 'success'];
  } elseif ($action === 'delete') {
    Database::execute('DELETE FROM users WHERE id = ?', [$uid]);
    $message = ['User deleted.', 'success'];
  }
}
?>
<div class="container">
  <div class="admin-header">
    <h1>User Management</h1>
    <a href="<?= url('admin/index.php') ?>" class="btn btn-outline">← Dashboard</a>
  </div>

  <?php if ($message): ?>
    <div style="background:#dcfce7;color:#14532d;padding:var(--space-sm);border-radius:var(--radius-md);margin-bottom:var(--space-lg);font-size:var(--text-sm);"><?= e($message[0]) ?></div>
  <?php endif; ?>

  <div class="table-wrap">
    <table>
      <thead>
        <tr><th>ID</th><th>Name</th><th>Email</th><th>Mobile</th><th>Country</th><th>Status</th><th>Reward Points</th><th>Joined</th><th>Action</th></tr>
      </thead>
      <tbody>
        <?php if ($users): foreach ($users as $u): ?>
          <tr>
            <td><?= $u['id'] ?></td>
            <td><?= e($u['full_name']) ?></td>
            <td><?= e($u['email']) ?></td>
            <td><?= e($u['mobile'] ?? '-') ?></td>
            <td><?= e($u['country']) ?></td>
            <td><span class="badge badge-<?= $u['status'] === 'active' ? 'success' : 'error' ?>"><?= ucfirst(e($u['status'])) ?></span></td>
            <td><?= (int) $u['points'] ?></td>
            <td><?= date('d M Y', strtotime($u['created_at'])) ?></td>
            <td>
              <form method="POST" style="display:inline;" onsubmit="return confirm('<?= $u['status'] === 'active' ? 'Suspend' : 'Activate' ?> this user?')">
                <?= csrfField() ?>
                <input type="hidden" name="user_id" value="<?= $u['id'] ?>">
                <input type="hidden" name="action" value="<?= $u['status'] === 'active' ? 'suspend' : 'activate' ?>">
                <button type="submit" class="btn btn-sm btn-outline"><?= $u['status'] === 'active' ? 'Suspend' : 'Activate' ?></button>
              </form>
              <form method="POST" style="display:inline;margin-left:var(--space-xs);" onsubmit="return confirm('Delete this user?')">
                <?= csrfField() ?>
                <input type="hidden" name="user_id" value="<?= $u['id'] ?>">
                <input type="hidden" name="action" value="delete">
                <button type="submit" class="btn btn-sm btn-outline" style="color:var(--color-error);border-color:var(--color-error);">Delete</button>
              </form>
            </td>
          </tr>
        <?php endforeach; else: ?>
          <tr><td colspan="9" style="text-align:center;color:var(--color-muted);">No users.</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>