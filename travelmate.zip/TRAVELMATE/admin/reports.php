<?php
/**
 * TRAVELMATE AI - Admin: Reports & Analytics
 */
require_once __DIR__ . '/../includes/header.php';
if (!isset($_SESSION['admin_id'])) redirect('admin/login.php');

$revenueByMonth = Database::query("SELECT DATE_FORMAT(created_at, '%Y-%m') AS name, COALESCE(SUM(total_amount),0) AS value FROM bookings WHERE payment_status = 'paid' AND created_at >= DATE_SUB(NOW(), INTERVAL 6 MONTH) GROUP BY name ORDER BY name");
$bookingsByStatus = Database::query("SELECT status AS name, COUNT(*) AS value FROM bookings GROUP BY status");
$topDestinations = Database::query("SELECT destination AS name, COUNT(*) AS value FROM bookings WHERE destination IS NOT NULL AND destination <> '' GROUP BY destination ORDER BY value DESC LIMIT 5");
?>
<div class="container">
  <div class="admin-header">
    <h1>Reports &amp; Analytics</h1>
    <a href="<?= url('admin/index.php') ?>" class="btn btn-outline">← Dashboard</a>
  </div>

  <div class="admin-grid">
    <div class="admin-card">
      <div class="admin-card-header"><h3>Revenue by Month (verified payments)</h3></div>
      <div class="admin-card-body"><canvas id="revenueChart" style="height:300px;"></canvas></div>
    </div>
    <div class="admin-card">
      <div class="admin-card-header"><h3>Bookings by Status</h3></div>
      <div class="admin-card-body"><canvas id="statusChart" style="height:300px;"></canvas></div>
    </div>
    <div class="admin-card" style="grid-column:1/-1;">
      <div class="admin-card-header"><h3>Top Destinations</h3></div>
      <div class="admin-card-body">
        <div class="table-wrap" style="border:none;">
          <table>
            <thead><tr><th>Destination</th><th>Bookings</th></tr></thead>
            <tbody>
              <?php if ($topDestinations): foreach ($topDestinations as $t): ?>
                <tr><td><?= e($t['name']) ?></td><td><?= (int) $t['value'] ?></td></tr>
              <?php else: ?><tr><td colspan="2" style="text-align:center;color:var(--color-muted);">No data.</td></tr><?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>

<script>
new Chart(document.getElementById('revenueChart'), {
  type: 'bar',
  data: {
    labels: <?= json_encode(array_column($revenueByMonth ?? [], 'name')) ?>,
    datasets: [{ label: 'Revenue (INR)', data: <?= json_encode(array_column($revenueByMonth ?? [], 'value')) ?>, backgroundColor: '#38bdf8' }]
  },
  options: { responsive: true, plugins: { title: { display: true, text: 'Monthly Revenue' } } }
});
new Chart(document.getElementById('statusChart'), {
  type: 'pie',
  data: {
    labels: <?= json_encode(array_column($bookingsByStatus ?? [], 'name')) ?>,
    datasets: [{ data: <?= json_encode(array_column($bookingsByStatus ?? [], 'value')) ?>, backgroundColor: ['#10b981','#f59e0b','#ef4444','#38bdf8'] }]
  },
  options: { responsive: true, plugins: { title: { display: true, text: 'Booking Status Distribution' } } }
});
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>