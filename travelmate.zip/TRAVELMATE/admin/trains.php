<?php
/**
 * TRAVELMATE AI - Admin: Train Management
 */
require_once __DIR__ . '/../includes/header.php';
if (!isset($_SESSION['admin_id'])) redirect('admin/login.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  if ($_POST['action'] === 'add') {
    Database::insert('INSERT INTO trains (train_number, train_name, source, destination, departure_time, arrival_time, duration, classes_available, price_sleeper, price_3ac, price_2ac, price_1ac, status, is_demo) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1)',
      [$_POST['train_number'], $_POST['train_name'], $_POST['source'], $_POST['destination'], $_POST['departure_time'], $_POST['arrival_time'], $_POST['duration'], json_encode(['SL','3A','2A','1A']), $_POST['price_sleeper'], $_POST['price_3ac'], $_POST['price_2ac'], $_POST['price_1ac'], $_POST['status']]);
    setFlash('login_success', 'Train added (demo — not official Indian Railways).', 'success');
    redirect('admin/trains.php');
  } elseif ($_POST['action'] === 'delete') {
    Database::execute('DELETE FROM trains WHERE id = ?', [(int) $_POST['id']]);
    setFlash('login_success', 'Train deleted.', 'success');
    redirect('admin/trains.php');
  }
}
$trains = Database::query('SELECT * FROM trains ORDER BY train_number');
?>
<div class="container">
  <div class="admin-header">
    <h1>Train Management</h1>
    <a href="<?= url('admin/index.php') ?>" class="btn btn-outline">← Dashboard</a>
    <button class="btn btn-primary" onclick="document.getElementById('addForm').style.display='block'">+ Add Train (demo)</button>
  </div>

  <div id="addForm" style="display:none;margin-bottom:var(--space-lg);" class="card">
    <div class="card-body">
      <h3>Add Train</h3>
      <form method="POST" class="grid grid-3">
        <?= csrfField() ?>
        <input type="hidden" name="action" value="add">
        <div class="form-group"><label>Train No.</label><input type="text" name="train_number" class="form-control" required></div>
        <div class="form-group"><label>Train Name</label><input type="text" name="train_name" class="form-control" required></div>
        <div class="form-group"><label>Source</label><input type="text" name="source" class="form-control" required></div>
        <div class="form-group"><label>Destination</label><input type="text" name="destination" class="form-control" required></div>
        <div class="form-group"><label>Departure Time</label><input type="time" name="departure_time" class="form-control" required></div>
        <div class="form-group"><label>Arrival Time</label><input type="time" name="arrival_time" class="form-control" required></div>
        <div class="form-group"><label>Duration</label><input type="text" name="duration" class="form-control" placeholder="8h 00m"></div>
        <div class="form-group"><label>Sleeper Price</label><input type="number" name="price_sleeper" class="form-control"></div>
        <div class="form-group"><label>3AC Price</label><input type="number" name="price_3ac" class="form-control"></div>
        <div class="form-group"><label>2AC Price</label><input type="number" name="price_2ac" class="form-control"></div>
        <div class="form-group"><label>1AC Price</label><input type="number" name="price_1ac" class="form-control"></div>
        <div class="form-group"><label>Status</label><select name="status" class="form-select"><option value="scheduled">Scheduled</option><option value="cancelled">Cancelled</option></select></div>
        <div class="form-group" style="grid-column:1/-1;"><button type="submit" class="btn btn-primary">Add Train</button></div>
      </form>
    </div>
  </div>

  <div class="table-wrap">
    <table>
      <thead><tr><th>Train No. / Name</th><th>Route</th><th>Departs</th><th>Arrives</th><th>Duration</th><th>Sleeper</th><th>3AC</th><th>Status</th><th>Action</th></tr></thead>
      <tbody>
        <?php if ($trains): foreach ($trains as $t): ?>
          <tr>
            <td><?= e($t['train_number']) ?> <span class="small">(<?= e($t['train_name']) ?>)</span></td>
            <td><?= e($t['source']) ?> → <?= e($t['destination']) ?></td>
            <td><?= e($t['departure_time']) ?></td>
            <td><?= e($t['arrival_time']) ?></td>
            <td><?= e($t['duration']) ?></td>
            <td><?= money($t['price_sleeper'], 'INR') ?></td>
            <td><?= money($t['price_3ac'], 'INR') ?></td>
            <td><span class="badge badge-<?= $t['status'] === 'scheduled' ? 'success' : 'error' ?>"><?= ucfirst(e($t['status'])) ?></span></td>
            <td>
              <form method="POST" style="display:inline;" onsubmit="return confirm('Delete this train?')">
                <?= csrfField() ?>
                <input type="hidden" name="id" value="<?= $t['id'] ?>">
                <input type="hidden" name="action" value="delete">
                <button type="submit" class="btn btn-sm btn-outline" style="color:var(--color-error);border-color:var(--color-error);">Delete</button>
              </form>
            </td>
          </tr>
        <?php endforeach; else: ?>
          <tr><td colspan="9" style="text-align:center;color:var(--color-muted);">No trains.</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>

  <div class="demo-notice" style="margin-top:var(--space-lg);max-width:700px;">
    <strong>Important:</strong> All train bookings in TRAVELMATE AI are simulated demo data. This platform is not affiliated with Indian Railways and does not issue official railway tickets.
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>