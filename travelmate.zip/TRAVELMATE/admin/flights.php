<?php
/**
 * TRAVELMATE AI - Admin: Flight Management
 */
require_once __DIR__ . '/../includes/header.php';
if (!isset($_SESSION['admin_id'])) redirect('admin/login.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  if ($_POST['action'] === 'add') {
    Database::insert('INSERT INTO flights (airline, flight_number, source, destination, departure_time, arrival_time, duration, price_economy, price_business, price_first, total_seats, available_seats, status, is_demo) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1)',
      [$_POST['airline'], $_POST['flight_number'], $_POST['source'], $_POST['destination'], $_POST['departure_time'], $_POST['arrival_time'], $_POST['duration'], $_POST['price_economy'], $_POST['price_business'], $_POST['price_first'], $_POST['total_seats'], $_POST['total_seats'], $_POST['status']]);
    setFlash('login_success', 'Flight added (demo).', 'success');
    redirect('admin/flights.php');
  } elseif ($_POST['action'] === 'delete') {
    Database::execute('DELETE FROM flights WHERE id = ?', [(int) $_POST['id']]);
    setFlash('login_success', 'Flight deleted.', 'success');
    redirect('admin/flights.php');
  }
}
$flights = Database::query('SELECT * FROM flights ORDER BY departure_time DESC');
?>
<div class="container">
  <div class="admin-header">
    <h1>Flight Management</h1>
    <a href="<?= url('admin/index.php') ?>" class="btn btn-outline">← Dashboard</a>
    <button class="btn btn-primary" onclick="document.getElementById('addForm').style.display='block'">+ Add Flight (demo)</button>
  </div>

  <div id="addForm" style="display:none;margin-bottom:var(--space-lg);" class="card">
    <div class="card-body">
      <h3>Add Flight</h3>
      <form method="POST" class="grid grid-3">
        <?= csrfField() ?>
        <input type="hidden" name="action" value="add">
        <div class="form-group"><label>Airline</label><input type="text" name="airline" class="form-control" required></div>
        <div class="form-group"><label>Flight No.</label><input type="text" name="flight_number" class="form-control" required></div>
        <div class="form-group"><label>Source</label><input type="text" name="source" class="form-control" required></div>
        <div class="form-group"><label>Destination</label><input type="text" name="destination" class="form-control" required></div>
        <div class="form-group"><label>Departure</label><input type="datetime-local" name="departure_time" class="form-control" required></div>
        <div class="form-group"><label>Arrival</label><input type="datetime-local" name="arrival_time" class="form-control" required></div>
        <div class="form-group"><label>Duration</label><input type="text" name="duration" class="form-control" placeholder="2h 00m"></div>
        <div class="form-group"><label>Economy Price</label><input type="number" name="price_economy" class="form-control" required></div>
        <div class="form-group"><label>Business Price</label><input type="number" name="price_business" class="form-control"></div>
        <div class="form-group"><label>First Price</label><input type="number" name="price_first" class="form-control"></div>
        <div class="form-group"><label>Total Seats</label><input type="number" name="total_seats" class="form-control" value="180" required></div>
        <div class="form-group"><label>Status</label><select name="status" class="form-select"><option value="scheduled">Scheduled</option><option value="cancelled">Cancelled</option></select></div>
        <div class="form-group" style="grid-column:1/-1;"><button type="submit" class="btn btn-primary">Add Flight</button></div>
      </form>
    </div>
  </div>

  <div class="table-wrap">
    <table>
      <thead><tr><th>Airline / No.</th><th>Route</th><th>Departs</th><th>Arrives</th><th>Duration</th><th>Economy Price</th><th>Seats</th><th>Status</th><th>Action</th></tr></thead>
      <tbody>
        <?php if ($flights): foreach ($flights as $f): ?>
          <tr>
            <td><?= e($f['airline']) ?> <span class="small">(<?= e($f['flight_number']) ?>)</span></td>
            <td><?= e($f['source']) ?> → <?= e($f['destination']) ?></td>
            <td><?= date('d M, H:i', strtotime($f['departure_time'])) ?></td>
            <td><?= date('d M, H:i', strtotime($f['arrival_time'])) ?></td>
            <td><?= e($f['duration']) ?></td>
            <td><?= money($f['price_economy'], 'INR') ?></td>
            <td><?= e($f['available_seats']) ?> / <?= e($f['total_seats']) ?></td>
            <td><span class="badge badge-<?= $f['status'] === 'scheduled' ? 'success' : 'error' ?>"><?= ucfirst(e($f['status'])) ?></span></td>
            <td>
              <form method="POST" style="display:inline;" onsubmit="return confirm('Delete this flight?')">
                <?= csrfField() ?>
                <input type="hidden" name="id" value="<?= $f['id'] ?>">
                <input type="hidden" name="action" value="delete">
                <button type="submit" class="btn btn-sm btn-outline" style="color:var(--color-error);border-color:var(--color-error);">Delete</button>
              </form>
            </td>
          </tr>
        <?php endforeach; else: ?>
          <tr><td colspan="9" style="text-align:center;color:var(--color-muted);">No flights.</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>