<?php
/**
 * TRAVELMATE AI - Admin: Refund Management
 */
require_once __DIR__ . '/../includes/header.php';
if (!isset($_SESSION['admin_id'])) redirect('admin/login.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $rid = (int) ($_POST['refund_id'] ?? 0);
  $status = $_POST['status'] ?? 'rejected';
  Database::execute('UPDATE refunds SET status = ?, processed_at = NOW() WHERE id = ?', [$status, $rid]);
  if ($status === 'processed') {
    $refund = Database::queryOne('SELECT * FROM refunds WHERE id = ?', [$rid]);
    Database::execute('UPDATE bookings SET status = ? WHERE id = ?', ['refunded', $refund['booking_id']]);
  }
  setFlash('login_success', 'Refund updated.', 'success');
  redirect('admin/refunds.php');
}

$refunds = Database::query('SELECT r.*, u.full_name, b.reference FROM refunds r LEFT JOIN users u ON r.user_id = u.id LEFT JOIN bookings b ON r.booking_id = b.id ORDER BY r.created_at DESC');
?>
<div class="container">
  <div class="admin-header">
    <h1>Refund Management</h1>
    <a href="<?= url('admin/index.php') ?>" class="btn btn-outline">← Dashboard</a>
  </div>

  <div class="table-wrap">
    <table>
      <thead><tr><th>Refund ID</th><th>User</th><th>Booking</th><th>Amount</th><th>Reason</th><th>Status</th><th>Requested</th><th>Action</th></tr></thead>
      <tbody>
        <?php if ($refunds): foreach ($refunds as $r): ?>
          <tr>
            <td>#<?= $r['id'] ?></td>
            <td><?= e($r['full_name'] ?? '-') ?></td>
            <td><?= e($r['reference'] ?? '-') ?></td>
            <td><?= money($r['amount'], $r['currency']) ?></td>
            <td><?= e($r['reason'] ?? '-') ?></td>
            <td><span class="badge badge-<?= $r['status'] === 'processed' ? 'success' : ($r['status'] === 'rejected' ? 'error' : 'warning') ?>"><?= ucfirst(e($r['status'])) ?></span></td>
            <td><?= date('d M Y', strtotime($r['created_at'])) ?></td>
            <td>
              <form method="POST" style="display:inline;">
                <?= csrfField() ?>
                <input type="hidden" name="refund_id" value="<?= $r['id'] ?>">
                <input type="hidden" name="status" value="approved">
                <button type="submit" class="btn btn-sm btn-outline">Approve</button>
              </form>
              <form method="POST" style="display:inline;margin-left:var(--space-xs);">
                <?= csrfField() ?>
                <input type="hidden" name="refund_id" value="<?= $r['id'] ?>">
                <input type="hidden" name="status" value="processed">
                <button type="submit" class="btn btn-sm btn-outline">Process</button>
              </form>
              <form method="POST" style="display:inline;margin-left:var(--space-xs);">
                <?= csrfField() ?>
                <input type="hidden" name="refund_id" value="<?= $r['id'] ?>">
                <input type="hidden" name="status" value="rejected">
                <button type="submit" class="btn btn-sm btn-outline" style="color:var(--color-error);border-color:var(--color-error);">Reject</button>
              </form>
            </td>
          </tr>
        <?php endforeach; else: ?>
          <tr><td colspan="8" style="text-align:center;color:var(--color-muted);">No refunds.</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>