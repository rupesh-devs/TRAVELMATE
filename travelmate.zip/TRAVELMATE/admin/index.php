<?php
/**
 * TRAVELMATE AI - Admin Dashboard
 */
require_once __DIR__ . '/../includes/header.php';

$adminId = $_SESSION['admin_id'] ?? null;
if (!$adminId) redirect('admin/login.php');

$totalUsers   = (int) Database::queryOne('SELECT COUNT(*) AS c FROM users WHERE role = "user"')['c'];
$totalBookings= (int) Database::queryOne('SELECT COUNT(*) AS c FROM bookings')['c'];
$confirmed    = (int) Database::queryOne("SELECT COUNT(*) AS c FROM bookings WHERE status = 'confirmed'")['c'];
$cancelled    = (int) Database::queryOne("SELECT COUNT(*) AS c FROM bookings WHERE status = 'cancelled'")['c'];
$revenueRow   = Database::queryOne("SELECT COALESCE(SUM(total_amount),0) AS c FROM bookings WHERE payment_status = 'paid'")['c'];
$revenue      = (float) ($revenueRow['c'] ?? 0);
$pendingRefunds = (int) Database::queryOne("SELECT COUNT(*) AS c FROM refunds WHERE status = 'requested'")['c'];

// Bookings by type (for chart)
$bookingsByType = Database::query("SELECT booking_type AS name, COUNT(*) AS value FROM bookings GROUP BY booking_type");

// Bookings over last 7 days
$bookingsByDay = Database::query("SELECT DATE(created_at) AS name, COUNT(*) AS value FROM bookings WHERE created_at >= DATE_SUB(NOW(), INTERVAL 6 DAY) GROUP BY DATE(created_at) ORDER BY name");
?>
<div class="container">
  <div class="admin-header">
    <div>
      <h1>Admin Dashboard</h1>
      <p class="small">Welcome back, <?= e($_SESSION['admin_name'] ?? 'Admin') ?></p>
    </div>
    <a href="<?= url('admin/login.php') ?>" style="text-decoration:none;">
      <form method="POST" action="<?= url('admin/logout.php') ?>" style="display:inline;" onsubmit="return confirm('Sign out?')">
        <button type="submit" class="btn btn-outline">Sign out</button>
      </form>
    </a>
  </div>

  <div class="admin-stats">
    <div class="stat-card">
      <div class="label">Total Users</div>
      <div class="value"><?= $totalUsers ?></div>
    </div>
    <div class="stat-card">
      <div class="label">Total Bookings</div>
      <div class="value"><?= $totalBookings ?></div>
    </div>
    <div class="stat-card">
      <div class="label">Revenue (verified)</div>
      <div class="value"><?= money($revenue) ?></div>
      <div class="change change-up">Only successful payments</div>
    </div>
    <div class="stat-card">
      <div class="label">Pending Refunds</div>
      <div class="value"><?= $pendingRefunds ?></div>
      <div class="change change-up">Awaiting action</div>
    </div>
  </div>

  <div class="admin-grid">
    <div class="admin-card">
      <div class="admin-card-header">
        <h3>Bookings by Type</h3>
      </div>
      <div class="admin-card-body">
        <canvas id="bookingsChart"></canvas>
      </div>
    </div>
    <div class="admin-card">
      <div class="admin-card-header">
        <h3>Bookings (Last 7 Days)</h3>
      </div>
      <div class="admin-card-body">
        <canvas id="trendChart"></canvas>
      </div>
    </div>
  </div>

  <div class="admin-card" style="margin-top:var(--space-lg);">
    <div class="admin-card-header">
      <h3>Recent Bookings</h3>
    </div>
    <div class="admin-card-body">
      <div class="table-wrap">
        <table>
          <thead>
            <tr><th>Reference</th><th>User</th><th>Type</th><th>Amount</th><th>Status</th><th>Date</th></tr>
          </thead>
          <tbody>
            <?php $recent = Database::query('SELECT b.*, u.full_name FROM bookings b LEFT JOIN users u ON b.user_id = u.id ORDER BY b.created_at DESC LIMIT 8'); ?>
            <?php if ($recent): foreach ($recent as $b): ?>
              <tr>
                <td><?= e($b['reference']) ?></td>
                <td><?= e($b['full_name'] ?? '-') ?></td>
                <td><?= ucfirst(e($b['booking_type'])) ?></td>
                <td><?= money($b['total_amount'], $b['currency']) ?></td>
                <td><span class="badge badge-<?= $b['status'] === 'confirmed' ? 'success' : ($b['status'] === 'cancelled' ? 'error' : 'warning') ?>"><?= ucfirst(e($b['status'])) ?></span></td>
                <td><?= date('d M, H:i', strtotime($b['created_at'])) ?></td>
              </tr>
            <?php endforeach; else: ?>
              <tr><td colspan="6" style="text-align:center;color:var(--color-muted);">No bookings.</td></tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>

<script>
new Chart(document.getElementById('bookingsChart'), {
  type: 'doughnut',
  data: {
    labels: <?= json_encode(array_column($bookingsByType ?? [], 'name')) ?>,
    datasets: [{ data: <?= json_encode(array_column($bookingsByType ?? [], 'value')) ?>, backgroundColor: ['#38bdf8','#f59e0b','#10b981','#ef4444'] }]
  },
  options: { responsive: true, plugins: { legend: { position: 'bottom' }, title: { display: true, text: 'Bookings by Type' } } }
});
new Chart(document.getElementById('trendChart'), {
  type: 'line',
  data: {
    labels: <?= json_encode(array_column($bookingsByDay ?? [], 'name')) ?>,
    datasets: [{ label: 'Bookings', data: <?= json_encode(array_column($bookingsByDay ?? [], 'value')) ?>, borderColor: '#38bdf8', fill: false, tension: 0.3 }]
  },
  options: { responsive: true, plugins: { title: { display: true, text: 'Daily Bookings' } } }
});
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>