<?php
/**
 * TRAVELMATE AI - Admin: Bus Management
 */
require_once __DIR__ . '/../includes/header.php';
if (!isset($_SESSION['admin_id'])) redirect('admin/login.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  if ($_POST['action'] === 'add') {
    Database::insert('INSERT INTO buses (operator, bus_number, source, destination, departure_time, arrival_time, duration, bus_type, price, total_seats, available_seats, amenities, status, is_demo) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1)',
      [$_POST['operator'], $_POST['bus_number'], $_POST['source'], $_POST['destination'], $_POST['departure_time'], $_POST['arrival_time'], $_POST['duration'], $_POST['bus_type'], $_POST['price'], $_POST['total_seats'], $_POST['total_seats'], json_encode(['WiFi','Water']), $_POST['status']]);
    setFlash('login_success', 'Bus added (demo).', 'success');
    redirect('admin/buses.php');
  } elseif ($_POST['action'] === 'delete') {
    Database::execute('DELETE FROM buses WHERE id = ?', [(int) $_POST['id']]);
    setFlash('login_success', 'Bus deleted.', 'success');
    redirect('admin/buses.php');
  }
}
$buses = Database::query('SELECT * FROM buses ORDER BY departure_time DESC');
?>
<div class="container">
  <div class="admin-header">
    <h1>Bus Management</h1>
    <a href="<?= url('admin/index.php') ?>" class="btn btn-outline">← Dashboard</a>
    <button class="btn btn-primary" onclick="document.getElementById('addForm').style.display='block'">+ Add Bus (demo)</button>
  </div>

  <div id="addForm" style="display:none;margin-bottom:var(--space-lg);" class="card">
    <div class="card-body">
      <h3>Add Bus</h3>
      <form method="POST" class="grid grid-3">
        <?= csrfField() ?>
        <input type="hidden" name="action" value="add">
        <div class="form-group"><label>Operator</label><input type="text" name="operator" class="form-control" required></div>
        <div class="form-group"><label>Bus No.</label><input type="text" name="bus_number" class="form-control" required></div>
        <div class="form-group"><label>Source</label><input type="text" name="source" class="form-control" required></div>
        <div class="form-group"><label>Destination</label><input type="text" name="destination" class="form-control" required></div>
        <div class="form-group"><label>Departure</label><input type="datetime-local" name="departure_time" class="form-control" required></div>
        <div class="form-group"><label>Arrival</label><input type="datetime-local" name="arrival_time" class="form-control" required></div>
        <div class="form-group"><label>Duration</label><input type="text" name="duration" class="form-control" placeholder="14h 00m"></div>
        <div class="form-group"><label>Type</label><select name="bus_type" class="form-select"><option value="AC Sleeper">AC Sleeper</option><option value="AC Seater">AC Seater</option><option value="Non-AC Sleeper">Non-AC Sleeper</option></select></div>
        <div class="form-group"><label>Price</label><input type="number" name="price" class="form-control" required></div>
        <div class="form-group"><label>Total Seats</label><input type="number" name="total_seats" class="form-control" value="40" required></div>
        <div class="form-group"><label>Status</label><select name="status" class="form-select"><option value="scheduled">Scheduled</option><option value="cancelled">Cancelled</option></select></div>
        <div class="form-group" style="grid-column:1/-1;"><button type="submit" class="btn btn-primary">Add Bus</button></div>
      </form>
    </div>
  </div>

  <div class="table-wrap">
    <table>
      <thead><tr><th>Operator / No.</th><th>Route</th><th>Departs</th><th>Arrives</th><th>Type</th><th>Price</th><th>Seats</th><th>Status</th><th>Action</th></tr></thead>
      <tbody>
        <?php if ($buses): foreach ($buses as $b): ?>
          <tr>
            <td><?= e($b['operator']) ?> <span class="small">(<?= e($b['bus_number']) ?>)</span></td>
            <td><?= e($b['source']) ?> → <?= e($b['destination']) ?></td>
            <td><?= date('d M, H:i', strtotime($b['departure_time'])) ?></td>
            <td><?= date('d M, H:i', strtotime($b['arrival_time'])) ?></td>
            <td><?= e($b['bus_type']) ?></td>
            <td><?= money($b['price'], 'INR') ?></td>
            <td><?= e($b['available_seats']) ?> / <?= e($b['total_seats']) ?></td>
            <td><span class="badge badge-<?= $b['status'] === 'scheduled' ? 'success' : 'error' ?>"><?= ucfirst(e($b['status'])) ?></span></td>
            <td>
              <form method="POST" style="display:inline;" onsubmit="return confirm('Delete this bus?')">
                <?= csrfField() ?>
                <input type="hidden" name="id" value="<?= $b['id'] ?>">
                <input type="hidden" name="action" value="delete">
                <button type="submit" class="btn btn-sm btn-outline" style="color:var(--color-error);border-color:var(--color-error);">Delete</button>
              </form>
            </td>
          </tr>
        <?php endforeach; else: ?>
          <tr><td colspan="9" style="text-align:center;color:var(--color-muted);">No buses.</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>