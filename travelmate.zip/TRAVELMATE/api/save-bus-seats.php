<?php
/**
 * TRAVELMATE AI - Save selected bus seats to session
 */
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/functions.php';

header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
  http_response_code(405);
  echo json_encode(['success' => false, 'error' => 'Method not allowed']);
  exit;
}

$input = json_decode(file_get_contents('php://input'), true) ?: [];
if (!verifyCsrf($input['csrf_token'] ?? '')) {
  http_response_code(403);
  echo json_encode(['success' => false, 'error' => 'Invalid CSRF token']);
  exit;
}

$_SESSION['temp_bus_seats'] = $input['seats'] ?? [];
$_SESSION['temp_bus_price'] = $input['price'] ?? 0;
$_SESSION['temp_bus_id'] = $input['bus'] ?? 0;

echo json_encode(['success' => true]);