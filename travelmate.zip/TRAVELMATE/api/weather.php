<?php
/**
 * TRAVELMATE AI - Weather API Proxy (OpenWeatherMap)
 * Demo fallback when no API key configured.
 */
require_once __DIR__ . '/../config/config.php';
header('Content-Type: application/json; charset=utf-8');

$city = $_GET['city'] ?? '';
if (!$city) {
  http_response_code(400);
  echo json_encode(['success' => false, 'error' => 'City required']);
  exit;
}

if (empty(WEATHER_API_KEY) || DEMO_MODE) {
  echo json_encode([
    'success' => true,
    'demo' => true,
    'city' => $city,
    'temperature' => 22,
    'feels_like' => 20,
    'condition' => 'Partly cloudy',
    'icon' => '02d',
    'humidity' => 65,
    'wind_speed' => 12,
    'forecast' => [
      ['day' => 'Today', 'high' => 25, 'low' => 18, 'condition' => 'Sunny'],
      ['day' => 'Tomorrow', 'high' => 23, 'low' => 16, 'condition' => 'Cloudy'],
      ['day' => 'Day 3', 'high' => 26, 'low' => 19, 'condition' => 'Rain'],
    ],
    'updated_at' => date('Y-m-d H:i:s'),
  ]);
  exit;
}

try {
  $url = WEATHER_API_URL . '/weather?q=' . urlencode($city) . '&appid=' . WEATHER_API_KEY . '&units=metric';
  $ch = curl_init($url);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
  curl_setopt($ch, CURLOPT_TIMEOUT, 15);
  $res = curl_exec($ch);
  $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
  curl_close($ch);

  if ($code !== 200) throw new Exception('Weather API error: ' . $code);
  $d = json_decode($res, true);

  echo json_encode([
    'success' => true,
    'city' => $d['name'],
    'temperature' => (float) $d['main']['temp'],
    'feels_like' => (float) $d['main']['feels_like'],
    'condition' => ucfirst($d['weather'][0]['description']),
    'icon' => $d['weather'][0]['icon'],
    'humidity' => (int) $d['main']['humidity'],
    'wind_speed' => (float) $d['wind']['speed'],
    'updated_at' => date('Y-m-d H:i:s'),
  ]);
} catch (Exception $e) {
  error_log('Weather error: ' . $e->getMessage());
  http_response_code(500);
  echo json_encode(['success' => false, 'error' => 'Weather unavailable']);
}