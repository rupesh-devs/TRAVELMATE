<?php
/**
 * TRAVELMATE AI - Gemini API Proxy
 * Server-side proxy so the API key is never exposed to the frontend.
 * Accepts POST { message, history, language } and returns Gemini's response.
 */
require_once __DIR__ . '/../config/config.php';

header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Method not allowed']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true) ?: [];
$message = trim($input['message'] ?? '');
$history = $input['history'] ?? [];
$language = $input['language'] ?? 'en';

if (!$message) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Message is required']);
    exit;
}

if (empty(GEMINI_API_KEY) || DEMO_MODE) {
    // Demo mode: intelligent local fallback responses
    echo json_encode([
        'success' => true,
        'demo' => true,
        'reply' => demoGeminiReply($message, $language)
    ]);
    exit;
}

try {
    // Build conversation for Gemini
    $systemInstruction = "You are TRAVELMATE AI, a helpful travel assistant. Reply in " . ($language === 'hi' ? 'Hindi (Hinglish ok)' : 'English') . ". "
        . "Help with itineraries, budgets, packing, destinations, and travel advice. Be concise and friendly.";

    $contents = [];
    foreach ($history as $h) {
        $contents[] = ['role' => $h['role'] === 'user' ? 'user' : 'model', 'parts' => [['text' => $h['text']]]];
    }
    $contents[] = ['role' => 'user', 'parts' => [['text' => $message]]];

    $payload = [
        'contents' => $contents,
        'generationConfig' => ['temperature' => 0.7, 'maxOutputTokens' => 800]
    ];
    if (!empty($systemInstruction)) {
        $payload['systemInstruction'] = ['parts' => [['text' => $systemInstruction]]];
    }

    $url = GEMINI_API_URL . '/' . GEMINI_MODEL . ':generateContent?key=' . GEMINI_API_KEY;
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);
    $res = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($httpCode !== 200 || !$res) {
        throw new Exception('Gemini API error: ' . $httpCode);
    }

    $data = json_decode($res, true);
    $reply = $data['candidates'][0]['content']['parts'][0]['text'] ?? 'Sorry, I could not generate a response.';

    echo json_encode(['success' => true, 'reply' => $reply]);
} catch (Exception $e) {
    error_log('Gemini proxy error: ' . $e->getMessage());
    echo json_encode([
        'success' => true,
        'demo' => true,
        'reply' => demoGeminiReply($message, $language)
    ]);
}

function demoGeminiReply(string $message, string $language): string
{
    $m = strtolower($message);
    $hi = $language === 'hi';

    if (preg_match('/plan.*(\d+).*day.*(?:from|to|from\s+\w+\s+to\s+\w+)/', $m) || preg_match('/(?:plan|itinerary)/', $m)) {
        return $hi
            ? "मैं आपकी यात्रा की योजना बनाने में मदद कर सकता हूँ। कृपया बताएं: शुरू करने वाला शहर, गंतव्य, तारीखें, बजट और यात्री संख्या।"
            : "I can help you plan your trip. Please tell me: starting city, destination, travel dates, budget, and number of travellers. I'll create a day-wise itinerary with cost estimates.";
    }
    if (preg_match('/budget|₹|rs\.|rupee|dollar/', $m)) {
        return $hi
            ? "बजट के हिसाब से सुझाव के लिए, अपना बजट और गंतव्य बताएं। मैं किफायती होटल, खाना और परिवहन का अनुमान लगा दूंगा।"
            : "Share your budget and destination, and I'll estimate hotel, food, and transport costs, plus budget-friendly suggestions.";
    }
    if (preg_match('/pack/', $m)) {
        return $hi
            ? "पैकिंग लिस्ट: कपड़े, टॉयलेट्रीज़, दवाइयां, दस्तावेज़ (पासपोर्ट/आधार), चार्जर और मौसम के अनुकूल सामान।"
            : "Packing checklist: clothes, toiletries, medicines, documents (passport/ID), chargers, and weather-appropriate gear.";
    }
    if (preg_match('/weather/', $m)) {
        return $hi
            ? "मौसम जानने के लिए शहर का नाम बताएं, मैं वर्तमान तापमान और पूर्वानुमान बता दूंगा।"
            : "Tell me the city and I'll share the current weather and forecast.";
    }
    if (preg_match('/currency|convert|exchange/', $m)) {
        return $hi
            ? "मुद्रा परिवर्तक: INR, USD, EUR, GBP, AED के बीच राशि बदलें। वास्तविक दरें API से ली जाती हैं।"
            : "Currency converter: convert between INR, USD, EUR, GBP, AED and more using live rates.";
    }

    return $hi
        ? "मैं आपका ट्रैवल असिस्टेंट हूँ। गंतव्य, यात्रा योजना, बजट या पैकिंग के बारे में पूछें।"
        : "I'm your TRAVELMATE AI assistant. Ask me about destinations, itineraries, budgets, packing, or any travel question.";
}