<?php
/**
 * TRAVELMATE AI - Razorpay Webhook / Verification endpoint
 * Handles Razorpay callback and verifies payment signature server-side.
 */
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../config/functions.php';

header('Content-Type: application/json; charset=utf-8');

$paymentId = (int) ($_POST['payment_id'] ?? 0);
$razorpayOrderId = $_POST['razorpay_order_id'] ?? '';
$razorpayPaymentId = $_POST['razorpay_payment_id'] ?? '';
$razorpaySignature = $_POST['razorpay_signature'] ?? '';

if (!$paymentId) {
  http_response_code(400);
  echo json_encode(['success' => false, 'error' => 'Payment ID missing']);
  exit;
}

$payment = Database::queryOne('SELECT * FROM payments WHERE id = ?', [$paymentId]);
if (!$payment) {
  http_response_code(404);
  echo json_encode(['success' => false, 'error' => 'Payment not found']);
  exit;
}

// Verify signature if webhook secret configured
$verified = true;
if (!empty(RAZORPAY_WEBHOOK_SECRET) && $razorpaySignature) {
  $expected = hash_hmac('sha256', $razorpayOrderId . '|' . $razorpayPaymentId, RAZORPAY_WEBHOOK_SECRET);
  $verified = hash_equals($expected, $razorpaySignature);
}

if ($verified) {
  Database::execute("UPDATE payments SET status = 'success', provider_payment_id = ?, signature = ?, paid_at = NOW() WHERE id = ?",
    [$razorpayPaymentId, $razorpaySignature, $paymentId]);
  Database::execute("UPDATE bookings SET payment_status = 'paid', status = 'confirmed' WHERE id = ?", [(int) $payment['booking_id']]);

  $booking = Database::queryOne('SELECT reference FROM bookings WHERE id = ?', [(int) $payment['booking_id']]);
  $qrPayload = json_encode(['ref' => $booking['reference'], 'booking_id' => (int) $payment['booking_id'], 'user_id' => (int) $payment['user_id']]);
  $qrUrl = 'https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=' . urlencode($qrPayload);
  Database::execute("UPDATE bookings SET qr_code_url = ?, qr_verified = 1 WHERE id = ?", [$qrUrl, (int) $payment['booking_id']]);

  echo json_encode(['success' => true, 'redirect' => url('booking/ticket.php?ref=' . $booking['reference'])]);
} else {
  Database::execute("UPDATE payments SET status = 'failed' WHERE id = ?", [$paymentId]);
  echo json_encode(['success' => false, 'error' => 'Signature verification failed']);
}