<?php
/**
 * TRAVELMATE AI - Stripe Webhook
 */
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../config/functions.php';

$payload = file_get_contents('php://input');
$sigHeader = $_SERVER['HTTP_STRIPE_SIGNATURE'] ?? '';

if (empty(STRIPE_WEBHOOK_SECRET)) {
  http_response_code(200);
  echo 'Webhook secret not configured';
  exit;
}

// In production, verify signature with Stripe library. Here we log the event.
$event = json_decode($payload, true);
Database::insert('INSERT INTO payment_events (provider, event_type, event_id, raw_payload, created_at) VALUES (?, ?, ?, ?, NOW())',
  ['stripe', $event['type'] ?? 'unknown', $event['id'] ?? null, $payload]);

// Handle checkout.session.completed
if (($event['type'] ?? '') === 'checkout.session.completed') {
  $session = $event['data']['object'] ?? [];
  $metadata = $session['metadata'] ?? [];
  $paymentId = (int) ($metadata['payment_id'] ?? 0);
  if ($paymentId) {
    Database::execute("UPDATE payments SET status = 'success', provider_payment_id = ?, paid_at = NOW() WHERE id = ?", [$session['payment_intent'] ?? null, $paymentId]);
    $payment = Database::queryOne('SELECT * FROM payments WHERE id = ?', [$paymentId]);
    if ($payment) {
      Database::execute("UPDATE bookings SET payment_status = 'paid', status = 'confirmed' WHERE id = ?", [(int) $payment['booking_id']]);
    }
  }
}
http_response_code(200);
echo 'ok';