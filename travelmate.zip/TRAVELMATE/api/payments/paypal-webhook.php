<?php
/**
 * TRAVELMATE AI - PayPal Webhook
 */
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../config/functions.php';

$payload = file_get_contents('php://input');
$event = json_decode($payload, true);

Database::insert('INSERT INTO payment_events (provider, event_type, event_id, raw_payload, created_at) VALUES (?, ?, ?, ?, NOW())',
  ['paypal', $event['event_type'] ?? 'unknown', $event['id'] ?? null, $payload]);

if (($event['event_type'] ?? '') === 'PAYMENT_CAPTURE_COMPLETED') {
  $resource = $event['resource'] ?? [];
  $customId = $resource['custom_id'] ?? 0;
  if ($customId) {
    Database::execute("UPDATE payments SET status = 'success', provider_payment_id = ?, paid_at = NOW() WHERE id = ?", [$resource['id'] ?? null, (int) $customId]);
    $payment = Database::queryOne('SELECT * FROM payments WHERE id = ?', [(int) $customId]);
    if ($payment) {
      Database::execute("UPDATE bookings SET payment_status = 'paid', status = 'confirmed' WHERE id = ?", [(int) $payment['booking_id']]);
    }
  }
}
http_response_code(200);
echo 'ok';