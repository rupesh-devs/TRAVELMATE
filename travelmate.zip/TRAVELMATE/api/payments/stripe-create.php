<?php
/**
 * TRAVELMATE AI - Stripe Checkout Session Creator
 */
require_once __DIR__ . '/../../config/config.php';
header('Content-Type: application/json; charset=utf-8');

$input = json_decode(file_get_contents('php://input'), true) ?: [];
$paymentId = (int) ($input['payment_id'] ?? 0);
$amount = (int) ($input['amount'] ?? 0);
$currency = $input['currency'] ?? 'usd';

if (empty(STRIPE_SECRET_KEY)) {
  echo json_encode(['error' => 'Stripe not configured']);
  http_response_code(500);
  exit;
}

$payment = Database::queryOne('SELECT * FROM payments WHERE id = ?', [$paymentId]);
if (!$payment) {
  echo json_encode(['error' => 'Payment not found']);
  http_response_code(404);
  exit;
}

try {
  $ch = curl_init('https://api.stripe.com/v1/checkout/sessions');
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
  curl_setopt($ch, CURLOPT_POST, true);
  curl_setopt($ch, CURLOPT_USERPWD, STRIPE_SECRET_KEY . ':');
  curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query([
    'mode' => 'payment',
    'line_items[0][price_data][currency]' => $currency,
    'line_items[0][price_data][unit_amount]' => $amount,
    'line_items[0][price_data][product_data][name]' => 'TRAVELMATE AI Booking #' . $payment['id'],
    'line_items[0][quantity]' => 1,
    'success_url' => url('booking/ticket.php?ref=' . (Database::queryOne('SELECT reference FROM bookings WHERE id = ?', [(int) $payment['booking_id']])['reference'] ?? '')),
    'cancel_url' => url('dashboard/bookings.php'),
    'metadata[payment_id]' => $paymentId,
  ]));
  $res = curl_exec($ch);
  $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
  curl_close($ch);

  if ($code !== 200) throw new Exception('Stripe error: ' . $res);
  $d = json_decode($res, true);
  echo json_encode(['url' => $d['url']]);
} catch (Exception $e) {
  error_log('Stripe create error: ' . $e->getMessage());
  echo json_encode(['error' => $e->getMessage()]);
  http_response_code(500);
}