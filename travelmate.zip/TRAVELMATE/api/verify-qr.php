<?php
/**
 * TRAVELMATE AI - QR Booking Reference Verification
 * Verifies a booking reference and returns booking status (JSON or HTML).
 */
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/functions.php';

$ref = $_GET['ref'] ?? ($_POST['ref'] ?? '');
$html = isset($_GET['html']);

if (!$ref) {
  if ($html) { echo '<p style="color:red;">No reference provided.</p>'; exit; }
  http_response_code(400);
  echo json_encode(['success' => false, 'error' => 'Reference required']);
  exit;
}

$booking = Database::queryOne('SELECT * FROM bookings WHERE reference = ?', [$ref]);
if (!$booking) {
  if ($html) { echo '<p style="color:red;">Booking reference not found.</p>'; exit; }
  echo json_encode(['success' => false, 'error' => 'Booking not found']);
  exit;
}

$passengerCount = Database::queryOne('SELECT COUNT(*) AS c FROM passengers WHERE booking_id = ?', [(int) $booking['id']])['c'];

echo json_encode([
  'success' => true,
  'reference' => $booking['reference'],
  'booking_type' => $booking['booking_type'],
  'source' => $booking['source'],
  'destination' => $booking['destination'],
  'journey_date' => $booking['journey_date'],
  'status' => $booking['status'],
  'payment_status' => $booking['payment_status'],
  'amount' => $booking['total_amount'],
  'currency' => $booking['currency'],
  'passengers' => (int) $passengerCount,
  'qr_verified' => (bool) $booking['qr_verified'],
]);