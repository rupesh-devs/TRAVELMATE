<?php
/**
 * TRAVELMATE AI - Currency Exchange Proxy (ExchangeRate-API)
 * Demo fallback with static rates when no API key configured.
 */
require_once __DIR__ . '/../config/config.php';
header('Content-Type: application/json; charset=utf-8');

$base = $_GET['base'] ?? 'INR';
$symbols = $_GET['symbols'] ?? 'USD,EUR,GBP,AED,AUD,CAD,SGD';

$demoRates = [
  'INR' => ['USD' => 0.0120, 'EUR' => 0.0110, 'GBP' => 0.0095, 'AED' => 0.0440, 'AUD' => 0.0180, 'CAD' => 0.0165, 'SGD' => 0.0160, 'INR' => 1],
  'USD' => ['INR' => 83.50, 'EUR' => 0.92, 'GBP' => 0.79, 'AED' => 3.67, 'AUD' => 1.50, 'CAD' => 1.37, 'SGD' => 1.35, 'USD' => 1],
];

if (empty(CURRENCY_API_KEY) || DEMO_MODE) {
  $rates = $demoRates[$base] ?? $demoRates['INR'];
  echo json_encode([
    'success' => true,
    'demo' => true,
    'base' => $base,
    'rates' => $rates,
    'updated_at' => date('Y-m-d H:i:s'),
    'note' => 'Demo rates — configure ExchangeRate-API key for live rates.',
  ]);
  exit;
}

try {
  $url = CURRENCY_API_URL . '/' . CURRENCY_API_KEY . '/latest/' . $base;
  if ($symbols) $url .= '?symbols=' . $symbols;
  $ch = curl_init($url);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
  curl_setopt($ch, CURLOPT_TIMEOUT, 15);
  $res = curl_exec($ch);
  $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
  curl_close($ch);

  if ($code !== 200) throw new Exception('Currency API error: ' . $code);
  $d = json_decode($res, true);

  echo json_encode([
    'success' => true,
    'base' => $d['base_code'] ?? $base,
    'rates' => $d['conversion_rates'] ?? [],
    'updated_at' => $d['time_last_update_utc'] ?? date('Y-m-d H:i:s'),
  ]);
} catch (Exception $e) {
  error_log('Currency error: ' . $e->getMessage());
  http_response_code(500);
  echo json_encode(['success' => false, 'error' => 'Currency unavailable']);
}