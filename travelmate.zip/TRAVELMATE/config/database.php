<?php
/**
 * TRAVELMATE AI - Database Connection (PDO)
 * Single PDO instance with prepared-statement defaults and error handling.
 */

declare(strict_types=1);

require_once __DIR__ . '/config.php';

class Database
{
    private static ?PDO $instance = null;
    private static int $queryCount = 0;
    private static array $queryLog = [];

    /**
     * Get (or create) the PDO connection.
     */
    public static function getConnection(): PDO
    {
        if (self::$instance === null) {
            $dsn = "mysql:host=" . DB_HOST . ";port=" . DB_PORT . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET;
            $options = [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,      // real prepared statements
                PDO::ATTR_STRINGIFY_FETCHES  => false,
                PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci",
            ];

            try {
                self::$instance = new PDO($dsn, DB_USER, DB_PASS, $options);
            } catch (PDOException $e) {
                if (APP_DEBUG) {
                    http_response_code(500);
                    echo "<h1>Database connection failed</h1><pre>" . htmlspecialchars($e->getMessage()) . "</pre>";
                    echo "<p>Make sure you have created the database and configured <code>.env</code> correctly.</p>";
                    exit;
                }
                error_log("Database connection failed: " . $e->getMessage());
                http_response_code(500);
                echo "<h1>Service temporarily unavailable</h1><p>Please try again later.</p>";
                exit;
            }
        }
        return self::$instance;
    }

    /**
     * Run a SELECT query and return all rows.
     */
    public static function query(string $sql, array $params = []): array
    {
        $stmt = self::getConnection()->prepare($sql);
        $stmt->execute($params);
        self::$queryCount++;
        if (APP_DEBUG) {
            self::$queryLog[] = ['sql' => $sql, 'params' => $params, 'time' => microtime(true)];
        }
        return $stmt->fetchAll();
    }

    /**
     * Run a SELECT query and return a single row (or null).
     */
    public static function queryOne(string $sql, array $params = []): ?array
    {
        $stmt = self::getConnection()->prepare($sql);
        $stmt->execute($params);
        self::$queryCount++;
        return $stmt->fetch() ?: null;
    }

    /**
     * Run an INSERT/UPDATE/DELETE and return affected row count.
     */
    public static function execute(string $sql, array $params = []): int
    {
        $stmt = self::getConnection()->prepare($sql);
        $stmt->execute($params);
        self::$queryCount++;
        return $stmt->rowCount();
    }

    /**
     * Run an INSERT and return the new auto-increment ID.
     */
    public static function insert(string $sql, array $params = []): int
    {
        $stmt = self::getConnection()->prepare($sql);
        $stmt->execute($params);
        self::$queryCount++;
        return (int) self::$instance->lastInsertId();
    }

    /**
     * Begin a database transaction.
     */
    public static function beginTransaction(): bool
    {
        return self::getConnection()->beginTransaction();
    }

    public static function commit(): bool
    {
        return self::getConnection()->commit();
    }

    public static function rollBack(): bool
    {
        return self::getConnection()->rollBack();
    }

    public static function getQueryCount(): int
    {
        return self::$queryCount;
    }

    // Prevent cloning/instantiation
    private function __construct() {}
    private function __clone() {}
}