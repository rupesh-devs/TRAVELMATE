<?php
/**
 * TRAVELMATE AI - CSRF Protection
 * Token generation, validation, and automatic form injection helpers.
 */

declare(strict_types=1);

// Regenerate CSRF token on login/logout for session fixation protection
function rotateCsrfToken(): void
{
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

function validateCsrfRequest(): bool
{
    $method = strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');
    // Only state-changing methods need CSRF
    if (in_array($method, ['POST', 'PUT', 'DELETE', 'PATCH'], true)) {
        $token = $_POST['csrf_token'] ?? $_GET['csrf_token'] ?? '';
        if (!verifyCsrf($token)) {
            http_response_code(403);
            header('Content-Type: application/json; charset=utf-8');
            echo json_encode(['success' => false, 'error' => 'Invalid or missing CSRF token.']);
            exit;
        }
    }
    return true;
}