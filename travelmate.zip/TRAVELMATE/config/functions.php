<?php
/**
 * TRAVELMATE AI - General Helper Functions
 */

declare(strict_types=1);

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/csrf.php';

// ---------------------------------------------------------------------------
// Flash messages (session-based)
// ---------------------------------------------------------------------------
function setFlash(string $key, string $message, string $type = 'info'): void
{
    $_SESSION['flash'][$key] = ['message' => $message, 'type' => $type];
}

function getFlash(string $key): ?array
{
    if (isset($_SESSION['flash'][$key])) {
        $flash = $_SESSION['flash'][$key];
        unset($_SESSION['flash'][$key]);
        return $flash;
    }
    return null;
}

// ---------------------------------------------------------------------------
// URL helpers
// ---------------------------------------------------------------------------
function url(string $path = ''): string
{
    $path = ltrim($path, '/');
    return rtrim(APP_URL, '/') . ($path ? '/' . $path : '');
}

function asset(string $path): string
{
    return rtrim(ASSETS_URL, '/') . '/' . ltrim($path, '/');
}

// ---------------------------------------------------------------------------
// Output escaping (XSS prevention)
// ---------------------------------------------------------------------------
function e(?string $value, string $flags = ENT_QUOTES | ENT_SUBSTITUTE): string
{
    return htmlspecialchars((string) $value, $flags, 'UTF-8');
}

// ---------------------------------------------------------------------------
// JSON response helper
// ---------------------------------------------------------------------------
function jsonResponse(mixed $data, int $status = 200): void
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    exit;
}

// ---------------------------------------------------------------------------
// Redirect helper
// ---------------------------------------------------------------------------
function redirect(string $path): void
{
    header('Location: ' . url($path));
    exit;
}

// ---------------------------------------------------------------------------
// CSRF token helpers
// ---------------------------------------------------------------------------
function csrfToken(): string
{
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function csrfField(): string
{
    return '<input type="hidden" name="csrf_token" value="' . e(csrfToken()) . '">';
}

function verifyCsrf(string $token): bool
{
    $expected = $_SESSION['csrf_token'] ?? '';
    if (empty($expected) || empty($token)) {
        return false;
    }
    return hash_equals($expected, $token);
}

// ---------------------------------------------------------------------------
// Rate limiting (login / sensitive actions) — in-memory per request + session
// ---------------------------------------------------------------------------
function isRateLimited(string $key, int $maxAttempts, int $windowSeconds): bool
{
    $now = time();
    $attempts = $_SESSION['rate_limit'][$key] ?? [];
    // Remove old attempts outside window
    $attempts = array_filter($attempts, fn($t) => ($now - $t) < $windowSeconds);
    $_SESSION['rate_limit'][$key] = array_values($attempts);

    if (count($attempts) >= $maxAttempts) {
        return true;
    }
    $attempts[] = $now;
    $_SESSION['rate_limit'][$key] = $attempts;
    return false;
}

function clearRateLimit(string $key): void
{
    unset($_SESSION['rate_limit'][$key]);
}

// ---------------------------------------------------------------------------
// Money formatting (INR default)
// ---------------------------------------------------------------------------
function money(float|int $amount, string $currency = 'INR'): string
{
    $symbols = ['INR' => '₹', 'USD' => '$', 'EUR' => '€', 'GBP' => '£', 'AED' => 'د.إ', 'AUD' => 'A$', 'CAD' => 'C$', 'SGD' => 'S$'];
    $symbol = $symbols[$currency] ?? $currency . ' ';
    return $symbol . number_format((float) $amount, 2);
}

// ---------------------------------------------------------------------------
// Date formatting
// ---------------------------------------------------------------------------
function travelDate(string $date, string $format = 'd M, Y'): string
{
    $dt = new DateTime($date);
    return $dt->format($format);
}

// ---------------------------------------------------------------------------
// Generate unique booking reference
// ---------------------------------------------------------------------------
function generateReference(string $prefix = 'TM'): string
{
    return $prefix . strtoupper(substr(bin2hex(random_bytes(6)), 0, 10));
}

// ---------------------------------------------------------------------------
// Send mail (wrapper — uses mail(); extend with PHPMailer/SwiftMailer in production)
// ---------------------------------------------------------------------------
function sendMail(string $to, string $subject, string $body, bool $isHtml = true): bool
{
    $headers = "MIME-Version: 1.0\r\n";
    $headers .= "Content-type: text/" . ($isHtml ? 'html' : 'plain') . "; charset=UTF-8\r\n";
    $headers .= "From: " . MAIL_FROM_NAME . " <" . MAIL_FROM . ">\r\n";
    return @mail($to, $subject, $body, $headers);
}

// ---------------------------------------------------------------------------
// Role check
// ---------------------------------------------------------------------------
function isAdmin(): bool
{
    return (isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin');
}

function isUser(): bool
{
    return (isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'user');
}

function requireAuth(): void
{
    if (!isset($_SESSION['user_id'])) {
        setFlash('auth_required', 'Please log in to continue.', 'warning');
        redirect('auth/login.php');
    }
}

function requireAdmin(): void
{
    if (!isAdmin()) {
        setFlash('access_denied', 'Admin access required.', 'error');
        redirect('index.php');
    }
}