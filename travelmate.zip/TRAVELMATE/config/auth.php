<?php
/**
 * TRAVELMATE AI - Authentication Helpers
 * Registration, login, password hashing, password-reset tokens, sessions.
 */

declare(strict_types=1);

require_once __DIR__ . '/functions.php';

// ---------------------------------------------------------------------------
// Register a new user
// ---------------------------------------------------------------------------
function registerUser(array $data): array
{
    $errors = [];

    $fullName   = trim($data['full_name'] ?? '');
    $email      = filter_var(trim($data['email'] ?? ''), FILTER_SANITIZE_EMAIL);
    $mobile     = trim($data['mobile'] ?? '');
    $country    = trim($data['country'] ?? '');
    $password   = $data['password'] ?? '';
    $confirm    = $data['confirm_password'] ?? '';
    $terms      = isset($data['terms']) ? true : false;

    if (!$fullName)      $errors[] = 'Full name is required.';
    if (!$email || !filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Valid email is required.';
    if (!$mobile)        $errors[] = 'Mobile number is required.';
    if (!$country)       $errors[] = 'Country is required.';
    if (strlen($password) < 8) $errors[] = 'Password must be at least 8 characters.';
    if ($password !== $confirm) $errors[] = 'Passwords do not match.';
    if (!$terms)         $errors[] = 'You must accept the terms and conditions.';

    if ($errors) {
        return ['success' => false, 'errors' => $errors];
    }

    // Duplicate email check
    $existing = Database::queryOne('SELECT id FROM users WHERE email = ?', [$email]);
    if ($existing) {
        return ['success' => false, 'errors' => ['This email is already registered.']];
    }

    $hash = password_hash($password, PASSWORD_DEFAULT);

    try {
        $userId = Database::insert(
            'INSERT INTO users (full_name, email, mobile, country, password, role, status, email_verified, created_at) 
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())',
            [$fullName, $email, $mobile, $country, $hash, 'user', 'active', 0]
        );

        // Default currency preference INR
        Database::insert(
            'INSERT INTO user_preferences (user_id, currency, language, theme, notifications_enabled) VALUES (?, ?, ?, ?, ?)',
            [$userId, 'INR', 'en', 'light', 1]
        );

        // Welcome reward points
        Database::insert(
            'INSERT INTO rewards (user_id, points, type, description, created_at) VALUES (?, ?, ?, ?, NOW())',
            [$userId, 100, 'signup', 'Welcome bonus for joining TRAVELMATE AI']
        );

        rotateCsrfToken();
        $_SESSION['user_id'] = (int) $userId;
        $_SESSION['user_email'] = $email;
        $_SESSION['user_name'] = $fullName;
        $_SESSION['user_role'] = 'user';
        $_SESSION['auth_time'] = time();

        setFlash('welcome', 'Welcome to TRAVELMATE AI, ' . e($fullName) . '!', 'success');
        return ['success' => true, 'user_id' => (int) $userId];
    } catch (Exception $e) {
        error_log('Registration error: ' . $e->getMessage());
        return ['success' => false, 'errors' => ['Registration failed. Please try again.']];
    }
}

// ---------------------------------------------------------------------------
// Login
// ---------------------------------------------------------------------------
function loginUser(string $email, string $password, bool $remember = false): array
{
    // Rate limiting on login
    $key = 'login_' . $email;
    if (isRateLimited($key, RATE_LIMIT_LOGIN, RATE_LIMIT_WINDOW)) {
        return ['success' => false, 'errors' => ['Too many failed attempts. Try again later.']];
    }

    $user = Database::queryOne(
        'SELECT id, full_name, email, password, role, status FROM users WHERE email = ? LIMIT 1',
        [$email]
    );

    if (!$user || !password_verify($password, $user['password'])) {
        setFlash('login_error', 'Invalid email or password.', 'error');
        return ['success' => false, 'errors' => ['Invalid email or password.']];
    }

    if ($user['status'] !== 'active') {
        return ['success' => false, 'errors' => ['Your account is not active. Contact support.']];
    }

    rotateCsrfToken();
    $_SESSION['user_id'] = (int) $user['id'];
    $_SESSION['user_email'] = $user['email'];
    $_SESSION['user_name'] = $user['full_name'];
    $_SESSION['user_role'] = $user['role'];
    $_SESSION['auth_time'] = time();

    if ($remember) {
        setcookie('tm_remember', bin2hex(random_bytes(32)), time() + SESSION_LIFETIME, '/', '', true, true);
        // In production, store this token hash in DB and validate on return
    }

    clearRateLimit($key);
    setFlash('login_success', 'Welcome back, ' . e($user['full_name']) . '!', 'success');

    return ['success' => true, 'user_id' => (int) $user['id'], 'role' => $user['role']];
}

// ---------------------------------------------------------------------------
// Logout
// ---------------------------------------------------------------------------
function logoutUser(): void
{
    setcookie('tm_remember', '', time() - 3600, '/');
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $params['path'], $params['domain'], $params['secure'], $params['httponly']);
    }
    session_destroy();
    rotateCsrfToken();
    redirect('auth/login.php');
}

// ---------------------------------------------------------------------------
// Password reset token
// ---------------------------------------------------------------------------
function createPasswordResetToken(string $email): array
{
    $user = Database::queryOne('SELECT id, email FROM users WHERE email = ? AND status = ?', [$email, 'active']);
    if (!$user) {
        // Don't reveal whether email exists
        return ['success' => true, 'message' => 'If this email exists, a reset link has been sent.'];
    }

    $token = bin2hex(random_bytes(32));
    $expires = date('Y-m-d H:i:s', time() + 3600); // 1 hour

    Database::execute(
        'INSERT INTO password_resets (email, token, expires_at, used) VALUES (?, ?, ?, 0)',
        [$email, $token, $expires]
    );

    $resetLink = url('auth/reset-password.php?token=' . $token);
    $body = "<p>Hello,</p><p>Click the link below to reset your TRAVELMATE AI password:</p>
             <p><a href=\"$resetLink\">$resetLink</a></p><p>This link expires in 1 hour.</p>";
    @sendMail($email, 'Reset your TRAVELMATE AI password', $body);

    return ['success' => true, 'message' => 'If this email exists, a reset link has been sent.'];
}

// ---------------------------------------------------------------------------
// Reset password with token
// ---------------------------------------------------------------------------
function resetPasswordWithToken(string $token, string $newPassword): array
{
    if (strlen($newPassword) < 8) {
        return ['success' => false, 'errors' => ['Password must be at least 8 characters.']];
    }

    $reset = Database::queryOne(
        'SELECT id, email, used, expires_at FROM password_resets WHERE token = ? LIMIT 1',
        [$token]
    );

    if (!$reset) {
        return ['success' => false, 'errors' => ['Invalid reset token.']];
    }
    if ($reset['used'] == '1') {
        return ['success' => false, 'errors' => ['This reset token has already been used.']];
    }
    if (new DateTime($reset['expires_at']) < new DateTime()) {
        return ['success' => false, 'errors' => ['This reset token has expired.']];
    }

    $user = Database::queryOne('SELECT id FROM users WHERE email = ?', [$reset['email']]);
    if (!$user) {
        return ['success' => false, 'errors' => ['User not found.']];
    }

    $hash = password_hash($newPassword, PASSWORD_DEFAULT);

    try {
        Database::beginTransaction();
        Database::execute('UPDATE users SET password = ? WHERE id = ?', [$hash, $user['id']]);
        Database::execute('UPDATE password_resets SET used = 1 WHERE id = ?', [$reset['id']]);
        Database::commit();
    } catch (Exception $e) {
        Database::rollBack();
        return ['success' => false, 'errors' => ['Reset failed. Please try again.']];
    }

    return ['success' => true, 'message' => 'Password reset successfully. You can now log in.'];
}