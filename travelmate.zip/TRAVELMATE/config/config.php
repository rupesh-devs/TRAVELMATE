<?php
/**
 * TRAVELMATE AI - Application Configuration
 * Loads environment variables from .env and defines app constants.
 */

declare(strict_types=1);

session_start();

// ---------------------------------------------------------------------------
// 1. Load .env file (simple parser — no external dependency)
// ---------------------------------------------------------------------------
function loadEnv(string $path): void
{
    if (!file_exists($path)) {
        return;
    }
    $lines = file($path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        $line = trim($line);
        if ($line === '' || str_starts_with($line, '#')) {
            continue;
        }
        if (str_contains($line, '=')) {
            [$key, $value] = explode('=', $line, 2);
            $key = trim($key);
            $value = trim($value);
            // Strip surrounding quotes
            if (preg_match('/^"(.*)"$/', $value, $m)) {
                $value = $m[1];
            } elseif (preg_match("/^'(.*)'$/", $value, $m)) {
                $value = $m[1];
            }
            $_ENV[$key] ??= $value;
            putenv("$key=$value");
        }
    }
}

$envPath = __DIR__ . '/../.env';
if (!file_exists($envPath) && file_exists(__DIR__ . '/../.env.example')) {
    @copy(__DIR__ . '/../.env.example', $envPath);
}
loadEnv($envPath);

// ---------------------------------------------------------------------------
// 2. Application constants
// ---------------------------------------------------------------------------
define('APP_NAME',       $_ENV['APP_NAME'] ?? 'TRAVELMATE AI');
define('APP_URL',        rtrim($_ENV['APP_URL'] ?? 'http://localhost/travelmate', '/'));
define('APP_ENV',        $_ENV['APP_ENV'] ?? 'development');
define('APP_DEBUG',      filter_var($_ENV['APP_DEBUG'] ?? true, FILTER_VALIDATE_BOOLEAN));
define('APP_TIMEZONE',   $_ENV['APP_TIMEZONE'] ?? 'Asia/Kolkata');
define('APP_LOCALE',     $_ENV['APP_LOCALE'] ?? 'en');
define('APP_KEY',        $_ENV['APP_KEY'] ?? 'default_change_me');
define('APP_SECRET',     $_ENV['CSRF_SECRET'] ?? 'default_csrf_change_me');

date_default_timezone_set(APP_TIMEZONE);

// ---------------------------------------------------------------------------
// 3. Database constants
// ---------------------------------------------------------------------------
define('DB_HOST', $_ENV['DB_HOST'] ?? 'localhost');
define('DB_PORT', $_ENV['DB_PORT'] ?? 3306);
define('DB_NAME', $_ENV['DB_NAME'] ?? 'travelmate');
define('DB_USER', $_ENV['DB_USER'] ?? 'root');
define('DB_PASS', $_ENV['DB_PASS'] ?? '');
define('DB_CHARSET', $_ENV['DB_CHARSET'] ?? 'utf8mb4');

// ---------------------------------------------------------------------------
// 4. Third-party API keys (backend only — never echo to frontend)
// ---------------------------------------------------------------------------
define('GEMINI_API_KEY',   $_ENV['GEMINI_API_KEY'] ?? '');
define('GEMINI_MODEL',     $_ENV['GEMINI_MODEL'] ?? 'gemini-1.5-flash');
define('GEMINI_API_URL',   $_ENV['GEMINI_API_URL'] ?? 'https://generativelanguage.googleapis.com/v1beta/models');

define('GOOGLE_MAPS_API_KEY',   $_ENV['GOOGLE_MAPS_API_KEY'] ?? '');
define('GOOGLE_MAPS_LIBRARIES', $_ENV['GOOGLE_MAPS_LIBRARIES'] ?? 'places,geometry');

define('WEATHER_API_KEY', $_ENV['WEATHER_API_KEY'] ?? '');
define('WEATHER_API_URL', $_ENV['WEATHER_API_URL'] ?? 'https://api.openweathermap.org/data/2.5');

define('CURRENCY_API_KEY', $_ENV['CURRENCY_API_KEY'] ?? '');
define('CURRENCY_API_URL', $_ENV['CURRENCY_API_URL'] ?? 'https://v6.exchangerate-api.com/v6');

define('RAZORPAY_KEY_ID',     $_ENV['RAZORPAY_KEY_ID'] ?? '');
define('RAZORPAY_KEY_SECRET', $_ENV['RAZORPAY_KEY_SECRET'] ?? '');
define('RAZORPAY_WEBHOOK_SECRET', $_ENV['RAZORPAY_WEBHOOK_SECRET'] ?? '');
define('RAZORPAY_MODE',       $_ENV['RAZORPAY_MODE'] ?? 'sandbox');

define('STRIPE_PUBLIC_KEY',  $_ENV['STRIPE_PUBLIC_KEY'] ?? '');
define('STRIPE_SECRET_KEY',  $_ENV['STRIPE_SECRET_KEY'] ?? '');
define('STRIPE_WEBHOOK_SECRET', $_ENV['STRIPE_WEBHOOK_SECRET'] ?? '');
define('STRIPE_MODE',        $_ENV['STRIPE_MODE'] ?? 'sandbox');

define('PAYPAL_CLIENT_ID',     $_ENV['PAYPAL_CLIENT_ID'] ?? '');
define('PAYPAL_CLIENT_SECRET', $_ENV['PAYPAL_CLIENT_SECRET'] ?? '');
define('PAYPAL_MODE',          $_ENV['PAYPAL_MODE'] ?? 'sandbox');

define('MAIL_DRIVER', $_ENV['MAIL_DRIVER'] ?? 'smtp');
define('MAIL_HOST',   $_ENV['MAIL_HOST'] ?? '');
define('MAIL_PORT',   $_ENV['MAIL_PORT'] ?? 587);
define('MAIL_USERNAME', $_ENV['MAIL_USERNAME'] ?? '');
define('MAIL_PASSWORD', $_ENV['MAIL_PASSWORD'] ?? '');
define('MAIL_FROM_NAME', $_ENV['MAIL_FROM_NAME'] ?? APP_NAME);
define('MAIL_FROM',     $_ENV['MAIL_FROM'] ?? 'no-reply@travelmate.ai');

define('DEMO_MODE', filter_var($_ENV['DEMO_MODE'] ?? 'true', FILTER_VALIDATE_BOOLEAN));

// ---------------------------------------------------------------------------
// 5. Paths
// ---------------------------------------------------------------------------
define('APP_ROOT', __DIR__ . '/..');
define('PUBLIC_URL', APP_URL);
define('ASSETS_URL', APP_URL . '/assets');

if (!defined('DS')) {
    define('DS', DIRECTORY_SEPARATOR);
}