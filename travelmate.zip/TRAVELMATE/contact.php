<?php
/**
 * TRAVELMATE AI - Contact / Support
 */
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/config/auth.php';

$message = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $name = trim($_POST['name'] ?? '');
  $email = trim($_POST['email'] ?? '');
  $msg = trim($_POST['message'] ?? '');
  if (!$name || !$email || !$msg) {
    $message = ['All fields are required.', 'error'];
  } else {
    // Store as notification-ish / simply confirm (no support tickets table to keep schema lean)
    $message = ['Thanks! Your message has been received. We will get back to you soon.', 'success'];
  }
}
?>
<div class="container" style="max-width:640px; margin: var(--space-xl) auto;">
  <div class="dashboard-header">
    <h1>Contact Us</h1>
    <p class="small">Have questions? Reach out to the TRAVELMATE AI support team.</p>
  </div>

  <?php if ($message): ?>
    <div style="background:<?= $message[1] === 'success' ? '#dcfce7' : '#fee2e2' ?>;color:<?= $message[1] === 'success' ? '#14532d' : '#991b1b' ?>;padding:var(--space-sm);border-radius:var(--radius-md);margin-bottom:var(--space-lg);font-size:var(--text-sm);"><?= e($message[0]) ?></div>
  <?php endif; ?>

  <div class="card">
    <div class="card-body">
      <form method="POST" novalidate>
        <?= csrfField() ?>
        <div class="grid grid-2">
          <div class="form-group"><label>Full name</label><input type="text" name="name" class="form-control" required></div>
          <div class="form-group"><label>Email</label><input type="email" name="email" class="form-control" required></div>
        </div>
        <div class="form-group"><label>Subject</label><input type="text" name="subject" class="form-control" placeholder="e.g. Booking issue"></div>
        <div class="form-group"><label>Message</label><textarea name="message" class="form-control" rows="5" required></textarea></div>
        <div class="form-group">
          <button type="submit" class="btn btn-primary">Send Message</button>
        </div>
      </form>
    </div>
  </div>

  <div class="grid grid-3" style="margin-top:var(--space-xl);">
    <div class="card">
      <div class="card-body">
        <h4>📧 Email</h4>
        <p class="small">support@travelmate.ai</p>
      </div>
    </div>
    <div class="card">
      <div class="card-body">
        <h4>📞 Phone</h4>
        <p class="small">+91 1800 123 4567</p>
      </div>
    </div>
    <div class="card">
      <div class="card-body">
        <h4>⏰ Hours</h4>
        <p class="small">24/7 Support</p>
      </div>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>