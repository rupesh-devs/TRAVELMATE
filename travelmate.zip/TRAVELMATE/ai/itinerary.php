<?php
/**
 * TRAVELMATE AI - Smart Trip Planner / Itinerary Generator
 */
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../config/auth.php';

$itinerary = null;
$itineraryId = (int) ($_GET['id'] ?? 0);
if ($itineraryId && isset($_SESSION['user_id'])) {
  $itinerary = Database::queryOne('SELECT * FROM itineraries WHERE id = ? AND user_id = ?', [$itineraryId, (int) $_SESSION['user_id']]);
}
?>
<div class="container">
  <div class="dashboard-header">
    <h1>🗺️ Smart Trip Planner</h1>
    <a href="<?= url('dashboard/index.php') ?>" class="btn btn-outline">← Back</a>
  </div>

  <?php if (!$itinerary): ?>
    <div class="itinerary-form">
      <h2>Create a New Itinerary</h2>
      <p class="small">Get a day-wise plan with attractions, transport, food and hotel estimates.</p>
      <form id="itineraryForm" novalidate>
        <?= csrfField() ?>
        <div class="grid grid-2">
          <div class="form-group">
            <label>Starting city</label>
            <input type="text" name="start_city" class="form-control" placeholder="e.g. Lucknow" required>
          </div>
          <div class="form-group">
            <label>Destination</label>
            <input type="text" name="destination" class="form-control" placeholder="e.g. Manali" required>
          </div>
          <div class="form-group">
            <label>Start date</label>
            <input type="date" name="start_date" class="form-control" required>
          </div>
          <div class="form-group">
            <label>End date</label>
            <input type="date" name="end_date" class="form-control" required>
          </div>
          <div class="form-group">
            <label>Budget (₹)</label>
            <input type="number" name="budget" class="form-control" placeholder="15000" required>
          </div>
          <div class="form-group">
            <label>Currency</label>
            <select name="currency" class="form-select">
              <option value="INR">INR</option><option value="USD">USD</option><option value="EUR">EUR</option>
            </select>
          </div>
          <div class="form-group">
            <label>Number of travellers</label>
            <input type="number" name="travellers" class="form-control" value="1" min="1" required>
          </div>
          <div class="form-group">
            <label>Interests</label>
            <input type="text" name="interests" class="form-control" placeholder="e.g. adventure, food, culture">
          </div>
        </div>
        <div class="form-group mt-4">
          <button type="button" class="btn btn-primary btn-lg btn-full" onclick="generateItinerary()">Generate Itinerary</button>
        </div>
      </form>
      <div id="itineraryResult"></div>
    </div>
  <?php else: ?>
    <div class="itinerary-output">
      <h2><?= e($itinerary['title']) ?></h2>
      <div class="trip-card-meta" style="margin-bottom:var(--space-lg);">
        <span><?= e($itinerary['start_city']) ?> → <?= e($itinerary['destination']) ?></span>
        <span><?= travelDate($itinerary['start_date']) ?> to <?= travelDate($itinerary['end_date']) ?></span>
        <span>Budget: <?= money($itinerary['budget'] ?? 0, $itinerary['currency']) ?></span>
      </div>
      <div id="itineraryResult"><?= nl2br(e($itinerary['plan_data'] ?? '')) ?></div>
    </div>
  <?php endif; ?>
</div>

<script>
async function generateItinerary() {
  const form = document.getElementById('itineraryForm');
  const fd = new FormData(form);
  const data = Object.fromEntries(fd);
  const result = document.getElementById('itineraryResult');
  result.innerHTML = '<div class="loader"></div><p style="text-align:center;color:var(--color-muted);">Generating your itinerary...</p>';

  try {
    const res = await fetch('<?= url('api/gemini.php') ?>', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({
        message: 'Plan a ' + (new Date(data.end_date) - new Date(data.start_date)) / (1000*60*60*24) + ' day trip from ' + data.start_city + ' to ' + data.destination + ' under ' + data.budget + ' ' + data.currency + '. Travellers: ' + data.travellers + '. Interests: ' + data.interests + '. Provide day-wise schedule with attractions, transport costs, food & hotel estimates, and total budget.',
        history: [],
        language: 'en'
      })
    });
    const json = await res.json();
    if (json.success) {
      result.innerHTML = '<div class="day-card"><div class="day-body"><h4>Your AI-Generated Itinerary</h4><div style="white-space:pre-wrap;line-height:1.6;">' + escapeHtml(json.reply) + '</div></div></div>';
    } else {
      result.innerHTML = '<div class="empty-state"><div class="icon">⚠️</div><p>Could not generate itinerary. Please try again.</p></div>';
    }
  } catch (e) {
    result.innerHTML = '<div class="empty-state"><div class="icon">⚠️</div><p>Error generating itinerary.</p></div>';
  }
}

function escapeHtml(t) {
  const d = document.createElement('div'); d.textContent = t; return d.innerHTML;
}
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>