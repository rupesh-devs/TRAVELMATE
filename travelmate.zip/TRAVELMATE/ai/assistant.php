<?php
/**
 * TRAVELMATE AI - AI Travel Assistant
 */
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../config/auth.php';

$history = [];
if (isset($_SESSION['user_id'])) {
  $history = Database::query(
    'SELECT * FROM (SELECT * FROM (SELECT 1 as dummy) t) d LIMIT 0'
  );
}
// We'll store chat history in session for simplicity
if (!isset($_SESSION['ai_history'])) {
  $_SESSION['ai_history'] = [
    ['role' => 'model', 'text' => 'Namaste! 👋 I am your TRAVELMATE AI assistant. Ask me to plan trips, suggest destinations, estimate budgets, or make packing checklists. How can I help you today?']
  ];
}
$history = $_SESSION['ai_history'];
?>
<div class="container">
  <div class="dashboard-header" style="margin-bottom:var(--space-lg);">
    <h1>🤖 AI Travel Assistant</h1>
    <a href="<?= url('dashboard/index.php') ?>" class="btn btn-outline">← Back to dashboard</a>
  </div>

  <div class="ai-layout">
    <div class="ai-sidebar">
      <div class="ai-sidebar-header">
        <h3>Conversations</h3>
      </div>
      <div class="ai-conversations">
        <div class="conv-item active" onclick="loadConversation(0)">
          <div class="title">Travel Chat</div>
          <div class="small">Your assistant conversation</div>
        </div>
      </div>
    </div>

    <div class="ai-main">
      <div class="ai-chat" id="aiChat">
        <?php foreach ($history as $msg): ?>
          <div class="ai-message <?= $msg['role'] === 'user' ? 'user' : 'bot' ?>">
            <div class="avatar"><?= $msg['role'] === 'user' ? 'U' : 'A' ?></div>
            <div class="ai-message-content"><?= nl2br(e($msg['text'])) ?></div>
            <div class="ai-message-time"><?= date('h:i A') ?></div>
          </div>
        <?php endforeach; ?>
      </div>

      <div class="ai-quick-actions">
        <button class="ai-quick-btn" onclick="sendQuick('Plan a 5-day trip from Lucknow to Manali under ₹15,000')">₹15k Manali trip</button>
        <button class="ai-quick-btn" onclick="sendQuick('Best time to visit Goa')">Best time to visit Goa</button>
        <button class="ai-quick-btn" onclick="sendQuick('Packing list for a winter trip to Manali')">Winter packing list</button>
        <button class="ai-quick-btn" onclick="sendQuick('Budget hotels in Paris under €100')">Budget hotels Paris</button>
        <button class="ai-quick-btn" onclick="sendQuick('Convert ₹50000 to USD')">Currency conversion</button>
      </div>

      <div class="ai-input-area">
        <div class="ai-input-wrapper">
          <input type="text" id="aiInput" placeholder="Ask me anything about travel..." autocomplete="off">
          <button class="ai-btn-voice" id="voiceBtn" title="Voice input">🎤</button>
          <button class="ai-btn-send" id="sendBtn" onclick="sendMessage()">➤</button>
        </div>
        <p class="small" style="text-align:center;color:var(--color-muted);margin-top:var(--space-xs);">Hindi &amp; English supported • Voice input available</p>
      </div>
    </div>
  </div>
</div>

<script>
const aiInput = document.getElementById('aiInput');
const aiChat = document.getElementById('aiChat');
const sendBtn = document.getElementById('sendBtn');
const voiceBtn = document.getElementById('voiceBtn');

let history = <?= json_encode($history) ?>;

function appendMessage(text, role) {
  const div = document.createElement('div');
  div.className = 'ai-message ' + (role === 'user' ? 'user' : 'bot');
  const avatar = role === 'user' ? 'U' : 'A';
  div.innerHTML = '<div class="avatar">' + avatar + '</div>' +
    '<div class="ai-message-content">' + escapeHtml(text) + '</div>' +
    '<div class="ai-message-time">' + new Date().toLocaleTimeString([], {hour:'2-digit', minute:'2-digit'}) + '</div>';
  aiChat.appendChild(div);
  aiChat.scrollTop = aiChat.scrollHeight;
  history.push({role: role, text: text});
}

function escapeHtml(t) {
  const d = document.createElement('div');
  d.textContent = t;
  return d.innerHTML;
}

function setSending(yes) {
  sendBtn.disabled = yes;
  aiInput.disabled = yes;
  if (yes) {
    const d = document.createElement('div');
    d.className = 'ai-message bot';
    d.id = 'typingMsg';
    d.innerHTML = '<div class="avatar">A</div><div class="ai-message-content ai-typing">Assistant is typing...</div>';
    aiChat.appendChild(d);
    aiChat.scrollTop = aiChat.scrollHeight;
  } else {
    const t = document.getElementById('typingMsg');
    if (t) t.remove();
  }
}

async function sendMessage() {
  const text = aiInput.value.trim();
  if (!text) return;
  aiInput.value = '';
  appendMessage(text, 'user');
  setSending(true);

  try {
    const res = await fetch('<?= url('api/gemini.php') ?>', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({message: text, history: history, language: 'en'})
    });
    const data = await res.json();
    setSending(false);
    if (data.success) {
      appendMessage(data.reply, 'model');
      // Speak the response
      speak(data.reply);
    } else {
      appendMessage('Sorry, something went wrong. Please try again.', 'model');
    }
  } catch (e) {
    setSending(false);
    appendMessage('Unable to connect to the assistant. Please try again later.', 'model');
  }
}

function sendQuick(text) {
  aiInput.value = text;
  sendMessage();
}

// Voice input (Web Speech API)
function startVoice() {
  if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
    alert('Voice input not supported in this browser.');
    return;
  }
  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  const rec = new SpeechRecognition();
  rec.lang = 'en-IN';
  rec.interimResults = false;
  rec.maxAlternatives = 1;
  rec.start();
  voiceBtn.textContent = '🔊';
  voiceBtn.style.opacity = '0.6';

  rec.onresult = (e) => {
    aiInput.value = e.results[0][0].transcript;
    sendMessage();
  };
  rec.onend = () => {
    voiceBtn.textContent = '🎤';
    voiceBtn.style.opacity = '1';
  };
  rec.onerror = () => {
    voiceBtn.textContent = '🎤';
    voiceBtn.style.opacity = '1';
  };
}
voiceBtn?.addEventListener('click', startVoice);
aiInput?.addEventListener('keypress', (e) => { if (e.key === 'Enter') sendMessage(); });

// Text-to-speech for assistant responses
function speak(text) {
  if (!('speechSynthesis' in window)) return;
  window.speechSynthesis.cancel();
  const u = new SpeechSynthesisUtterance(text);
  u.lang = 'en-IN';
  u.rate = 1.0;
  window.speechSynthesis.speak(u);
}
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>