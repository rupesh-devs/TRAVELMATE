<?php
/**
 * TRAVELMATE AI - Password Reset (token-based)
 */
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../config/auth.php';

$token = $_GET['token'] ?? '';
$message = null;
$messageType = 'info';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $password = $_POST['password'] ?? '';
  $confirm  = $_POST['confirm_password'] ?? '';
  $token    = $_POST['token'] ?? $token;

  if ($password !== $confirm) {
    $message = 'Passwords do not match.';
    $messageType = 'error';
  } elseif (strlen($password) < 8) {
    $message = 'Password must be at least 8 characters.';
    $messageType = 'error';
  } else {
    $result = resetPasswordWithToken($token, $password);
    $message = $result['message'];
    $messageType = $result['success'] ? 'success' : 'error';
    if ($result['success']) {
      echo "<script>setTimeout(()=>location.href='".url('auth/login.php')."', 1500)</script>";
    }
  }
}
?>
<div class="container" style="max-width:460px; margin: var(--space-xl) auto;">
  <div class="card">
    <div class="card-body">
      <div class="text-center mb-4">
        <div class="brand-mark" style="margin:0 auto var(--space-md);">T</div>
        <h2>Reset password</h2>
        <p class="small">Choose a new password for your account.</p>
      </div>

      <?php if ($message): ?>
        <div style="background:<?= $messageType === 'success' ? '#dcfce7' : '#fee2e2' ?>;color:<?= $messageType === 'success' ? '#14532d' : '#991b1b' ?>;padding:var(--space-sm);border-radius:var(--radius-md);margin-bottom:var(--space-md);font-size:var(--text-sm);"><?= e($message) ?></div>
      <?php endif; ?>

      <?php if (!$message || $messageType !== 'success'): ?>
      <form method="POST" action="" novalidate>
        <?= csrfField() ?>
        <input type="hidden" name="token" value="<?= e($token) ?>">
        <div class="form-group">
          <label for="password">New password</label>
          <input type="password" id="password" name="password" class="form-control" placeholder="••••••••" required minlength="8">
        </div>
        <div class="form-group">
          <label for="confirm_password">Confirm password</label>
          <input type="password" id="confirm_password" name="confirm_password" class="form-control" placeholder="••••••••" required minlength="8">
        </div>
        <div class="form-group">
          <button type="submit" class="btn btn-primary btn-full">Update password</button>
        </div>
      </form>
      <?php endif; ?>

      <div class="form-group text-center mt-3">
        <p class="small"><a href="<?= url('auth/login.php') ?>">Back to sign in</a></p>
      </div>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>