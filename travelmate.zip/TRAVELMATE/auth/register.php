<?php
/**
 * TRAVELMATE AI - Registration
 */
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../config/auth.php';

$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $result = registerUser($_POST);
  if ($result['success']) {
    redirect('dashboard/index.php');
  } else {
    $errors = $result['errors'];
  }
}

if (isset($_SESSION['user_id'])) redirect('dashboard/index.php');
?>
<div class="container" style="max-width:460px; margin: var(--space-xl) auto;">
  <div class="card">
    <div class="card-body">
      <div class="text-center mb-4">
        <div class="brand-mark" style="margin:0 auto var(--space-md);">T</div>
        <h2>Create account</h2>
        <p class="small">Join TRAVELMATE AI and start traveling smarter.</p>
      </div>

      <?php foreach ($errors as $err): ?>
        <div class="alert alert-error" style="background:#fee2e2;color:#991b1b;padding:var(--space-sm);border-radius:var(--radius-md);margin-bottom:var(--space-md);font-size:var(--text-sm);"><?= e($err) ?></div>
      <?php endforeach; ?>

      <form method="POST" action="" novalidate>
        <?= csrfField() ?>

        <div class="form-group">
          <label>Full name</label>
          <input type="text" name="full_name" class="form-control" placeholder="Rahul Sharma" required value="<?= e($_POST['full_name'] ?? '') ?>">
        </div>

        <div class="form-group">
          <label>Email address</label>
          <input type="email" name="email" class="form-control" placeholder="you@example.com" required value="<?= e($_POST['email'] ?? '') ?>">
        </div>

        <div class="form-group">
          <label>Mobile number</label>
          <input type="tel" name="mobile" class="form-control" placeholder="+91 98765 43210" required value="<?= e($_POST['mobile'] ?? '') ?>">
        </div>

        <div class="form-group">
          <label>Country</label>
          <select name="country" class="form-select" required>
            <option value="India" <?= ($_POST['country'] ?? '') === 'India' ? 'selected' : '' ?>>India</option>
            <option value="United States" <?= ($_POST['country'] ?? '') === 'United States' ? 'selected' : '' ?>>United States</option>
            <option value="United Kingdom" <?= ($_POST['country'] ?? '') === 'United Kingdom' ? 'selected' : '' ?>>United Kingdom</option>
            <option value="UAE" <?= ($_POST['country'] ?? '') === 'UAE' ? 'selected' : '' ?>>UAE</option>
            <option value="France" <?= ($_POST['country'] ?? '') === 'France' ? 'selected' : '' ?>>France</option>
            <option value="Indonesia" <?= ($_POST['country'] ?? '') === 'Indonesia' ? 'selected' : '' ?>>Indonesia</option>
            <option value="Maldives" <?= ($_POST['country'] ?? '') === 'Maldives' ? 'selected' : '' ?>>Maldives</option>
            <option value="Japan" <?= ($_POST['country'] ?? '') === 'Japan' ? 'selected' : '' ?>>Japan</option>
            <option value="">Other</option>
          </select>
        </div>

        <div class="form-group">
          <label>Password</label>
          <input type="password" name="password" class="form-control" placeholder="••••••••" required minlength="8">
        </div>

        <div class="form-group">
          <label>Confirm password</label>
          <input type="password" name="confirm_password" class="form-control" placeholder="••••••••" required minlength="8">
        </div>

        <div class="form-group form-check">
          <input type="checkbox" id="terms" name="terms" value="1" required>
          <label for="terms">I accept the <a href="#">Terms of Service</a> and <a href="#">Privacy Policy</a></label>
        </div>

        <div class="form-group">
          <button type="submit" class="btn btn-primary btn-full btn-lg">Create account</button>
        </div>
      </form>

      <div class="form-group text-center">
        <p class="small">Already have an account? <a href="<?= url('auth/login.php') ?>">Sign in</a></p>
      </div>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>