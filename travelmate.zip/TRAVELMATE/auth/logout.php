<?php
/**
 * TRAVELMATE AI - Logout
 */
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/auth.php';
logoutUser();