<?php
/**
 * TRAVELMATE AI - Forgot Password
 */
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../config/auth.php';

$message = null;
$messageType = 'info';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $email = trim($_POST['email'] ?? '');
  if (!$email) {
    $message = 'Please enter your email address.';
    $messageType = 'error';
  } else {
    $result = createPasswordResetToken($email);
    $message = $result['message'];
    $messageType = $result['success'] ? 'success' : 'error';
  }
}
?>
<div class="container" style="max-width:460px; margin: var(--space-xl) auto;">
  <div class="card">
    <div class="card-body">
      <div class="text-center mb-4">
        <div class="brand-mark" style="margin:0 auto var(--space-md);">T</div>
        <h2>Forgot password?</h2>
        <p class="small">Enter your email and we'll send a reset link.</p>
      </div>

      <?php if ($message): ?>
        <div style="background:<?= $messageType === 'success' ? '#dcfce7' : '#fee2e2' ?>;color:<?= $messageType === 'success' ? '#14532d' : '#991b1b' ?>;padding:var(--space-sm);border-radius:var(--radius-md);margin-bottom:var(--space-md);font-size:var(--text-sm);"><?= e($message) ?></div>
      <?php endif; ?>

      <form method="POST" action="" novalidate>
        <?= csrfField() ?>
        <div class="form-group">
          <label for="email">Email address</label>
          <input type="email" id="email" name="email" class="form-control" placeholder="you@example.com" required>
        </div>
        <div class="form-group">
          <button type="submit" class="btn btn-primary btn-full">Send reset link</button>
        </div>
      </form>

      <div class="form-group text-center mt-3">
        <p class="small">Remember your password? <a href="<?= url('auth/login.php') ?>">Sign in</a></p>
      </div>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>