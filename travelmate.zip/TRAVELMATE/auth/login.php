<?php
/**
 * TRAVELMATE AI - Login
 */
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../config/auth.php';

$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $email    = trim($_POST['email'] ?? '');
  $password = $_POST['password'] ?? '';
  $remember = !empty($_POST['remember']);

  if (!$email || !$password) {
    $errors[] = 'Please enter email and password.';
  } else {
    $result = loginUser($email, $password, $remember);
    if ($result['success']) {
      $next = $_SESSION['redirect_after_login'] ?? 'dashboard/index.php';
      unset($_SESSION['redirect_after_login']);
      redirect($next);
    } else {
      $errors = $result['errors'];
    }
  }
}

// If already logged in, go to dashboard
if (isset($_SESSION['user_id'])) redirect('dashboard/index.php');
if (isset($_SESSION['admin_id'])) redirect('admin/index.php');
?>
<div class="container" style="max-width:460px; margin: var(--space-xl) auto;">
  <div class="card">
    <div class="card-body">
      <div class="text-center mb-4">
        <div class="brand-mark" style="margin:0 auto var(--space-md);">T</div>
        <h2>Welcome back</h2>
        <p class="small">Sign in to your TRAVELMATE AI account</p>
      </div>

      <?php foreach ($errors as $err): ?>
        <div class="alert alert-error" style="background:#fee2e2;color:#991b1b;padding:var(--space-sm);border-radius:var(--radius-md);margin-bottom:var(--space-md);font-size:var(--text-sm);"><?= e($err) ?></div>
      <?php endforeach; ?>

      <form method="POST" action="" novalidate>
        <?= csrfField() ?>
        <div class="form-group">
          <label for="email">Email address</label>
          <input type="email" id="email" name="email" class="form-control" placeholder="you@example.com" required value="<?= e($_POST['email'] ?? '') ?>">
        </div>
        <div class="form-group">
          <div class="flex justify-between">
            <label for="password">Password</label>
            <a href="<?= url('auth/forgot-password.php') ?>" class="small">Forgot password?</a>
          </div>
          <div class="input-with-icon" style="position:relative;">
            <input type="password" id="password" name="password" class="form-control" placeholder="••••••••" required>
            <button type="button" class="btn btn-ghost btn-sm" style="position:absolute;right:var(--space-md);top:50%;transform:translateY(-50%);" id="togglePwd" aria-label="Show/hide password">👁️</button>
          </div>
        </div>
        <div class="form-group form-check">
          <input type="checkbox" id="remember" name="remember" value="1">
          <label for="remember">Remember me</label>
        </div>
        <div class="form-group">
          <button type="submit" class="btn btn-primary btn-full btn-lg">Sign in</button>
        </div>
      </form>

      <div class="form-group text-center">
        <p class="small">Don't have an account? <a href="<?= url('auth/register.php') ?>">Create account</a></p>
      </div>
    </div>
  </div>
</div>

<script>
document.getElementById('togglePwd')?.addEventListener('click', function(){
  const p = document.getElementById('password');
  if (p.type === 'password') { p.type = 'text'; this.textContent = '🙈'; }
  else { p.type = 'password'; this.textContent = '👁️'; }
});
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>