<?php
/**
 * TRAVELMATE AI - Database Installer
 * Creates the database and imports schema. Run via browser once.
 */
require_once __DIR__ . '/config/config.php';

$message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $host = $_POST['db_host'] ?? 'localhost';
  $user = $_POST['db_user'] ?? 'root';
  $pass = $_POST['db_pass'] ?? '';
  $name = $_POST['db_name'] ?? 'travelmate';

  try {
    $pdo = new PDO("mysql:host=$host;charset=utf8mb4", $user, $pass, [
      PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    ]);
    $pdo->exec("CREATE DATABASE IF NOT EXISTS `$name` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
    $pdo->exec("USE `$name`");

    $sql = file_get_contents(__DIR__ . '/database.sql');
    // Split on semicolons and execute each statement (naive but works for this schema)
    $statements = array_filter(array_map('trim', explode(';', $sql)));
    foreach ($statements as $stmt) {
      if (trim($stmt) && !str_starts_with(trim($stmt), '--')) {
        $pdo->exec($stmt);
      }
    }
    $message = ['Database installed successfully! You can now log in. Demo user: rahul@example.com / Travel@123 | Admin: admin@travelmate.ai / Admin@123', 'success'];
  } catch (Exception $e) {
    $message = ['Installation failed: ' . $e->getMessage(), 'error'];
  }
}
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>TRAVELMATE AI - Installer</title>
<link rel="stylesheet" href="<?= asset('css/variables.css') ?>">
<link rel="stylesheet" href="<?= asset('css/layout.css') ?>">
<link rel="stylesheet" href="<?= asset('css/components.css') ?>">
<style>body{font-family:var(--font-sans);background:var(--color-offwhite);color:var(--color-navy);} .install{max-width:520px;margin:60px auto;padding:var(--space-xl);}</style>
</head>
<body>
<div class="install card" style="margin:var(--space-xl) auto;">
  <div class="card-body">
    <h1>🚀 TRAVELMATE AI Installer</h1>
    <?php if ($message): ?>
      <div style="background:<?= $message[1]==='success'?'#dcfce7':'#fee2e2' ?>;color:<?= $message[1]==='success'?'#14532d':'#991b1b' ?>;padding:var(--space-sm);border-radius:var(--radius-md);margin-bottom:var(--space-lg);"><?= e($message[0]) ?></div>
    <?php endif; ?>
    <form method="POST">
      <div class="form-group"><label>Database host</label><input type="text" name="db_host" class="form-control" value="localhost" required></div>
      <div class="form-group"><label>Database user</label><input type="text" name="db_user" class="form-control" value="root" required></div>
      <div class="form-group"><label>Database password</label><input type="password" name="db_pass" class="form-control"></div>
      <div class="form-group"><label>Database name</label><input type="text" name="db_name" class="form-control" value="travelmate" required></div>
      <div class="form-group"><button type="submit" class="btn btn-primary btn-full">Install Database</button></div>
    </form>
    <p class="small mt-3">Then copy <code>.env.example</code> to <code>.env</code> and configure your API keys.</p>
  </div>
</div>
</body>
</html>