<?php
/**
 * TRAVELMATE AI - Saved Itineraries
 */
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../config/auth.php';
requireAuth();

$userId = (int) $_SESSION['user_id'];
$itineraries = Database::query(
  'SELECT * FROM itineraries WHERE user_id = ? ORDER BY updated_at DESC',
  [$userId]
);
?>
<div class="container">
  <div class="dashboard-header">
    <h1>My Itineraries</h1>
    <a href="<?= url('ai/itinerary.php') ?>" class="btn btn-primary">Create New</a>
    <a href="<?= url('dashboard/index.php') ?>" class="btn btn-outline">← Back</a>
  </div>

  <div class="grid grid-3">
    <?php if ($itineraries): foreach ($itineraries as $it): ?>
      <div class="card">
        <div class="card-body">
          <h3><?= e($it['title']) ?></h3>
          <p class="small"><?= e($it['start_city']) ?> → <?= e($it['destination']) ?></p>
          <p class="small"><?= travelDate($it['start_date']) ?> to <?= travelDate($it['end_date']) ?></p>
          <p class="small">Budget: <?= money($it['budget'] ?? 0, $it['currency']) ?></p>
          <div class="btn-group mt-3">
            <a href="<?= url('ai/itinerary.php?id=' . $it['id']) ?>" class="btn btn-sm btn-outline">View</a>
            <a href="<?= url('dashboard/index.php') ?>" class="btn btn-sm btn-outline">Edit</a>
          </div>
        </div>
      </div>
    <?php endforeach; else: ?>
      <div class="empty-state" style="grid-column:1/-1;padding:var(--space-3xl);">
        <div class="icon">🗺️</div>
        <h3 style="font-size:var(--text-lg);">No itineraries yet</h3>
        <p class="small">Create a day-wise trip plan with the AI assistant.</p>
      </div>
    <?php endforeach; ?>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>