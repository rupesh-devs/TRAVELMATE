<?php
/**
 * TRAVELMATE AI - Change Password handler
 */
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/auth.php';
requireAuth();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
  redirect('dashboard/settings.php');
}

$userId = (int) $_SESSION['user_id'];
$current = $_POST['current_password'] ?? '';
$newPassword = $_POST['new_password'] ?? '';
$confirm = $_POST['confirm_password'] ?? '';

$user = Database::queryOne('SELECT password FROM users WHERE id = ?', [$userId]);
$errors = [];

if (!$user || !password_verify($current, $user['password'])) {
  $errors[] = 'Current password is incorrect.';
}
if ($newPassword !== $confirm) {
  $errors[] = 'New passwords do not match.';
}
if (strlen($newPassword) < 8) {
  $errors[] = 'New password must be at least 8 characters.';
}

if ($errors) {
  $_SESSION['change_password_errors'] = $errors;
} else {
  Database::execute('UPDATE users SET password = ? WHERE id = ?', [password_hash($newPassword, PASSWORD_DEFAULT), $userId]);
  $_SESSION['change_password_success'] = 'Password updated successfully.';
}
redirect('dashboard/settings.php');