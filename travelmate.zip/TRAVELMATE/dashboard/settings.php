<?php
/**
 * TRAVELMATE AI - Account Settings
 */
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../config/auth.php';
requireAuth();
?>
<div class="container" style="max-width:640px; margin: var(--space-xl) auto;">
  <div class="dashboard-header">
    <h1>Account Settings</h1>
    <a href="<?= url('dashboard/index.php') ?>" class="btn btn-outline">← Back</a>
  </div>

  <div class="card">
    <div class="card-body">
      <h3 style="margin-bottom:var(--space-lg);">Change Password</h3>
      <form method="POST" action="<?= url('dashboard/change-password.php') ?>" novalidate>
        <?= csrfField() ?>
        <div class="form-group">
          <label>Current password</label>
          <input type="password" name="current_password" class="form-control" required>
        </div>
        <div class="form-group">
          <label>New password</label>
          <input type="password" name="new_password" class="form-control" required minlength="8">
        </div>
        <div class="form-group">
          <label>Confirm new password</label>
          <input type="password" name="confirm_password" class="form-control" required minlength="8">
        </div>
        <div class="form-group">
          <button type="submit" class="btn btn-primary">Update password</button>
        </div>
      </form>

      <h3 style="margin:var(--space-xl) 0 var(--space-lg);">Danger Zone</h3>
      <div class="form-group">
        <button type="button" class="btn btn-danger" onclick="if(confirm('This will deactivate your account. Continue?'))location.href='<?= url('dashboard/deactivate.php') ?>'">Deactivate Account</button>
        <p class="form-text">Deactivating will prevent login but keeps your booking records.</p>
      </div>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>