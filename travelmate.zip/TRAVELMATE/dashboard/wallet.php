<?php
/**
 * TRAVELMATE AI - Digital Travel Wallet
 */
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../config/auth.php';
requireAuth();

$userId = (int) $_SESSION['user_id'];
$balance = (float) (Database::queryOne("SELECT COALESCE(SUM(amount),0) AS c FROM payments WHERE user_id = ? AND status = 'success'", [$userId])['c'] ?? 0);
$transactions = Database::query(
  'SELECT p.*, b.reference, b.booking_type FROM payments p LEFT JOIN bookings b ON p.booking_id = b.id WHERE p.user_id = ? ORDER BY p.created_at DESC LIMIT 20',
  [$userId]
);
?>
<div class="container">
  <div class="dashboard-header">
    <h1>Travel Wallet</h1>
    <a href="<?= url('dashboard/index.php') ?>" class="btn btn-outline">← Back</a>
  </div>

  <div class="dashboard-card wallet-card">
    <h3>Available Balance</h3>
    <div class="wallet-balance"><?= money($balance) ?></div>
    <p class="small">Use your wallet for future bookings and refunds.</p>
    <div class="reward-points">
      <span>🎁</span>
      <span class="points"><?= (int)(Database::queryOne('SELECT COALESCE(SUM(points),0) AS p FROM rewards WHERE user_id = ?', [$userId])['p'] ?? 0) ?></span>
      <span>reward points</span>
    </div>
  </div>

  <div class="dashboard-card" style="margin-top:var(--space-lg);">
    <div class="dashboard-card-header"><h3>Recent Transactions</h3></div>
    <div class="dashboard-card-body">
      <?php if ($transactions): ?>
        <div class="table-wrap" style="border:none;">
          <table>
            <thead>
              <tr><th>Date</th><th>Booking</th><th>Type</th><th>Amount</th><th>Status</th></tr>
            </thead>
            <tbody>
              <?php foreach ($transactions as $t): ?>
                <tr>
                  <td><?= date('d M Y', strtotime($t['created_at'])) ?></td>
                  <td><?= e($t['reference'] ?? 'Wallet top-up') ?></td>
                  <td><?= ucfirst(e($t['booking_type'] ?? 'wallet')) ?></td>
                  <td><?= money($t['amount'], $t['currency']) ?></td>
                  <td><span class="badge badge-<?= $t['status'] === 'success' ? 'success' : 'error' ?>"><?= ucfirst(e($t['status'])) ?></span></td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      <?php else: ?>
        <div class="empty-state" style="padding:var(--space-md);">
          <div class="icon">💳</div>
          <h3 style="font-size:var(--text-lg);">No transactions yet</h3>
          <p class="small">Your wallet transactions will appear here.</p>
        </div>
      <?php endif; ?>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>