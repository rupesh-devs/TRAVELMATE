<?php
/**
 * TRAVELMATE AI - User Dashboard
 */
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../config/auth.php';
requireAuth();

$userId = (int) $_SESSION['user_id'];

// Stats
$totalBookings = (int) Database::queryOne('SELECT COUNT(*) AS c FROM bookings WHERE user_id = ?', [$userId])['c'];
$upcoming = (int) Database::queryOne("SELECT COUNT(*) AS c FROM bookings WHERE user_id = ? AND status = 'confirmed' AND journey_date >= CURDATE()", [$userId])['c'];
$totalSpent = (float) (Database::queryOne("SELECT COALESCE(SUM(total_amount),0) AS c FROM bookings WHERE user_id = ? AND payment_status = 'paid'", [$userId])['c'] ?? 0);
$rewardsRow = Database::queryOne('SELECT COALESCE(SUM(points),0) AS p FROM rewards WHERE user_id = ?', [$userId]);
$rewardPoints = (int) ($rewardsRow['p'] ?? 0);

// Upcoming trips
$upcomingTrips = Database::query(
  'SELECT * FROM bookings WHERE user_id = ? AND status = ? AND journey_date >= CURDATE() ORDER BY journey_date ASC LIMIT 4',
  [$userId, 'confirmed']
);

// Recent bookings
$recentBookings = Database::query(
  'SELECT * FROM bookings WHERE user_id = ? ORDER BY created_at DESC LIMIT 5',
  [$userId]
);

// Notifications (unread first)
$notifications = Database::query(
  'SELECT * FROM notifications WHERE user_id = ? ORDER BY is_read ASC, created_at DESC LIMIT 6',
  [$userId]
);

// Wallet balance placeholder (from payments)
$walletBalance = (float) (Database::queryOne("SELECT COALESCE(SUM(amount),0) AS c FROM payments WHERE user_id = ? AND status = 'success'", [$userId])['c'] ?? 0);
?>
<div class="container">
  <div class="dashboard-header">
    <div>
      <h1>Hi, <?= e($_SESSION['user_name']) ?> 👋</h1>
      <p class="subtitle">Here's what's happening with your travel plans.</p>
    </div>
    <div class="btn-group">
      <a href="<?= url('booking/flights.php') ?>" class="btn btn-primary">Book Flight</a>
      <a href="<?= url('ai/assistant.php') ?>" class="btn btn-outline">Ask AI</a>
    </div>
  </div>

  <!-- Stats -->
  <div class="dashboard-stats">
    <div class="stat-card">
      <div class="label">Total Bookings</div>
      <div class="value"><?= $totalBookings ?></div>
      <div class="change change-up">▲ 2 this month</div>
    </div>
    <div class="stat-card">
      <div class="label">Upcoming Trips</div>
      <div class="value"><?= $upcoming ?></div>
      <div class="change change-up">All confirmed</div>
    </div>
    <div class="stat-card wallet-card">
      <div class="label">Travel Wallet</div>
      <div class="value"><?= money($walletBalance) ?></div>
    </div>
    <div class="stat-card">
      <div class="label">Reward Points</div>
      <div class="value"><?= $rewardPoints ?></div>
      <div class="change change-up">Redeem for discounts</div>
    </div>
  </div>

  <div class="dashboard-grid">
    <!-- Upcoming trips -->
    <div class="dashboard-card">
      <div class="dashboard-card-header">
        <h3>Upcoming Trips</h3>
        <a href="<?= url('dashboard/bookings.php') ?>">View all</a>
      </div>
      <div class="dashboard-card-body">
        <?php if ($upcomingTrips): ?>
          <?php foreach ($upcomingTrips as $trip): ?>
            <div class="trip-card">
              <div class="trip-card-image">
                <img src="https://images.unsplash.com/photo-1469854523076-904d97e86e29?auto=format&fit=crop&w=200&q=80" alt="<?= e($trip['destination']) ?>">
              </div>
              <div class="trip-card-info">
                <h4><?= e($trip['destination']) ?></h4>
                <p><?= e($trip['booking_type']) ?> &bull; <?= e($trip['source'] ?? '') ?> → <?= e($trip['destination']) ?></p>
                <div class="trip-card-meta">
                  <span><?= travelDate($trip['journey_date']) ?></span>
                  <span class="badge badge-success">Confirmed</span>
                </div>
              </div>
            </div>
          <?php endforeach; ?>
        <?php else: ?>
          <div class="empty-state" style="padding:var(--space-md);">
            <div class="icon">🧳</div>
            <h3 style="font-size:var(--text-lg);">No upcoming trips</h3>
            <p class="small">Book your first journey and it will appear here.</p>
          </div>
        <?php endif; ?>
      </div>
    </div>

    <!-- Recent bookings -->
    <div class="dashboard-card">
      <div class="dashboard-card-header">
        <h3>Recent Bookings</h3>
        <a href="<?= url('dashboard/bookings.php') ?>">View all</a>
      </div>
      <div class="dashboard-card-body">
        <?php if ($recentBookings): ?>
          <?php foreach ($recentBookings as $b): ?>
            <div class="trip-card">
              <div class="trip-card-image">
                <img src="https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?auto=format&fit=crop&w=200&q=80" alt="Travel">
              </div>
              <div class="trip-card-info">
                <h4><?= e($b['reference']) ?></h4>
                <p><?= ucfirst(e($b['booking_type'])) ?> booking &bull; <?= money($b['total_amount'], $b['currency']) ?></p>
                <div class="trip-card-meta">
                  <span class="badge badge-<?= $b['payment_status'] === 'paid' ? 'success' : 'warning' ?>">
                    <?= ucfirst(e($b['payment_status'])) ?>
                  </span>
                </div>
              </div>
            </div>
          <?php endforeach; ?>
        <?php else: ?>
          <div class="empty-state" style="padding:var(--space-md);">
            <div class="icon">🎫</div>
            <h3 style="font-size:var(--text-lg);">No bookings yet</h3>
            <p class="small">Your recent bookings will appear here.</p>
          </div>
        <?php endif; ?>
      </div>
    </div>

    <!-- Quick actions -->
    <div class="dashboard-card" style="grid-column: 1 / -1;">
      <div class="dashboard-card-header">
        <h3>Quick Actions</h3>
      </div>
      <div class="dashboard-card-body" style="display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:var(--space-md);">
        <a href="<?= url('booking/flights.php') ?>" class="btn btn-outline btn-full">✈️ Book Flight</a>
        <a href="<?= url('booking/buses.php') ?>" class="btn btn-outline btn-full">🚌 Book Bus</a>
        <a href="<?= url('booking/trains.php') ?>" class="btn btn-outline btn-full">🚆 Book Train</a>
        <a href="<?= url('booking/hotels.php') ?>" class="btn btn-outline btn-full">🏨 Book Hotel</a>
        <a href="<?= url('ai/assistant.php') ?>" class="btn btn-outline btn-full">🤖 AI Assistant</a>
        <a href="<?= url('dashboard/wallet.php') ?>" class="btn btn-outline btn-full">💳 Travel Wallet</a>
      </div>
    </div>

    <!-- Notifications -->
    <div class="dashboard-card">
      <div class="dashboard-card-header">
        <h3>Notifications</h3>
        <a href="<?= url('dashboard/notifications.php') ?>">View all</a>
      </div>
      <div class="dashboard-card-body">
        <?php if ($notifications): ?>
          <?php foreach ($notifications as $n): ?>
            <div class="notification-item">
              <div class="notification-dot"></div>
              <div class="notification-content">
                <h5><?= e($n['title']) ?></h5>
                <p><?= e($n['message']) ?></p>
                <time><?= date('d M, H:i', strtotime($n['created_at'])) ?></time>
              </div>
            </div>
          <?php endforeach; ?>
        <?php else: ?>
          <div class="empty-state" style="padding:var(--space-md);">
            <div class="icon">🔔</div>
            <h3 style="font-size:var(--text-lg);">No notifications</h3>
            <p class="small">You're all caught up.</p>
          </div>
        <?php endif; ?>
      </div>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>