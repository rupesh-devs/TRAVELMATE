<?php
/**
 * TRAVELMATE AI - Wishlist
 */
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../config/auth.php';
requireAuth();

$userId = (int) $_SESSION['user_id'];
$wishlist = Database::query(
  'SELECT w.*, d.name, d.country, d.city, d.image_url, d.rating FROM wishlists w LEFT JOIN destinations d ON w.destination_id = d.id WHERE w.user_id = ? ORDER BY w.created_at DESC',
  [$userId]
);
?>
<div class="container">
  <div class="dashboard-header">
    <h1>Wishlist</h1>
    <a href="<?= url('dashboard/index.php') ?>" class="btn btn-outline">← Back</a>
  </div>

  <div class="grid grid-3">
    <?php if ($wishlist): foreach ($wishlist as $w): ?>
      <div class="destination-card">
        <div class="destination-image">
          <img src="<?= e($w['image_url'] ?? 'https://images.unsplash.com/photo-1469854523076-904d97e86e29?auto=format&fit=crop&w=600&q=80') ?>" alt="<?= e($w['name']) ?>">
        </div>
        <div class="destination-body">
          <h3><?= e($w['name']) ?></h3>
          <div class="destination-meta">📍 <?= e($w['country']) ?></div>
        </div>
      </div>
    <?php endforeach; else: ?>
      <div class="empty-state" style="grid-column:1/-1;padding:var(--space-3xl);">
        <div class="icon">❤️</div>
        <h3 style="font-size:var(--text-lg);">Your wishlist is empty</h3>
        <p class="small">Save destinations you love from the Explore page.</p>
      </div>
    <?php endforeach; ?>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>