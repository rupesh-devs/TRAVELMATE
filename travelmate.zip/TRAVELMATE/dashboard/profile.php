<?php
/**
 * TRAVELMATE AI - User Profile
 */
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../config/auth.php';
requireAuth();

$userId = (int) $_SESSION['user_id'];
$user = Database::queryOne('SELECT * FROM users WHERE id = ?', [$userId]);
$prefs = Database::queryOne('SELECT * FROM user_preferences WHERE user_id = ?', [$userId]);

$message = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $name  = trim($_POST['full_name'] ?? '');
  $mobile = trim($_POST['mobile'] ?? '');
  $country = trim($_POST['country'] ?? '');
  if (!$name || !$mobile || !$country) {
    $message = ['All fields are required.', 'error'];
  } else {
    Database::execute('UPDATE users SET full_name = ?, mobile = ?, country = ? WHERE id = ?', [$name, $mobile, $country, $userId]);
    Database::execute('INSERT INTO user_preferences (user_id, currency, language, theme) VALUES (?, ?, ?, ?) ON DUPLICATE KEY UPDATE currency = VALUES(currency), language = VALUES(language), theme = VALUES(theme)',
      [$userId, $_POST['currency'] ?? 'INR', $_POST['language'] ?? 'en', $_POST['theme'] ?? 'light']);
    $_SESSION['user_name'] = $name;
    $message = ['Profile updated successfully.', 'success'];
  }
}
?>
<div class="container" style="max-width:700px; margin: var(--space-xl) auto;">
  <div class="dashboard-header">
    <h1>Profile</h1>
    <a href="<?= url('dashboard/index.php') ?>" class="btn btn-outline">← Back to dashboard</a>
  </div>

  <?php if ($message): ?>
    <div style="background:<?= $message[1] === 'success' ? '#dcfce7' : '#fee2e2' ?>;color:<?= $message[1] === 'success' ? '#14532d' : '#991b1b' ?>;padding:var(--space-sm);border-radius:var(--radius-md);margin-bottom:var(--space-lg);font-size:var(--text-sm);"><?= e($message[0]) ?></div>
  <?php endif; ?>

  <div class="card">
    <div class="card-body">
      <div style="display:flex;align-items:center;gap:var(--space-lg);margin-bottom:var(--space-xl);">
        <div class="avatar" style="width:96px;height:96px;font-size:2rem;"><?= strtoupper(substr(e($_SESSION['user_name']), 0, 2)) ?></div>
        <div>
          <h3 style="margin:0;"><?= e($_SESSION['user_name']) ?></h3>
          <p class="small"><?= e($_SESSION['user_email']) ?> &bull; Member since <?= date('M Y', strtotime($user['created_at'] ?? 'now')) ?></p>
        </div>
      </div>

      <form method="POST" action="">
        <div class="form-group">
          <label>Full name</label>
          <input type="text" name="full_name" class="form-control" required value="<?= e($user['full_name'] ?? '') ?>">
        </div>
        <div class="form-group">
          <label>Email address</label>
          <input type="email" name="email" class="form-control" value="<?= e($user['email'] ?? '') ?>" readonly>
          <p class="form-text">Email cannot be changed from here.</p>
        </div>
        <div class="form-group">
          <label>Mobile number</label>
          <input type="tel" name="mobile" class="form-control" required value="<?= e($user['mobile'] ?? '') ?>">
        </div>
        <div class="form-group">
          <label>Country</label>
          <input type="text" name="country" class="form-control" required value="<?= e($user['country'] ?? '') ?>">
        </div>
        <div class="form-group">
          <label>Preferred currency</label>
          <select name="currency" class="form-select">
            <option value="INR" <?= (($prefs['currency'] ?? '') === 'INR') ? 'selected' : '' ?>>INR (Indian Rupee)</option>
            <option value="USD" <?= (($prefs['currency'] ?? '') === 'USD') ? 'selected' : '' ?>>USD (US Dollar)</option>
            <option value="EUR" <?= (($prefs['currency'] ?? '') === 'EUR') ? 'selected' : '' ?>>EUR (Euro)</option>
            <option value="GBP" <?= (($prefs['currency'] ?? '') === 'GBP') ? 'selected' : '' ?>>GBP (British Pound)</option>
            <option value="AED" <?= (($prefs['currency'] ?? '') === 'AED') ? 'selected' : '' ?>>AED (UAE Dirham)</option>
          </select>
        </div>
        <div class="form-group">
          <label>Language</label>
          <select name="language" class="form-select">
            <option value="en" <?= (($prefs['language'] ?? '') === 'en') ? 'selected' : '' ?>>English</option>
            <option value="hi" <?= (($prefs['language'] ?? '') === 'hi') ? 'selected' : '' ?>>हिन्दी (Hindi)</option>
          </select>
        </div>
        <div class="form-group">
          <label>Theme</label>
          <select name="theme" class="form-select">
            <option value="light" <?= (($prefs['theme'] ?? '') === 'light') ? 'selected' : '' ?>>Light</option>
            <option value="dark" <?= (($prefs['theme'] ?? '') === 'dark') ? 'selected' : '' ?>>Dark</option>
          </select>
        </div>
        <div class="form-group">
          <button type="submit" class="btn btn-primary">Save changes</button>
        </div>
      </form>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>