<?php
/**
 * TRAVELMATE AI - Notifications
 */
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../config/auth.php';
requireAuth();

$userId = (int) $_SESSION['user_id'];
$notifications = Database::query(
  'SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC',
  [$userId]
);
Database::execute('UPDATE notifications SET is_read = 1 WHERE user_id = ? AND is_read = 0', [$userId]);
?>
<div class="container">
  <div class="dashboard-header">
    <h1>Notifications</h1>
    <a href="<?= url('dashboard/index.php') ?>" class="btn btn-outline">← Back</a>
  </div>

  <div class="dashboard-card">
    <div class="dashboard-card-body">
      <?php if ($notifications): foreach ($notifications as $n): ?>
        <div class="notification-item" style="<?= $n['is_read'] ? 'background:var(--color-sky-soft);' : '' ?>">
          <div class="notification-dot"></div>
          <div class="notification-content">
            <h5><?= e($n['title']) ?></h5>
            <p><?= e($n['message']) ?></p>
            <time><?= date('d M Y, h:i A', strtotime($n['created_at'])) ?></time>
          </div>
        </div>
      <?php endforeach; else: ?>
        <div class="empty-state" style="padding:var(--space-md);">
          <div class="icon">🔔</div>
          <h3 style="font-size:var(--text-lg);">No notifications</h3>
        </div>
      <?php endif; ?>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>