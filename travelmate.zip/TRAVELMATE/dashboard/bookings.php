<?php
/**
 * TRAVELMATE AI - My Bookings
 */
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../config/auth.php';
requireAuth();

$userId = (int) $_SESSION['user_id'];
$bookings = Database::query(
  'SELECT * FROM bookings WHERE user_id = ? ORDER BY created_at DESC',
  [$userId]
);
?>
<div class="container">
  <div class="dashboard-header">
    <h1>My Bookings</h1>
    <a href="<?= url('dashboard/index.php') ?>" class="btn btn-outline">← Back</a>
  </div>

  <div class="table-wrap">
    <table>
      <thead>
        <tr>
          <th>Reference</th>
          <th>Type</th>
          <th>Route</th>
          <th>Journey Date</th>
          <th>Amount</th>
          <th>Status</th>
          <th>Payment</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        <?php if ($bookings): foreach ($bookings as $b): ?>
          <tr>
            <td><strong><?= e($b['reference']) ?></strong></td>
            <td><span class="badge badge-info"><?= ucfirst(e($b['booking_type'])) ?></span></td>
            <td><?= e($b['source'] ?? '-') ?> → <?= e($b['destination']) ?></td>
            <td><?= $b['journey_date'] ? travelDate($b['journey_date']) : '-' ?></td>
            <td><?= money($b['total_amount'], $b['currency']) ?></td>
            <td><span class="badge badge-<?= $b['status'] === 'confirmed' ? 'success' : ($b['status'] === 'cancelled' ? 'error' : 'warning') ?>"><?= ucfirst(e($b['status'])) ?></span></td>
            <td><span class="badge badge-<?= $b['payment_status'] === 'paid' ? 'success' : 'warning' ?>"><?= ucfirst(e($b['payment_status'])) ?></span></td>
            <td>
              <?php if ($b['status'] === 'confirmed'): ?>
                <a href="<?= url('booking/ticket.php?ref=' . $b['reference']) ?>" class="btn btn-sm btn-outline">View Ticket</a>
              <?php endif; ?>
              <?php if ($b['status'] === 'confirmed' && $b['payment_status'] === 'paid'): ?>
                <a href="<?= url('booking/cancellations.php?id=' . $b['id']) ?>" class="btn btn-sm btn-outline" style="color:var(--color-error);border-color:var(--color-error);">Cancel</a>
              <?php endif; ?>
            </td>
          </tr>
        <?php endforeach; else: ?>
          <tr><td colspan="8" style="text-align:center;color:var(--color-muted);">No bookings found.</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>