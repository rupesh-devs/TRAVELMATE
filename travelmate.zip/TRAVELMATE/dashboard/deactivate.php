<?php
/**
 * TRAVELMATE AI - Deactivate Account handler
 */
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/auth.php';
requireAuth();

Database::execute('UPDATE users SET status = ? WHERE id = ?', ['inactive', (int) $_SESSION['user_id']]);
session_destroy();
setcookie('tm_remember', '', time() - 3600, '/');
redirect('auth/login.php');